// Generic empty-body Web Push + ES256 VAPID (RFC 8030 / RFC 8292).
// Notification text is fixed in the service worker; no holdings/prices are sent.
export const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
export function un64(s){if(typeof s!=='string'||!/^[A-Za-z0-9_-]+$/.test(s))throw Error('PUSH_KEY_INVALID');return Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),x=>x.charCodeAt(0));}
export function pushEndpoint(s){
 if(typeof s!=='string'||s.length>2048)throw Error('PUSH_ENDPOINT_INVALID');const u=new URL(s);
 const allowed=u.hostname==='fcm.googleapis.com'||u.hostname==='web.push.apple.com'||u.hostname==='updates.push.services.mozilla.com'||u.hostname.endsWith('.push.services.mozilla.com');
 if(u.protocol!=='https:'||u.username||u.password||u.port||u.hash||!allowed)throw Error('PUSH_ENDPOINT_BLOCKED');return u;
}
export async function checkedSubscription(s){
 const u=pushEndpoint(s?.endpoint);if(!s.keys||un64(s.keys.auth).length!==16||un64(s.keys.p256dh).length!==65)throw Error('PUSH_KEY_INVALID');
 await crypto.subtle.importKey('raw',un64(s.keys.p256dh),{name:'ECDH',namedCurve:'P-256'},false,[]);
 return {endpoint:u.toString(),expirationTime:typeof s.expirationTime==='number'?s.expirationTime:null,keys:{p256dh:s.keys.p256dh,auth:s.keys.auth}};
}
export async function vapidAuthorization(endpoint,env,now=Date.now()){
 const raw=un64(env.VAPID_PUBLIC_KEY);if(raw.length!==65||raw[0]!==4)throw Error('VAPID_CONFIG_INVALID');
 if(!/^mailto:[^\s@]+@[^\s@]+$/.test(env.VAPID_SUBJECT||''))throw Error('VAPID_CONTACT_REQUIRED');
 let jwk;try{jwk=JSON.parse(env.VAPID_PRIVATE_JWK);}catch{throw Error('VAPID_CONFIG_INVALID');}
 if(jwk.kty!=='EC'||jwk.crv!=='P-256'||un64(jwk.d||'').length!==32||b64(raw.slice(1,33))!==jwk.x||b64(raw.slice(33))!==jwk.y)throw Error('VAPID_KEY_PAIR_MISMATCH');
 const key=await crypto.subtle.importKey('jwk',jwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
 const encode=x=>b64(new TextEncoder().encode(JSON.stringify(x))),head=encode({typ:'JWT',alg:'ES256'}),payload=encode({aud:pushEndpoint(endpoint).origin,exp:Math.floor(now/1000)+3600,sub:env.VAPID_SUBJECT});
 const content=head+'.'+payload,signature=await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,new TextEncoder().encode(content));
 if(signature.byteLength!==64)throw Error('VAPID_SIGNATURE_FORMAT');return 'vapid t='+content+'.'+b64(signature)+', k='+env.VAPID_PUBLIC_KEY;
}
export async function sendReviewPush(subscription,env,fetchImpl=fetch){
 const u=pushEndpoint(subscription.endpoint),authorization=await vapidAuthorization(u.toString(),env);
 // Workers fetch supports follow/manual. Manual avoids forwarding VAPID credentials.
 let r;try{r=await fetchImpl(u.toString(),{method:'POST',headers:{Authorization:authorization,TTL:'300',Urgency:'normal','Content-Type':'application/octet-stream'},body:new Uint8Array(0),redirect:'manual',signal:AbortSignal.timeout(15000)});}catch{return {state:'UNKNOWN',automaticRetry:false};}
 if(r.body)await r.body.cancel().catch(()=>{});
 return {state:r.status>=300&&r.status<400?'REDIRECT_BLOCKED':r.status===201||r.status===202?'ACCEPTED_BY_PUSH_SERVICE':r.status===404||r.status===410?'EXPIRED':'REJECTED',httpStatus:r.status,deviceReceiptVerified:false,automaticRetry:false};
}
