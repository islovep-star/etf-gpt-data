import {b64,un64,checkedSubscription,sendReviewPush} from './push.mjs';
const NS='basic-app:v1:',LIMIT=24*1024*1024,ID=/^[A-Za-z0-9_-]{1,64}$/;
const hex=bytes=>[...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('');
export const sha=async bytes=>hex(await crypto.subtle.digest('SHA-256',bytes));
const reply=(v,status=200,runId=null)=>new Response(JSON.stringify(v),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'",...(runId?{'X-Basic-Run-Id':runId}:{})}});
function fail(code,status=400){throw Object.assign(Error(code),{code,status});}
function auth(request,env,write=false){
 const read=env.BASIC_PWA_READ_TOKEN,admin=env.BASIC_APP_ADMIN_TOKEN;
 if(!/^[A-Za-z0-9_-]{24,256}$/.test(read||'')||!/^[A-Za-z0-9_-]{24,256}$/.test(admin||'')||read===admin)fail('DISTINCT_APP_SECRETS_REQUIRED',503);
 if(request.headers.get('Authorization')!=='Bearer '+(write?admin:read))fail('UNAUTHORIZED',401);
}
function kv(env){if(!env.BASIC_APP_KV)fail('BASIC_APP_KV_REQUIRED',503);return env.BASIC_APP_KV;}
async function body(request,limit){
 if(!request.body||Number(request.headers.get('Content-Length')||0)>limit)fail('BODY_TOO_LARGE',413);
 const reader=request.body.getReader(),chunks=[];let n=0;
 try{for(;;){const x=await reader.read();if(x.done)break;n+=x.value.length;if(n>limit)fail('BODY_TOO_LARGE',413);chunks.push(x.value);}}finally{await reader.cancel().catch(()=>{});}
 const out=new Uint8Array(n);let offset=0;for(const c of chunks){out.set(c,offset);offset+=c.length;}
 try{return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(out));}catch{fail('INVALID_JSON');}
}
function pathOK(s){return typeof s==='string'&&s.length<300&&!s.startsWith('/')&&!/[\\%?#\x00-\x1f]/.test(s)&&s.split('/').every(x=>x&&x!=='.'&&x!=='..');}
export async function validateBundle(v){
 if(v?.schema!=='BASIC_APP_UPLOAD_V1'||!ID.test(v.runId||'')||!Array.isArray(v.files)||!v.files.length||v.files.length>20000)fail('BUNDLE_CONTRACT_INVALID');
 const names=new Set();let total=0,packet,run;
 for(const f of v.files){
  if(!pathOK(f.path)||names.has(f.path)||!Number.isSafeInteger(f.bytes)||f.bytes<0||! /^[a-f0-9]{64}$/.test(f.sha256||'')||typeof f.base64!=='string')fail('BUNDLE_FILE_INVALID');names.add(f.path);
  let bytes;try{bytes=un64(f.base64);}catch{if(f.base64==='')bytes=new Uint8Array(0);else fail('BUNDLE_ENCODING_INVALID');}
  total+=bytes.length;if(total>16*1024*1024||bytes.length!==f.bytes||await sha(bytes)!==f.sha256)fail('BUNDLE_INTEGRITY_FAILURE');
  if(f.path==='gpt_packet.json'||f.path==='run.json'){let x;try{x=JSON.parse(new TextDecoder().decode(bytes));}catch{fail('BUNDLE_JSON_INVALID');}if(f.path==='gpt_packet.json')packet=x;else run=x;}
 }
 if(packet?.schema!=='GPT_BASIC_RELEASE_PACKET_V1'||packet.generation!==v.runId||packet.metadata?.runId!==v.runId||packet.actionAllowed!==false||packet.automaticTradingAllowed!==false||packet.metadata?.orderExecution!==false||packet.metadata?.ruleBlobSha!=='327f91d760e5d703ba6c970e3b9fa8a036de9187'||!Array.isArray(packet.reviews)||!packet.sections)fail('BUNDLE_PACKET_INVALID');
 if(run?.schema!=='LOCAL_REVIEW_RUN_V1'||run.runId!==v.runId||run.status!=='COMPLETE'||!Array.isArray(run.files)||run.files.length!==v.files.length-1)fail('BUNDLE_RUN_INVALID');
 for(const f of run.files){const actual=v.files.find(x=>x.path===f.path);if(!actual||f.path==='run.json'||actual.bytes!==f.bytes||actual.sha256!==f.sha256)fail('BUNDLE_RUN_MANIFEST_MISMATCH');}
 const dates=[packet.metadata.analysisAsOf,run.completedAt];if(dates.some(x=>!Number.isFinite(Date.parse(x))||Date.parse(x)>Date.now()+300000))fail('BUNDLE_FUTURE_OR_INVALID_TIME');
 return v;
}
export default {
 async fetch(request,env){
  try{
   const u=new URL(request.url),p=u.pathname;if(u.protocol!=='https:'&&u.hostname!=='localhost'&&u.hostname!=='127.0.0.1')fail('HTTPS_REQUIRED',403);
   if(u.search||u.hash||/%|\\/.test(p))fail('APP_URL_INVALID');
   const origin=request.headers.get('Origin');if(origin&&origin!==u.origin)fail('SAME_ORIGIN_REQUIRED',403);
   if(request.headers.get('Sec-Fetch-Site')==='cross-site'&&request.method!=='GET')fail('SAME_ORIGIN_REQUIRED',403);
   if(p==='/health'){if(request.method!=='GET')fail('GET_ONLY',405);return reply({ok:true,version:'BASIC_APP_V1',scope:'APP_INTERFACE_ONLY',deploymentVerified:false});}
   if(p==='/admin/publish'){
    if(request.method!=='POST')fail('POST_ONLY',405);auth(request,env,true);const data=await validateBundle(await body(request,LIMIT)),raw=JSON.stringify(data),hash=await sha(new TextEncoder().encode(raw)),store=kv(env);
    const key=NS+'run:'+data.runId,existing=await store.get(key);if(existing){if(await sha(new TextEncoder().encode(existing))!==hash)fail('RUN_ID_CONFLICT',409);return reply({ok:true,runId:data.runId,state:'ALREADY_STORED_POINTER_NOT_CHANGED',hash,consistency:'EVENTUAL'});}
    try{await store.put(key,raw);await store.put(NS+'published',JSON.stringify({runId:data.runId,hash}));}catch{fail('PUBLICATION_UNKNOWN_NO_AUTOMATIC_RETRY',503);}
    return reply({ok:true,runId:data.runId,hash,state:'PUBLICATION_ACKNOWLEDGED',consistency:'EVENTUAL',sourceAccuracy:'NOT_CERTIFIED'});
   }
   if(p.startsWith('/mobile/data/')){
    if(request.method!=='GET')fail('GET_ONLY',405);auth(request,env);const store=kv(env),pointer=await store.get(NS+'published',{type:'json'});if(!pointer)fail('APP_DATA_NOT_PUBLISHED',404);
    const raw=await store.get(NS+'run:'+pointer.runId);if(!raw)fail('APP_DATA_PROPAGATING',503);if(await sha(new TextEncoder().encode(raw))!==pointer.hash)fail('APP_DATA_INTEGRITY_FAILURE',503);
    const data=JSON.parse(raw),name=p.slice('/mobile/data/'.length);if(data.runId!==pointer.runId)fail('APP_DATA_INTEGRITY_FAILURE',503);
    if(name==='run')return reply({runId:data.runId,status:'COMPLETE',integrityStatus:'VERIFIED_PUBLISHED_BYTES',readOnly:true,authMode:'ENV_READ_TOKEN',remotePush:env.VAPID_PUBLIC_KEY?'CONFIGURED_DEVICE_RECEIPT_UNVERIFIED':'CONFIGURATION_REQUIRED',automaticResend:false,orderExecution:false},200,data.runId);
    if(name==='manifest')return reply({schema:'BASIC_MOBILE_MANIFEST_V1',runId:data.runId,actionAllowed:false,files:data.files.map(({path,bytes,sha256})=>({path,bytes,sha256}))},200,data.runId);
    const f=data.files.find(x=>x.path===name);if(!f)fail('FILE_NOT_IN_MANIFEST',404);
    // Always download HTML/raw files; only JSON is eligible for inline data viewing.
    return new Response(f.base64?un64(f.base64):new Uint8Array(0),{headers:{'Content-Type':name.endsWith('.json')?'application/json; charset=utf-8':'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",'X-Basic-Run-Id':data.runId}});
   }
   if(p==='/mobile/push/config'){
    if(request.method!=='GET')fail('GET_ONLY',405);auth(request,env);if(!env.VAPID_PUBLIC_KEY||!env.VAPID_PRIVATE_JWK||!env.VAPID_SUBJECT)fail('VAPID_CONFIG_REQUIRED',503);
    return reply({publicKey:env.VAPID_PUBLIC_KEY,mode:'GENERIC_REVIEW_NOTICE',deviceReceiptVerified:false});
   }
   if(p==='/mobile/push/subscribe'||p==='/mobile/push/unsubscribe'){
    if(request.method!=='POST')fail('POST_ONLY',405);auth(request,env);const data=await body(request,8192),s=await checkedSubscription(data),id=await sha(new TextEncoder().encode(s.endpoint)),store=kv(env);
    if(p.endsWith('/unsubscribe'))await store.delete(NS+'subscription:'+id);
    else {if(!env.VAPID_PUBLIC_KEY||data.applicationServerKey!==env.VAPID_PUBLIC_KEY)fail('SUBSCRIPTION_VAPID_KEY_MISMATCH',409);await store.put(NS+'subscription:'+id,JSON.stringify({subscription:s,applicationServerKey:env.VAPID_PUBLIC_KEY,createdAt:new Date().toISOString()}));}
    return reply({ok:true,state:p.endsWith('/unsubscribe')?'REMOVED':'STORED',consistency:'EVENTUAL'});
   }
   if(p==='/admin/push-test'){
    if(request.method!=='POST')fail('POST_ONLY',405);auth(request,env,true);const store=kv(env),data=await body(request,1024);if(data.confirm!== 'GENERIC_REVIEW_NOTICE')fail('PUSH_EXPLICIT_NOTICE_REQUIRED');
    const listed=await store.list({prefix:NS+'subscription:',limit:100});if(!listed.list_complete)fail('PUSH_SUBSCRIPTION_BATCH_LIMIT',409);
    const results=[];for(const key of listed.keys){const record=await store.get(key.name,{type:'json'});if(!record)continue;if(record.applicationServerKey!==env.VAPID_PUBLIC_KEY){results.push({state:'KEY_CHANGED_RESUBSCRIBE_REQUIRED'});continue;}const result=await sendReviewPush(record.subscription,env);if(result.state==='EXPIRED')await store.delete(key.name);results.push(result);}
    return reply({ok:results.length>0&&results.every(x=>x.state==='ACCEPTED_BY_PUSH_SERVICE'),results,deviceReceiptVerified:false,automaticRetry:false});
   }
   if(p.startsWith('/admin/')||p.startsWith('/mobile/data')||p.startsWith('/mobile/push/'))fail('ROUTE_NOT_FOUND',404);
   if(request.method!=='GET'&&request.method!=='HEAD')fail('GET_ONLY',405);
   const asset=await env.ASSETS.fetch(request),headers=new Headers(asset.headers);headers.set('X-Content-Type-Options','nosniff');headers.set('Referrer-Policy','no-referrer');headers.set('Cache-Control','no-store');
   if(p==='/sw.js')headers.set('Service-Worker-Allowed','/');
   return new Response(asset.body,{status:asset.status,headers});
  }catch(e){return reply({ok:false,error:e.code||'APP_REQUEST_FAILED',automaticRetry:false},e.status||503);}
 }
};
