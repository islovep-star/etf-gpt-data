const base64=bytes=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
export async function generateMobileKeys(api=crypto){
 const read=base64(api.getRandomValues(new Uint8Array(32)));let admin;do{admin=base64(api.getRandomValues(new Uint8Array(32)));}while(admin===read);
 const pair=await api.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const privateJwk=await api.subtle.exportKey('jwk',pair.privateKey),raw=await api.subtle.exportKey('raw',pair.publicKey);
 return {BASIC_PWA_READ_TOKEN:read,BASIC_APP_ADMIN_TOKEN:admin,VAPID_PRIVATE_JWK:JSON.stringify(privateJwk),VAPID_PUBLIC_KEY:base64(new Uint8Array(raw))};
}
if(typeof document!=='undefined'){
 let keys=null;const message=document.getElementById('message'),button=document.getElementById('generate');
 button.onclick=async()=>{if(keys)return;button.disabled=true;try{if(!isSecureContext||!crypto?.subtle)throw Error();keys=await generateMobileKeys();for(const [name,value] of Object.entries(keys))document.getElementById(name).value=value;document.getElementById('values').hidden=false;message.textContent='생성한 키를 휴대폰에 보관하고 GitHub 설정에 등록하세요. 서버 등록은 아직 하지 않았습니다.';}catch{button.disabled=false;message.textContent='키를 생성하지 못했습니다. 새 앱의 HTTPS 주소에서 다시 확인하세요.';}};
 for(const b of document.querySelectorAll('[data-copy]'))b.onclick=async()=>{try{await navigator.clipboard.writeText(keys[b.dataset.copy]);message.textContent='복사했습니다. GitHub 설정에 직접 붙여넣으세요.';}catch{const field=document.getElementById(b.dataset.copy);field.focus();field.select();message.textContent='입력란을 선택했습니다. 브라우저의 복사 기능을 사용하세요.';}};
 document.getElementById('save').onclick=()=>{if(!keys)return;const url=URL.createObjectURL(new Blob([JSON.stringify(keys,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='basic-app-private-keys.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);message.textContent='비공개 파일 저장을 요청했습니다. 다운로드 완료 여부를 확인하세요.';};
}
