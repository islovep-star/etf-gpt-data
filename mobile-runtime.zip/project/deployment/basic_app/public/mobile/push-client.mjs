// Loaded only on the hosted /mobile/ candidate. Tokens remain in the form's memory.
export function publicKeyBytes(s){if(typeof s!=='string'||!/^[A-Za-z0-9_-]{87}$/.test(s))throw Error('VAPID_PUBLIC_KEY_INVALID');const bytes=Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='),x=>x.charCodeAt(0));if(bytes.length!==65||bytes[0]!==4)throw Error('VAPID_PUBLIC_KEY_INVALID');return bytes;}
export async function pushRequest(path,{token,body,fetchImpl=fetch}={}){
 if(!['config','subscribe','unsubscribe'].includes(path))throw Error('PUSH_ROUTE_INVALID');if(!token?.trim())throw Error('조회 토큰을 입력해 주세요.');
 let response;try{response=await fetchImpl('/mobile/push/'+path,{method:path==='config'?'GET':'POST',headers:{Authorization:'Bearer '+token.trim(),'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),cache:'no-store',credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(20000)});}catch{throw Error('푸시 연결을 확인하지 못했습니다. 자동 재요청하지 않습니다.');}
 if(!response.ok)throw Error(response.status===401?'조회 토큰을 확인해 주세요.':'푸시 서버 설정 또는 저장 상태를 확인해 주세요.');return response.json();
}
function boot(){
 const token=()=>document.getElementById('readToken').value,info=document.getElementById('remotePushInfo');let busy=false;
 const run=async f=>{if(busy)return;busy=true;try{await f();}catch(e){info.textContent=e.message||'푸시 연결을 확인해 주세요.';}finally{busy=false;}};
 document.getElementById('subscribePush').onclick=()=>run(async()=>{
  if(!isSecureContext||!('serviceWorker' in navigator)||!('PushManager' in window)||!('Notification' in window))throw Error('HTTPS 주소와 푸시 지원 브라우저가 필요합니다.');
  if(!token().trim())throw Error('조회 토큰을 입력해 주세요.');
  const permission=Notification.permission==='default'?await Notification.requestPermission():Notification.permission;if(permission!=='granted')throw Error('이 사이트의 알림을 허용해 주세요.');
  const config=await pushRequest('config',{token:token()}),key=publicKeyBytes(config.publicKey),registration=await navigator.serviceWorker.ready;
  let s=await registration.pushManager.getSubscription();
  if(s?.options?.applicationServerKey){const old=new Uint8Array(s.options.applicationServerKey);if(old.length!==key.length||old.some((x,i)=>x!==key[i]))throw Error('발송 키가 변경되었습니다. 푸시 해제 후 다시 연결해 주세요.');}
  if(!s)s=await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:key});
  // A saved browser subscription may outlive an interrupted server save. A second click saves that same subscription only.
  await pushRequest('subscribe',{token:token(),body:{...s.toJSON(),applicationServerKey:config.publicKey}});info.textContent='원격 푸시 구독을 저장했습니다. 서버 시험 발송 후 휴대폰 수신을 확인해 주세요.';
 });
 document.getElementById('unsubscribePush').onclick=()=>run(async()=>{
  const registration=await navigator.serviceWorker.ready,s=await registration.pushManager.getSubscription();if(!s){info.textContent='연결된 푸시 구독이 없습니다.';return;}
  await pushRequest('unsubscribe',{token:token(),body:s.toJSON()});if(!await s.unsubscribe())throw Error('서버 구독은 해제했습니다. 브라우저 알림 설정도 확인해 주세요.');info.textContent='원격 푸시 구독을 해제했습니다.';
 });
}
if(typeof document!=='undefined')boot();
