/* Scope is /mobile/. Only the blank application shell is eligible for storage. */
const CACHE='etf-basic-pwa-shell-v1';
const SHELL=new Set(['/mobile/','/mobile/index.html','/mobile/style.css','/mobile/app.mjs','/mobile/manifest.webmanifest','/mobile/icon.svg','/mobile/icon-192.png','/mobile/icon-512.png']);
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll([...SHELL]))));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('etf-basic-pwa-shell-')&&key!==CACHE)await caches.delete(key);})()));
self.addEventListener('fetch',event=>{
 const u=new URL(event.request.url);
 if(event.request.method!=='GET'||u.origin!==self.location.origin||u.search||event.request.headers.has('Authorization')||!SHELL.has(u.pathname))return;
 event.respondWith((async()=>{try{return await fetch(event.request,{cache:'no-store'});}catch{const cache=await caches.open(CACHE);return await cache.match(u.pathname)||Response.error();}})());
});
// Payload cannot provide a trade instruction, URL, price or private holding text.
self.addEventListener('push',event=>event.waitUntil(self.registration.showNotification('주식·ETF 검토 알림',{body:'새 검토자료 확인 요청입니다. 앱을 열어 자료 기준시각을 확인하세요.',icon:'/mobile/icon.svg',tag:'basic-review-update',data:{path:'/mobile/'}})));
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil((async()=>{const list=await self.clients.matchAll({type:'window'});const existing=list.find(c=>new URL(c.url).origin===self.location.origin&&new URL(c.url).pathname==='/mobile/');if(existing)return existing.focus();return self.clients.openWindow('/mobile/');})());});
