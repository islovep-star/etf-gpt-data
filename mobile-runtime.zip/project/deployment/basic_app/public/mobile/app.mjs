export const PWA_BUILD='BASIC-PWA-READONLY-V1';
const ID=/^[A-Za-z0-9_-]{1,64}$/;
export function filePath(value){
 if(typeof value!=='string'||!value||value.startsWith('/')||value.includes('\\')||value.split('/').some(x=>!x||x==='.'||x==='..')||/[?#%\x00-\x1f]/.test(value))throw Error('FILE_PATH_NOT_ALLOWED');return value.split('/').map(encodeURIComponent).join('/');
}
export function checkedPacket(packet,runId){
 if(packet?.schema!=='GPT_BASIC_RELEASE_PACKET_V1'||!ID.test(runId||'')||packet.generation!==runId||packet.metadata?.runId!==runId||packet.actionAllowed!==false||packet.automaticTradingAllowed!==false||!Array.isArray(packet.reviews)||!packet.sections)throw Error('PACKET_ID_OR_AUTHORITY_MISMATCH');return packet;
}
export function checkedManifest(manifest,runId){
 if(manifest?.schema!=='BASIC_MOBILE_MANIFEST_V1'||manifest.runId!==runId||manifest.actionAllowed!==false||!Array.isArray(manifest.files)||manifest.files.length>20000)throw Error('MANIFEST_ID_MISMATCH');
 const paths=new Set();for(const f of manifest.files){filePath(f.path);if(paths.has(f.path)||!Number.isSafeInteger(f.bytes)||f.bytes<0||!/^[a-f0-9]{64}$/.test(f.sha256))throw Error('MANIFEST_FILE_INVALID');paths.add(f.path);}return manifest;
}
export function noticeOptions(level){const patterns={GENERAL:[],IMPORTANT:[120,80,120],URGENT:[250,100,250,100,400]};if(!Object.hasOwn(patterns,level))throw Error('NOTICE_LEVEL_INVALID');return {body:'로컬 연결 시험입니다. 매수·매도 알림이 아닙니다.',icon:'/mobile/icon.svg',tag:'basic-local-test',vibrate:patterns[level],data:{path:'/mobile/'}};}
export function createReader({fetchImpl=fetch,getToken=()=>'',isCurrent=()=>true}={}){
 return async function read(relative,{json=true}={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),30000);
  try{const headers={Accept:json?'application/json':'application/octet-stream'},token=getToken().trim();if(token)headers.Authorization='Bearer '+token;
   const r=await fetchImpl('/mobile/data/'+filePath(relative),{method:'GET',headers,cache:'no-store',credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',signal:controller.signal});
   if(!r.ok)throw Error(r.status===401?'READ_TOKEN_REQUIRED_OR_INVALID':'READ_FAILED_HTTP_'+r.status);const bytes=await r.arrayBuffer();if(!isCurrent())throw Error('VIEW_CANCELLED');return {value:json?JSON.parse(new TextDecoder().decode(bytes)):bytes,runId:r.headers.get('X-Basic-Run-Id')};
  }finally{clearTimeout(timer);}
 };
}
function boot(){
 const $=id=>document.getElementById(id);let epoch=0,busy=false,packet=null,manifest=null,registration=null,installEvent=null;
 const value=(id,s)=>$(id).textContent=s;
 function wipe(){epoch++;packet=null;manifest=null;$('instruments').replaceChildren();$('sections').replaceChildren();value('detail','선택된 정보가 없습니다.');value('runInfo','자료를 조회해 주세요.');$('sourceFile').replaceChildren();for(const id of ['gpt','sources','download','sourceFile'])$(id).disabled=true;}
 const message=error=>{wipe();value('connection','조회 미완료 — 결과를 다시 조회해 주세요.');value('error',error?.message==='VIEW_CANCELLED'?'':error?.message||'연결을 확인해 주세요.');};
 async function work(fn){if(busy)return;busy=true;const snapshot=epoch;value('error','');$('load').disabled=true;const read=createReader({getToken:()=>$('readToken').value,isCurrent:()=>snapshot===epoch});try{await fn(read,()=>snapshot===epoch);}catch(e){if(snapshot===epoch)message(e);}finally{busy=false;$('load').disabled=false;}}
 const textJson=v=>JSON.stringify(v,null,2);
 function render(){
  value('connection','정상 실행 자료 조회 완료 · 투자 검토 보류');value('runInfo','실행 '+packet.generation+' · 분석시각 '+packet.metadata.analysisAsOf+' · 자료모드 '+packet.metadata.mode+' · 원천 '+packet.metadata.sourceVerification);
  const rows=packet.reviews.map(r=>{const div=document.createElement('article');div.className='row';const h=document.createElement('h3');h.textContent=r.instrumentName+' · '+r.instrumentId;const p=document.createElement('p');p.className='note';p.textContent=r.assetType+' · '+r.analysisAsOf;const b=document.createElement('button');b.textContent='객관값·재무·검토 상태 보기';b.onclick=()=>value('detail',textJson(r));div.append(h,p,b);return div;});$('instruments').replaceChildren(...rows);if(!rows.length)value('instruments','입력 종목이 없습니다.');
  const parts=Object.entries(packet.sections).map(([key,s])=>{const div=document.createElement('div');div.className='row';const h=document.createElement('h3');h.textContent=s.label||key;const p=document.createElement('p');p.className='badge';p.textContent=s.status||'MISSING';const b=document.createElement('button');b.className='secondary';b.textContent='상세 보기';b.onclick=()=>value('detail',textJson(s));div.append(h,p,b);return div;});$('sections').replaceChildren(...parts);$('gpt').disabled=false;$('sources').disabled=false;
 }
 function download(bytes,name,type){const blob=new Blob([bytes],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 $('load').onclick=()=>work(async(read,current)=>{const head=await read('run');if(head.value.status!=='COMPLETE'||!ID.test(head.value.runId||''))throw Error('RUN_NOT_READY');const r=await read('gpt_packet.json');if(r.runId!==head.value.runId)throw Error('RESPONSE_RUN_MISMATCH');if(!current())return;packet=checkedPacket(r.value,head.value.runId);render();});
 $('clear').onclick=()=>{wipe();$('readToken').value='';value('error','');value('connection','입력·조회 결과를 지웠습니다.');};
 $('readToken').addEventListener('input',()=>{wipe();value('connection','토큰 변경 — 다시 조회해 주세요.');});
 $('gpt').onclick=()=>{if(packet)download(textJson(packet)+'\n',packet.generation+'_GPT.json','application/json');};
 $('sources').onclick=()=>work(async(read,current)=>{const r=await read('manifest');if(!current())return;manifest=checkedManifest(r.value,packet?.generation);if(r.runId!==packet.generation)throw Error('RESPONSE_RUN_MISMATCH');$('sourceFile').replaceChildren(...manifest.files.map(f=>{const o=document.createElement('option');o.value=f.path;o.textContent=f.path+' · '+f.bytes+' bytes';return o;}));$('sourceFile').disabled=false;$('download').disabled=false;});
 $('download').onclick=()=>work(async(read,current)=>{const f=manifest?.files.find(x=>x.path===$('sourceFile').value);if(!f)throw Error('SOURCE_FILE_NOT_SELECTED');const r=await read(f.path,{json:false});if(!current())return;const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',r.value))].map(x=>x.toString(16).padStart(2,'0')).join('');if(r.runId!==packet.generation||r.value.byteLength!==f.bytes||hash!==f.sha256)throw Error('DOWNLOADED_FILE_INTEGRITY_FAILURE');if(!current())return;download(r.value,packet.generation+'_'+f.path.split('/').pop(),'application/octet-stream');value('detail',textJson({runId:packet.generation,path:f.path,bytes:f.bytes,sha256:hash,transportIntegrity:'MATCHED',sourceAccuracy:'NOT_CERTIFIED_BY_FILE_HASH',actionAllowed:false}));});
 const offline=()=>{$('readToken').value='';wipe();value('connection','오프라인 — 자료·토큰을 지웠습니다. 연결 후 수동 조회해 주세요.');};window.addEventListener('offline',offline);window.addEventListener('online',()=>value('connection','연결이 복구되었습니다. 분석자료 조회를 눌러 주세요.'));window.addEventListener('pagehide',()=>{$('readToken').value='';wipe();});window.addEventListener('pageshow',event=>{if(event.persisted){$('readToken').value='';wipe();value('connection','이전 화면이 복원되었습니다. 분석자료를 다시 조회해 주세요.');}});
 window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installEvent=event;$('install').disabled=false;});$('install').onclick=async()=>{if(!installEvent)return;await installEvent.prompt();installEvent=null;$('install').disabled=true;};
 if(window.isSecureContext&&'serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js',{scope:'/',updateViaCache:'none'}).then(r=>{registration=r;}).catch(()=>value('installInfo','앱 등록을 확인하지 못했습니다. 브라우저 조회는 사용할 수 있습니다.'));
 $('notice').onclick=async()=>{try{if(!window.isSecureContext||!('Notification' in window)||!registration?.active){value('noticeInfo','알림 지원과 앱 등록을 확인한 뒤 다시 시도해 주세요.');return;}const permission=Notification.permission==='default'?await Notification.requestPermission():Notification.permission;if(permission!=='granted'){value('noticeInfo','알림 권한이 허용되지 않았습니다.');return;}await registration.showNotification('주식·ETF 로컬 시험',noticeOptions($('noticeLevel').value));value('noticeInfo','로컬 시험 알림을 요청했습니다. 원격 푸시는 설정 대기 상태입니다.');}catch{value('noticeInfo','시험 알림을 표시하지 못했습니다.');}};
}
if(typeof document!=='undefined')boot();
