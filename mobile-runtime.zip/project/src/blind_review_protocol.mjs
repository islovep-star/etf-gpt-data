import fs from 'node:fs';import path from 'node:path';
import {sha256,strictTimestamp} from './common.mjs';
import {validateRecordEnvelope} from './data_record_contract.mjs';
const id=x=>{if(!/^[A-Za-z0-9_-]{1,64}$/.test(x))throw new Error('CASE_OR_EVALUATOR_ID_REQUIRED');return x;};
const fields=['key','account','instrumentId','value','unit','currency','periodStart','periodEnd','periodKind','tradeDate','observedAt','availableAt','versionId','sourceRef','rawReference'];
const seal=x=>({...x,hash:sha256(x)});
const verify=x=>{const {hash,...body}=x;if(hash!==sha256(body))throw new Error('BLIND_RECORD_HASH_MISMATCH');return body;};
function dir(root,caseId){const p=path.resolve(root,id(caseId));fs.mkdirSync(p,{recursive:true,mode:0o700});if(fs.realpathSync(p)!==p)throw new Error('BLIND_SYMLINK_FORBIDDEN');return p;}
function read(p){if(fs.realpathSync(p)!==p)throw new Error('BLIND_SYMLINK_FORBIDDEN');const x=JSON.parse(fs.readFileSync(p));verify(x);return x;}
function exclusive(p,value){const fd=fs.openSync(p,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
const hashValue=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
function validateLock(lock,packet,caseId){
 if(lock.schema!=='BLIND_JUDGEMENT_LOCK_V1'||lock.caseId!==caseId||!hashValue(lock.packetHash)||packet.schema!=='BLIND_OBJECTIVE_PACKET_V1'||packet.caseId!==caseId||packet.hash!==lock.packetHash||packet.asOf!==lock.asOf||packet.status!=='PROTOCOL_READY'||!Array.isArray(packet.blockers)||packet.blockers.length||!Array.isArray(packet.observations)||!packet.observations.length)throw new Error('BLIND_LOCK_PACKET_BINDING_INVALID');
 id(lock.evaluatorId);strictTimestamp(lock.asOf);if(strictTimestamp(lock.lockedAt)>Date.now())throw new Error('BLIND_LOCK_TIME_INVALID');
 if(typeof lock.judgement!=='string'||!lock.judgement.trim()||Buffer.byteLength(lock.judgement)>16000||lock.exposure!==packet.exposure||lock.freshOutOfSampleVerified!==false||lock.softwareApproval!=='HOLD'||lock.investmentApproval!=='HOLD')throw new Error('BLIND_LOCK_SCHEMA_INVALID');
}

/** Research protocol. Availability proof and observer independence remain separate gates. */
export function prepareBlindPacket({caseId,asOf,records,rawArtifacts,alreadySeen=true}={}){
 id(caseId);strictTimestamp(asOf);const blockers=[];
 if(records?.length>10000)throw new Error('BLIND_RECORD_LIMIT');
 if(!Array.isArray(records)||!records.length)blockers.push('EVIDENCE_REQUIRED');
 for(const f of records||[]){
  if(!validateRecordEnvelope(f,{asOf,rawArtifacts}).valid)blockers.push('INVALID_OR_FUTURE_EVIDENCE');
  if(f.status!=='VERIFIED'||f.realDataVerified!==true||!Number.isFinite(f.value))blockers.push('VERIFIED_NONMISSING_OBSERVATION_REQUIRED');
  if(f.pitVerified!==true||f.availabilityConfidence!=='EXACT_PUBLICATION'||!f.pitEvidenceRef||!f.observedAt)blockers.push('POINT_IN_TIME_AND_OBSERVATION_PROOF_REQUIRED');
  if(f.periodEnd&&f.periodEnd>asOf.slice(0,10)||f.tradeDate&&f.tradeDate>asOf.slice(0,10))blockers.push('FUTURE_MEASUREMENT');
 }
 return seal({schema:'BLIND_OBJECTIVE_PACKET_V1',caseId,asOf,status:blockers.length?'HOLD':'PROTOCOL_READY',blockers:[...new Set(blockers)],exposure:alreadySeen?'KNOWN_DATA_REPLAY':'SELF_DECLARED_UNSEEN_NOT_INDEPENDENTLY_PROVEN',freshOutOfSampleVerified:false,observations:blockers.length?[]:records.map(f=>Object.fromEntries(fields.filter(k=>Object.hasOwn(f,k)).map(k=>[k,f[k]]))),actionAllowed:false,automaticTradingAllowed:false});
}
export function lockBlindJudgement({root,packet,caseInput,evaluatorId,judgement}={}){
 verify(packet);id(evaluatorId);
 if(!caseInput||prepareBlindPacket(caseInput).hash!==packet.hash)throw new Error('BLIND_SOURCE_REVALIDATION_REQUIRED');
 if(packet.schema!=='BLIND_OBJECTIVE_PACKET_V1'||packet.status!=='PROTOCOL_READY'||packet.blockers.length||!packet.observations.length)throw new Error('BLIND_EVIDENCE_GATE_HOLD');
 if(typeof judgement!=='string'||!judgement.trim()||Buffer.byteLength(judgement)>16000)throw new Error('BOUNDED_JUDGEMENT_REQUIRED');
 const p=dir(root,packet.caseId);if(fs.existsSync(path.join(p,'reveal.json')))throw new Error('OUTCOME_ALREADY_REVEALED');
 const lock=seal({schema:'BLIND_JUDGEMENT_LOCK_V1',caseId:packet.caseId,packetHash:packet.hash,asOf:packet.asOf,lockedAt:new Date().toISOString(),evaluatorId,judgement,exposure:packet.exposure,freshOutOfSampleVerified:false,softwareApproval:'HOLD',investmentApproval:'HOLD',integrityScope:'LOCAL_DIGEST_CHAIN_NOT_EXTERNAL_AUTHENTICATION'});
 exclusive(path.join(p,'packet.json'),packet);
 exclusive(path.join(p,'lock.json'),lock);return lock;
}
export function revealBlindOutcome({root,caseId,outcome,observedAt,availableAt,sourceSha256}={}){
 strictTimestamp(observedAt);strictTimestamp(availableAt);
 const p=dir(root,caseId),lock=read(path.join(p,'lock.json'));
 // A recomputed unkeyed hash is not proof that a real lock operation happened.
 // Require the persisted packet chain, and retain external/observer approval HOLD.
 const packet=read(path.join(p,'packet.json'));validateLock(lock,packet,caseId);
 if(Date.parse(observedAt)<=Date.parse(lock.asOf)||Date.parse(observedAt)>Date.parse(availableAt)||Date.parse(availableAt)>Date.now())throw new Error('OUTCOME_TIME_INVALID');
 if(!/^[a-f0-9]{64}$/.test(sourceSha256)||typeof outcome!=='string'||!outcome.trim()||Buffer.byteLength(outcome)>16000)throw new Error('BOUNDED_OUTCOME_AND_SOURCE_HASH_REQUIRED');
 const event=seal({schema:'BLIND_REVEAL_V1',caseId,lockHash:lock.hash,packetHash:lock.packetHash,revealedAt:new Date().toISOString(),observedAt,availableAt,sourceSha256,outcome,exposure:lock.exposure,freshOutOfSampleVerified:false,investmentApproval:'HOLD',integrityScope:'LOCAL_DIGEST_CHAIN_NOT_EXTERNAL_AUTHENTICATION',outcomeSourceVerification:'UNVERIFIED_HASH_REFERENCE_ONLY'});
 exclusive(path.join(p,'reveal.json'),event);return event;
}
