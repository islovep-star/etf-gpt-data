import fs from 'node:fs';
import crypto from 'node:crypto';
import {parseSourceSeries,latestFredRecord,latestVixRecord} from '../vendor/g02/g02_source_adapters.mjs';
const root=new URL('../data/g02_public/',import.meta.url),hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const collections={g02_public:root,g02_cboe_20260930:new URL('../data/g02_cboe_20260930/',import.meta.url)};
function collectionRoot(id='g02_public'){if(typeof id!=='string'||!Object.hasOwn(collections,id))throw Error('GLOBAL_RAW_COLLECTION_NOT_ALLOWED');return collections[id];}
export function bindGlobalSourceReferences(config){
 const copy=structuredClone(config),bound=new Map(),manifests=new Map();let boundRecords=0;
 for(const [domain,records] of Object.entries(copy?.domainEvidence??{})){
  if(!Array.isArray(records))throw Error('INVALID_GLOBAL_EVIDENCE');
  for(const record of records){const ref=record?.raw_reference;if(!ref)continue;
   if(!ref||typeof ref.localFile!=='string'||!/^([A-Z0-9_]+)\.csv$/.test(ref.localFile))throw Error('INVALID_GLOBAL_RAW_REFERENCE');
   const collection=ref.collection??'g02_public',sourceRoot=collectionRoot(collection),manifestBytes=fs.readFileSync(new URL('acquisition.json',sourceRoot)),acquisition=JSON.parse(manifestBytes);
   manifests.set(collection,hash(manifestBytes));
   const a=acquisition.artifacts.find(a=>a.ok&&a.localFile===ref.localFile);if(!a||a.sha256!==ref.sha256)throw Error('GLOBAL_RAW_REFERENCE_NOT_BOUND');
   const bytes=fs.readFileSync(new URL(a.localFile,sourceRoot));if(hash(bytes)!==a.sha256||bytes.length!==a.bytes)throw Error('GLOBAL_RAW_HASH_MISMATCH');
   if(Date.parse(record.retrieved_at)!==Date.parse(a.retrievedAt))throw Error('GLOBAL_RAW_RETRIEVAL_MISMATCH');
   const parsed=parseSourceSeries(bytes.toString('utf8'),a.name==='VIX'?'CBOE_VIX':'FRED');
   const expected=a.name==='VIX'?latestVixRecord(parsed,a.retrievedAt):latestFredRecord(a.name,parsed,a.retrievedAt);
   if(domain!==expected.domain)throw Error('GLOBAL_RAW_DOMAIN_MISMATCH');
   for(const key of ['record_id','metric_id','market','asset_or_sector','value','unit','observed_at','available_at','retrieved_at','frequency','evidence_class','source_tier','source_name','source_locator','status','cluster_id']){
    if(record[key]!==expected.record[key])throw Error('GLOBAL_RAW_VALUE_OR_MEANING_MISMATCH:'+key);
   }
   const reviewLocalPath='global_environment/raw/'+(collection==='g02_public'?'':collection+'/')+a.localFile;record.raw_reference={...ref,reviewLocalPath};bound.set(collection+'/'+a.localFile,{...a,...(collection==='g02_public'?{}:{collection}),reviewLocalPath});boundRecords++;
  }
 }
 const artifacts=[...bound.values()];return {config:copy,manifest:{schema:'G02_BOUND_PUBLIC_SOURCE_V1',status:artifacts.length?'LATEST_ROWS_BOUND_TO_CAPTURED_PUBLIC_CSV':'NO_BOUND_PUBLIC_SOURCES',boundRecords,artifacts,acquisitionManifestSha256:hash(fs.readFileSync(new URL('acquisition.json',root))),...(manifests.has('g02_cboe_20260930')?{collectionManifestSha256:Object.fromEntries(manifests)}:{}),directCollectorOperationVerified:false}};
}
export function readBoundGlobalSource(artifact){if(!artifact||typeof artifact.localFile!=='string'||!/^([A-Z0-9_]+)\.csv$/.test(artifact.localFile))throw Error('INVALID_GLOBAL_RAW_REFERENCE');const bytes=fs.readFileSync(new URL(artifact.localFile,collectionRoot(artifact.collection)));if(hash(bytes)!==artifact.sha256)throw Error('GLOBAL_RAW_HASH_MISMATCH');return bytes;}
