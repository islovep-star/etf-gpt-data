import {fetchDartCorpMap,fetchDartFinancial,fetchDartDisclosures,fetchKrxService,fetchSecCompanyData,fetchSec13F} from './provider_clients.mjs';
import {aggregateInvestorFlow,buildFlowFacts,calculateValuation} from './krx_adapter.mjs';
import {buildStockContext} from './stock_context_pipeline.mjs';
import {strictTimestamp} from './common.mjs';
import {buildEtfMetrics} from './etf_metrics.mjs';

export async function collectKrStockContext(config){
  const {asOf,identity,fetchImpl}=config;strictTimestamp(asOf,'asOf');
  if(identity.assetType==='ETF')throw new Error('USE_ETF_OBJECTIVE_CONTEXT');
  let corpCode=identity.corpCode,corpName=identity.instrumentName;
  const warnings=[];
  if(!corpCode){
    const map=await fetchDartCorpMap({apiKey:config.dartApiKey,availableAt:config.corpMapAvailableAt||asOf,fetchImpl});
    const hit=map.find(x=>x.symbol===identity.symbol);if(!hit)throw new Error('DART_CORP_CODE_NOT_FOUND');corpCode=hit.corpCode;corpName=corpName||hit.corpName;
  }
  const fundamentalFacts=[...(config.supplementalFundamentalFacts||[])];
  for(const r of config.dartReports||[]){
    const parsed=await fetchDartFinancial({apiKey:config.dartApiKey,corpCode,businessYear:r.businessYear,reportCode:r.reportCode,fsDiv:r.fsDiv||'CFS',fetchImpl,
      meta:{...r,symbol:identity.symbol,corpCode,businessYear:r.businessYear,reportCode:r.reportCode,fsDiv:r.fsDiv||'CFS',filedAt:r.filedAt,filingId:r.filingId,versionId:r.versionId}});
    fundamentalFacts.push(...parsed.facts);warnings.push(...parsed.warnings);
  }
  let events=[];
  if(config.disclosureRange){
    events=await fetchDartDisclosures({apiKey:config.dartApiKey,corpCode,startDate:config.disclosureRange.startDate,endDate:config.disclosureRange.endDate,fetchImpl,
      meta:{symbol:identity.symbol,corpCode,retrievedAt:config.disclosureRange.retrievedAt||asOf}});
  }
  let flowFacts=[];
  if(config.krxFlow){
    const rows=await fetchKrxService({...config.krxFlow,apiKey:config.krxApiKey,asOf,symbol:identity.symbol,fetchImpl,mode:'FLOW'});
    flowFacts=buildFlowFacts(aggregateInvestorFlow(rows,{asOf,instrumentId:identity.symbol,windows:config.krxFlow.windows||[5,20,60],expectedTradingDates:config.krxFlow.expectedTradingDates,institutionComponents:config.krxFlow.institutionComponents}),{instrumentId:identity.symbol,availableAt:config.krxFlow.availableAt,sourceRef:config.krxFlow.sourceRef||'KRX_INVESTOR_FLOW'});
  } else warnings.push('KRX_FLOW_NOT_CONFIGURED_OR_APPROVED');
  let valuationFacts=[];let valuation=null;
  if(config.valuationInput){const v=calculateValuation({...config.valuationInput,availableAt:config.valuationInput.availableAt||asOf,instrumentId:identity.symbol});valuation=v.current;valuationFacts=v.facts;}
  return buildStockContext({identity:{...identity,corpCode,instrumentName:corpName},asOf,financialOptions:config.financialOptions,evidenceBundle:config.evidenceBundle,technical:config.technical||null,fundamentalFacts,valuation:{current:valuation,history:config.financialOptions?.valuationComparison?.history||[],industry:config.financialOptions?.valuationComparison?.peers||null},valuationFacts,flowFacts,events,market:config.market||null,warnings,
    quality:{fundamental:{status:fundamentalFacts.length?'PARTIAL':'MISSING'},valuation:{status:valuationFacts.length?'PARTIAL':'MISSING'},flow:{status:flowFacts.length?'PARTIAL':'MISSING'},events:{status:events.length?'PARTIAL':'MISSING'},technical:{status:config.technical?'PARTIAL':'MISSING'},market:{status:config.market?'PARTIAL':'MISSING'},ownership:{status:'MISSING'}}});
}

export async function collectUsStockContext(config){
  const {asOf,identity,fetchImpl,userAgent}=config;strictTimestamp(asOf,'asOf');
  if(identity.assetType==='ETF')throw new Error('USE_ETF_OBJECTIVE_CONTEXT');
  const sec=await fetchSecCompanyData({cik:identity.cik,instrumentId:identity.symbol,asOf,userAgent,fetchImpl});
  const events=sec.filings.map(x=>({key:`event.${x.accessionNumber}`,type:x.form==='8-K'?'OTHER_MAJOR':'EARNINGS',eventDate:x.filingDate,title:x.form,filingId:x.accessionNumber,instrumentId:identity.symbol,availableAt:x.availableAt,sourceRef:x.sourceRef,versionId:x.versionId,status:'VERIFIED',facts:{reportDate:x.reportDate,primaryDocument:x.primaryDocument}}));
  const ownershipFacts=[];const warnings=[...(sec.warnings||[])];
  if(config.manager13F){
    const f=await fetchSec13F({...config.manager13F,userAgent,fetchImpl});
    ownershipFacts.push({key:`ownership.13f.${f.managerCik}.${f.periodEnd}`,period:f.periodEnd,value:f.holdings.length,unit:'HOLDING_COUNT',instrumentId:identity.symbol,availableAt:f.availableAt,sourceRef:f.sourceRef,versionId:f.accessionNumber,status:'VERIFIED',details:f});
    warnings.push(...f.limitations);
  }
  const valuation=config.valuationInput?calculateValuation({...config.valuationInput,currency:'USD',availableAt:config.valuationInput.availableAt||asOf,instrumentId:identity.symbol}):null;
  return buildStockContext({identity,asOf,financialOptions:config.financialOptions,evidenceBundle:config.evidenceBundle,technical:config.technical||null,fundamentalFacts:[...sec.fundamentalFacts,...(config.supplementalFundamentalFacts||[])],valuationFacts:valuation?.facts||[],valuation:{current:valuation?.current||null,history:config.financialOptions?.valuationComparison?.history||[],industry:config.financialOptions?.valuationComparison?.peers||null},ownershipFacts,events,market:config.market||null,warnings,
    quality:{fundamental:{status:(sec.fundamentalFacts.length||(config.supplementalFundamentalFacts||[]).length)?'PARTIAL':'MISSING'},ownership:{status:ownershipFacts.length?'PARTIAL':'MISSING'},events:{status:events.length?'PARTIAL':'MISSING'},technical:{status:config.technical?'PARTIAL':'MISSING'},valuation:{status:valuation?'PARTIAL':'MISSING'},flow:{status:'MISSING'},market:{status:config.market?'PARTIAL':'MISSING'}}});
}

export function collectEtfObjectiveContext(config){return buildEtfMetrics({...config.etfMetricsInput,instrumentId:config.identity.symbol,asOf:config.asOf});}
