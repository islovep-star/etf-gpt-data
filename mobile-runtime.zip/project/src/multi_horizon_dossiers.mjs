/** Read-only adapter over V9 calculations and their full source envelopes. */
import {sha256,strictTimestamp,hasText} from './common.mjs';
import {validateRecordEnvelope} from './data_record_contract.mjs';
export function actualTree(record,depth=0){
 if(!record||depth>12)return false;
 if(record.actualOrEstimate!==undefined&&record.actualOrEstimate!=='ACTUAL')return false;
 if(record.kind!==undefined&&!['OBSERVATION','ACTUAL'].includes(record.kind))return false;
 if(record.sourceVerification?.status==='CONFLICT'||['MISSING','BLOCKED','UNVERIFIED','PARTIAL'].includes(record.status))return false;
 return [...(record.inputs||[]),...(record.derivationInputs||[])].every(x=>actualTree(x,depth+1));
}
export function buildMultiHorizonDossiers(sample,{analysisAsOf=sample.asOf}={}){
 const cutoff=strictTimestamp(analysisAsOf);if(strictTimestamp(sample.asOf)>cutoff)throw Error('FUTURE_SOURCE_SNAPSHOT');
 const dossiers=sample.reviews.map(review=>{
  const id=review.instrumentId;
  const history=review.assetType==='STOCK'?[...(sample.contexts[id]?.fundamental.history||[]),...(sample.optionalHistory?.[id]||[])]:[...(sample.etfHistory||[]),...(sample.inputs.find(x=>x.etfMetricsInput?.instrumentId===id)?.sourceFacts||[])];
  const sourceRecords=[...new Map(history.filter(r=>r.instrumentId===id).map(r=>[sha256(r),r])).values()];
  const verified=r=>actualTree(r)&&r.value!==null&&Number.isFinite(r.value)&&r.status==='VERIFIED'&&validateRecordEnvelope(r,{asOf:analysisAsOf,rawArtifacts:sample.artifacts}).valid;
  const metrics=[],missing=[];
  const inspect=(node,path)=>{
   if(!node||typeof node!=='object')return;
   if(Object.hasOwn(node,'value')){
    const refs=node.inputs?.length?node.inputs:[node];
    const inputs=refs.map(ref=>sourceRecords.filter(r=>r.key===ref.key&&r.versionId===ref.versionId&&r.value===ref.value&&sha256(r.rawReference)===sha256(ref.rawReference)));
    const valid=Number.isFinite(node.value)&&actualTree(node)&&node.status==='VERIFIED'&&inputs.length>0&&inputs.every(matches=>matches.length===1&&verified(matches[0]));
    const metric={metricId:id+':'+path,key:node.key||path,value:valid?node.value:null,unit:node.unit||null,status:valid?'VERIFIED':'MISSING',reason:valid?null:node.reason||'ACTUAL_ORIGINAL_INPUTS_REQUIRED',formula:node.formula||'REPORTED',sourceRefs:valid?inputs.flatMap(rs=>rs.map(r=>({versionId:r.versionId,...r.rawReference}))):[],periodStart:node.periodStart||null,periodEnd:node.periodEnd||null,actualOrEstimate:'ACTUAL',interpretation:'NONE'};
    (valid?metrics:missing).push(metric);return;
   }
   for(const [k,v] of Object.entries(node))if(!['rawReference','rawReferences','sourceConflicts','pcf','basis'].includes(k))inspect(v,path?path+'.'+k:k);
  };
  if(review.assetType==='STOCK'){inspect(review.core,'core');if(review.optional)inspect(review.optional,'optional');}
  else {inspect(review.core.etfMetrics?.metrics,'etf');inspect(review.core.product?.reportedManagementFee,'reportedManagementFee');}
  return {instrumentId:id,instrumentName:review.instrumentName,assetType:review.assetType,sourcePacketHash:review.packetHash,sourceAsOf:sample.asOf,sourceScope:'BOUNDED_HISTORICAL_SOURCE_SAMPLE',metrics,missing,corporateEps:review.assetType==='ETF'?'NOT_APPLICABLE':'SEPARATE_BASIC_DILUTED_BASIS',fullHistoryRef:`history/${id}.json`,detailRef:`details/${id}.json`,safety:structuredClone(review.safety),technicalScoreContribution:0};
 });
 return {schema:'MULTI_HORIZON_DOSSIERS_V1',sourceAsOf:sample.asOf,dossiers,rawArtifactHashes:sample.artifacts.map(a=>({artifactId:a.artifactId,sha256:a.sha256})),interpretationBy:'GPT',technicalScoreContribution:0};
}

/** Project only bounded legacy summaries; never copy balances, quantities or secrets. */
export function projectLegacyReviewSummary(summary,{analysisAsOf}={}){
 const none={holdings:[],shortTerm:[],holdingsStatus:'NOT_PROVIDED',shortTermStatus:'EXISTING_V9_PATH_UNCHANGED_NOT_PRESENT_IN_SAMPLE'};
 if(summary===undefined||summary===null)return none;
 const fail=()=>{throw Error('LEGACY_CONTEXT_INVALID_OR_UNVERIFIED');};
 const keys=(x,allowed)=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).every(k=>allowed.includes(k));
 if(!keys(summary,['asOf','evidence','holdings','shortTerm'])||!Array.isArray(summary.holdings)||!Array.isArray(summary.shortTerm))fail();
 const cutoff=strictTimestamp(analysisAsOf);let at,available,retrieved;
 try{at=strictTimestamp(summary.asOf);available=strictTimestamp(summary.evidence?.availableAt);retrieved=strictTimestamp(summary.evidence?.retrievedAt);}catch{fail();}
 const e=summary.evidence;
 if(!keys(e,['status','sourceRef','sha256','availableAt','retrievedAt'])||at>cutoff||available>retrieved||retrieved>cutoff||e?.status!=='VERIFIED'||!hasText(e.sourceRef)||!/^[a-f0-9]{64}$/.test(e.sha256||''))fail();
 const seen=new Set();
 for(const [kind,rows] of [['holdings',summary.holdings],['shortTerm',summary.shortTerm]]){
  for(const row of rows){
   if(!keys(row,kind==='holdings'?['instrumentId','additionalAllocationBlocked']:['instrumentId','lossOrFailure'])||!hasText(row.instrumentId)||seen.has(kind+':'+row.instrumentId))fail();
   seen.add(kind+':'+row.instrumentId);
   const value=row[kind==='holdings'?'additionalAllocationBlocked':'lossOrFailure'];if(value!==undefined&&typeof value!=='boolean')fail();
  }
 }
 return {holdings:structuredClone(summary.holdings),shortTerm:structuredClone(summary.shortTerm),holdingsStatus:'PROVIDED_LOCAL_EVIDENCE_SUMMARY',shortTermStatus:'PROVIDED_LOCAL_EVIDENCE_SUMMARY',legacyEvidenceAsOf:summary.asOf,legacyEvidence:structuredClone(e),privateQuantitiesOmitted:true};
}
