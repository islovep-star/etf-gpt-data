import {strictTimestamp,strictDate,isObject} from './common.mjs';

const timeFields=new Set(['asOf','analysisAsOf','analysis_as_of','observedAt','observed_at','availableAt','available_at','retrievedAt','retrieved_at','timestamp','measurementAt']);
const dateFields=new Set(['date','tradeDate','periodEnd','measurementDate']);

/** Inspect declared observation metadata before copying legacy technical/market payloads.
 * Date-only fields remain dates; this does not manufacture publication time or PIT proof.
 */
export function assertObservationTimes(value,asOf,label='TECHNICAL',instrumentId=null){
 const cutoff=strictTimestamp(asOf),day=asOf.slice(0,10);let visited=0;
 const walk=(v,depth)=>{
  if(++visited>100000||depth>24)throw new Error(`${label}_METADATA_LIMIT`);
  if(Array.isArray(v)){for(const x of v)walk(x,depth+1);return;}
  if(!isObject(v))return;
  for(const [key,x] of Object.entries(v)){
   if(instrumentId!==null&&['instrumentId','instrument_id','symbol'].includes(key)&&x!==undefined&&String(x).toUpperCase()!==String(instrumentId).toUpperCase())throw new Error('TECHNICAL_INSTRUMENT_MISMATCH');
   if(x!==null&&x!==undefined&&(timeFields.has(key)||dateFields.has(key))){
    if(typeof x==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(x)){strictDate(x);if(x>day)throw new Error(`FUTURE_${label}_DATA`);}
    else if(strictTimestamp(x,key)>cutoff)throw new Error(`FUTURE_${label}_DATA`);
   }
   if(x&&typeof x==='object')walk(x,depth+1);
  }
 };
 walk(value,0);return true;
}

export function assertTechnicalScope(value,{asOf,instrumentId}={}){
 if(value===null||value===undefined)return true;
 if(!isObject(value))throw new Error('TECHNICAL_OBJECT_REQUIRED');
 for(const key of ['instrumentId','instrument_id','symbol'])if(value[key]!==undefined&&String(value[key]).toUpperCase()!==String(instrumentId).toUpperCase())throw new Error('TECHNICAL_INSTRUMENT_MISMATCH');
 return assertObservationTimes(value,asOf,'TECHNICAL',instrumentId);
}

export function assertEventScope(event,instrumentId){
 // An announced future event date is valid; its source availability is checked separately.
 for(const key of ['instrumentId','instrument_id','symbol'])if(event?.[key]!==undefined&&String(event[key]).toUpperCase()!==String(instrumentId).toUpperCase())throw new Error('EVENT_INSTRUMENT_MISMATCH');
 return true;
}
