import fs from 'node:fs';
import path from 'node:path';
import {parsePrivateSnapshot} from '../vendor/g03g09/g06_private_input.mjs';
/** Local-only sidecar. Contracts are supplied through a separate protected CLI path. */
export function loadPrivateReview({privateFile,contractFile,outputRoot,analysisAsOf}){
 if(!privateFile&&!contractFile)return null;
 if(!privateFile||!contractFile)throw new Error('PRIVATE_INPUT_AND_SEPARATE_CONTRACT_REQUIRED');
 for(const p of [privateFile,contractFile]){
  const resolved=fs.realpathSync(p),out=path.resolve(outputRoot);
  if(resolved===out||resolved.startsWith(out+path.sep))throw new Error('PRIVATE_INPUT_CANNOT_BE_IN_OUTPUT');
  if((fs.statSync(resolved).mode&0o077)!==0)throw new Error('PRIVATE_INPUT_OWNER_ONLY_PERMISSION_REQUIRED');
 }
 const data=JSON.parse(fs.readFileSync(privateFile)),contracts=JSON.parse(fs.readFileSync(contractFile));
 if(data.schema!=='PRIVATE_REVIEW_SIDECAR_V1'||contracts.schema!=='LOCAL_TRUSTED_REVIEW_CONTRACTS_V1'||!Array.isArray(data.packets)||!Array.isArray(contracts.contracts))throw new Error('PRIVATE_SCHEMA_REQUIRED');
 if(data.snapshot)parsePrivateSnapshot({...data.snapshot,analysis_as_of:analysisAsOf});
 const seen=new Set();return data.packets.map(packet=>{
  if(packet.asOf!==analysisAsOf)throw new Error('PRIVATE_REVIEW_TIME_MISMATCH');
  const id=packet.intent?.instrumentId;if(!id||seen.has(id))throw new Error('PRIVATE_REVIEW_TARGET_REQUIRED_OR_DUPLICATE');seen.add(id);
  const matches=contracts.contracts.filter(c=>c.targetInstrumentId===id&&c.scopeId===packet.portfolio?.scopeId);
  if(matches.length!==1)throw new Error('PRIVATE_CONTRACT_SCOPE_MISMATCH');
  return {instrumentId:id,reviewPacket:packet,reviewContract:matches[0]};
 });
}
