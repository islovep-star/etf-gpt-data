import {hasText,isObject,isFiniteNumber,strictTimestamp,selectLatestAvailable,sha256,round,factIdentity} from './common.mjs';
import {growthChange} from './financial_contract.mjs';
import {assertTechnicalScope,assertObservationTimes,assertEventScope} from './temporal_scope.mjs';

export const STOCK_CONTEXT_SCHEMA='STOCK_CONTEXT_V1';
export const PACKET_SCHEMA='GPT_STOCK_ANALYSIS_PACKET_V1';

export function emptyStockContext({symbol,market='KR',instrumentName=null,corpCode=null,cik=null,asOf}){
  strictTimestamp(asOf,'asOf');
  if(!hasText(symbol))throw new Error('SYMBOL_REQUIRED');
  return {
    schemaVersion:STOCK_CONTEXT_SCHEMA,
    identity:{symbol:String(symbol).toUpperCase(),market,instrumentName,corpCode,cik},
    asOf,
    technical:null,
    fundamental:{quarterly:[],annual:[],cashFlow:[],facts:[]},
    valuation:{current:null,history:[],industry:null,facts:[]},
    flow:{foreign:[],institution:[],ownershipPct:[],facts:[]},
    ownership:{largeHolders:[],insiders:[],controllingHolder:null,facts:[]},
    events:[],
    market:null,
    dataQuality:{status:'PARTIAL',sections:{},blockers:[],warnings:[]},
    meta:{availableAt:null,sources:[],warnings:[],missing:[]},
    automaticTradingAllowed:false,
    judgement:'NONE'
  };
}

function validateFacts(facts,asOf,section,{requireValue=true}={}){
  const blockers=[];const cutoff=Date.parse(asOf);
  for(const f of facts||[]){
    if(!isObject(f)||!hasText(f.key)||!hasText(f.availableAt)||!hasText(f.sourceRef)){blockers.push(`${section}:FACT_METADATA_REQUIRED`);continue;}
    let t;try{t=strictTimestamp(f.availableAt);}catch{blockers.push(`${section}:INVALID_AVAILABLE_AT`);}if(t>cutoff)blockers.push(`${section}:LOOKAHEAD_FACT`);
    const explicitMissing=['MISSING','BLOCKED','NOT_APPLICABLE'].includes(f.status)&&f.value===null;
    if(requireValue&&!explicitMissing&&(f.value===null||f.value===undefined||((typeof f.value==='number')&&!Number.isFinite(f.value))))blockers.push(`${section}:INVALID_FACT_VALUE`);
  }
  return blockers;
}

export function validateStockContext(ctx){
  const blockers=[],warnings=[];
  if(!isObject(ctx)||ctx.schemaVersion!==STOCK_CONTEXT_SCHEMA)return {valid:false,blockers:['STOCK_CONTEXT_SCHEMA_REQUIRED'],warnings};
  if(!hasText(ctx.identity?.symbol)||!hasText(ctx.identity?.market))blockers.push('IDENTITY_REQUIRED');
  try{strictTimestamp(ctx.asOf,'context.asOf');}catch(e){blockers.push(e.message);}
  try{assertTechnicalScope(ctx.technical,{asOf:ctx.asOf,instrumentId:ctx.identity?.symbol});assertObservationTimes(ctx.market,ctx.asOf,'MARKET');for(const event of ctx.events||[])assertEventScope(event,ctx.identity?.symbol);}catch(e){blockers.push(e.message);}
  for(const section of ['fundamental','valuation','flow','ownership']){
    if(!isObject(ctx[section]))blockers.push(`${section.toUpperCase()}_OBJECT_REQUIRED`);
    blockers.push(...validateFacts(ctx[section]?.facts,ctx.asOf,section));
  }
  if(!Array.isArray(ctx.events))blockers.push('EVENTS_ARRAY_REQUIRED');
  blockers.push(...validateFacts(ctx.events,ctx.asOf,'events',{requireValue:false}));
  if(ctx.automaticTradingAllowed!==false)blockers.push('AUTOMATIC_TRADING_MUST_BE_FALSE');
  if(ctx.judgement!=='NONE')blockers.push('PROGRAM_JUDGEMENT_FORBIDDEN');
  if(ctx.dataQuality?.status!=='VERIFIED')warnings.push('DATA_QUALITY_NOT_FULLY_VERIFIED');
  return {valid:blockers.length===0,blockers:[...new Set(blockers)],warnings:[...new Set(warnings)]};
}

function latestFacts(facts,asOf){return selectLatestAvailable(facts||[],asOf,factIdentity).selected;}

function seriesFromFacts(facts,prefix){
  return facts.filter(x=>x.key===prefix||x.key.startsWith(prefix+'.')).sort((a,b)=>String(a.periodEnd||a.period||'').localeCompare(String(b.periodEnd||b.period||''))).map(x=>({...x}));
}

export function buildCompactStockPacket(ctx,{maxEvents=20,maxSeries=8}={}){
  const check=validateStockContext(ctx);if(!check.valid)throw new Error(`INVALID_STOCK_CONTEXT:${check.blockers.join(',')}`);
  const fundamentalFacts=latestFacts(ctx.fundamental.facts,ctx.asOf);
  const valuationFacts=latestFacts(ctx.valuation.facts,ctx.asOf);
  const flowFacts=latestFacts(ctx.flow.facts,ctx.asOf);
  const ownershipFacts=latestFacts(ctx.ownership.facts,ctx.asOf);
  const events=(ctx.events||[]).filter(x=>Date.parse(x.availableAt)<=Date.parse(ctx.asOf)).sort((a,b)=>Date.parse(b.availableAt)-Date.parse(a.availableAt)).slice(0,maxEvents);
  const packet={
    schemaVersion:PACKET_SCHEMA,
    asOf:ctx.asOf,
    identity:ctx.identity,
    technical:ctx.technical,
    fundamental:{
      revenue:seriesFromFacts(fundamentalFacts,'fundamental.revenue').slice(-maxSeries),
      operatingIncome:seriesFromFacts(fundamentalFacts,'fundamental.operatingIncome').slice(-maxSeries),
      netIncome:seriesFromFacts(fundamentalFacts,'fundamental.netIncome').slice(-maxSeries),
      operatingCashFlow:seriesFromFacts(fundamentalFacts,'fundamental.operatingCashFlow').slice(-maxSeries),
      other:fundamentalFacts.filter(x=>!/^fundamental\.(revenue|operatingIncome|netIncome|operatingCashFlow)(\.|$)/.test(x.key)),
      metrics:ctx.fundamental.metrics||null,
      revisionHistory:ctx.fundamental.history||[],
      seriesLimit:maxSeries
    },
    valuation:valuationFacts,
    valuationComparisons:ctx.valuation.comparisons||null,
    flow:flowFacts,
    ownership:ownershipFacts,
    events,
    market:ctx.market,
    dataQuality:ctx.dataQuality,
    evidence:ctx.meta?.evidence||null,
    missing:ctx.meta?.missing||[],warnings:[...(ctx.meta?.warnings||[]),...check.warnings],
    decisionAuthority:'GPT_REVIEW_ONLY',automaticTradingAllowed:false,judgement:'NONE'
  };
  return {...packet,packetHash:sha256(packet)};
}

export function deriveYoY(current,previous){
  return growthChange(current,previous);
}
