import {hasText,isFiniteNumber as finite,round,strictTimestamp,strictDate,stableStringify} from './common.mjs';
import {financialSelection,scopeCompatible,metric,calculateEps,growthChange,dayCount,nextDate,previousDate,eligibleFact} from './financial_contract.mjs';

const ADDITIVE=new Set(['revenue','operatingIncome','netIncome','profitCommon','operatingCashFlow','capexPpe','capexTotal','interestExpense','ebit','stockBasedCompensation','dividendsPaid','repurchases']);
const groupKey=f=>[f.periodStart,f.periodEnd,f.periodKind,f.instrumentId,f.currency,f.fsDiv,f.accountingBasis].join('|');
const comparable=(a,b,opts={})=>scopeCompatible([a,b],opts)||((a?.comparisonBasis||b?.comparisonBasis)&&a?.comparisonBasis!==b?.comparisonBasis?'COMPARISON_BASIS_MISMATCH':null);
export function deriveTtm(quarters){
 const q=[...(quarters||[])].sort((a,b)=>String(a.periodStart).localeCompare(String(b.periodStart)));
 let reason=q.length!==4?'FOUR_QUARTERS_REQUIRED':scopeCompatible(q,{samePeriod:false});
 if(!reason&&q.some(f=>!ADDITIVE.has(f.account)||f.account!==q[0].account||f.periodKind!=='QUARTER'||f.cumulative||dayCount(f)<70||dayCount(f)>110))reason='ADDITIVE_STANDALONE_QUARTERS_REQUIRED';
 if(!reason&&q.some((f,i)=>i&&nextDate(q[i-1].periodEnd)!==f.periodStart))reason='QUARTER_GAP_OR_OVERLAP';
 if(!reason&&(dayCount({periodStart:q[0].periodStart,periodEnd:q[3].periodEnd})<330||dayCount({periodStart:q[0].periodStart,periodEnd:q[3].periodEnd})>380))reason='TTM_LENGTH_MISMATCH';
 if(!reason&&q.some(f=>(f.comparisonBasis||null)!==(q[0].comparisonBasis||null)))reason='COMPARISON_BASIS_MISMATCH';
 const m=metric(`ttm.${q[0]?.account||'unknown'}`,reason?null:q.reduce((a,f)=>a+f.value,0),q,{unit:q[0]?.unit,reason,formula:'sum of four contiguous standalone quarters'});
 return {...m,account:q[0]?.account,instrumentId:q[0]?.instrumentId,currency:q[0]?.currency,fsDiv:q[0]?.fsDiv,accountingBasis:q[0]?.accountingBasis,actualOrEstimate:'ACTUAL',periodKind:'TTM',periodStart:q[0]?.periodStart,periodEnd:q.at(-1)?.periodEnd,cumulative:false,versionId:reason?null:`TTM:${q.map(f=>f.versionId).join(':')}`,sourceRef:'DERIVED_FROM_REPORTED_FACTS',realDataVerified:m.sourceStatus==='VERIFIED',comparisonBasis:q[0]?.comparisonBasis};
}
function annualPrior(a,b){
 if(comparable(a,b,{samePeriod:false})||a.account!==b.account||a.periodKind!==b.periodKind||a.shareAdjustmentBasis!==b.shareAdjustmentBasis)return false;
 if(/Eps$/.test(a.account)&&!hasText(a.shareAdjustmentBasis))return false;
 const shift=d=>`${Number(d.slice(0,4))-1}${d.slice(4)}`;
 if(a.periodStart&&shift(a.periodStart)===b.periodStart&&shift(a.periodEnd)===b.periodEnd)return true;
 // Issuer-defined fiscal quarters may end on different calendar dates (52/53 weeks).
 return hasText(a.fiscalCalendarId)&&a.fiscalCalendarId===b.fiscalCalendarId&&
  hasText(a.periodAlignmentEvidence)&&hasText(b.periodAlignmentEvidence)&&
  Number.isInteger(a.fiscalYear)&&a.fiscalYear===b.fiscalYear+1&&
  (a.periodKind==='ANNUAL'||Number.isInteger(a.fiscalQuarter)&&a.fiscalQuarter>=1&&a.fiscalQuarter<=4&&a.fiscalQuarter===b.fiscalQuarter)&&
  Math.abs(dayCount(a)-dayCount(b))<=7&&Math.abs((Date.parse(a.periodEnd)-Date.parse(b.periodEnd))/86400000-365)<=7;
}
function pairMetric(key,a,b,fn,{unit='PCT',positiveDenominator=false,formula}={}){
 let reason=comparable(a,b);if(!reason&&positiveDenominator&&b.value<=0)reason='NONPOSITIVE_DENOMINATOR';
 return metric(key,reason?null:fn(a.value,b.value),[a,b],{unit,reason,formula});
}
export function compareValuations({current,history=[],peers=[],asOf}){
 strictTimestamp(asOf);const required=['metric','basis','currency','unit','accountingBasis','fsDiv','sectorClassification','sector','methodology'];
 const comparableRecord=x=>eligibleFact(x,asOf)&&required.every(k=>hasText(x[k]))&&finite(x.value)&&x.value>0&&hasText(x.observationDate)&&/^\d{4}-\d{2}-\d{2}$/.test(x.observationDate)&&Number.isFinite(Date.parse(x.observationDate))&&new Date(Date.parse(x.observationDate)).toISOString().slice(0,10)===x.observationDate&&x.observationDate<=asOf.slice(0,10)&&['ACTUAL','ESTIMATE'].includes(x.actualOrEstimate)&&x.actualOrEstimate===current?.actualOrEstimate;
 if(!current||!comparableRecord(current))return {status:'MISSING',reason:'CURRENT_VALUATION_BASIS_REQUIRED',history:null,industry:null,excluded:[...history,...peers]};
 const same=x=>comparableRecord(x)&&required.every(k=>x[k]===current[k]);
 const hist=history.filter(x=>same(x)&&x.instrumentId===current.instrumentId&&x.observationDate<current.observationDate);
 const peer=peers.filter(x=>same(x)&&x.instrumentId!==current.instrumentId&&x.observationDate===current.observationDate);
 const summarize=(rows,type)=>{
  const unique=new Map();let conflict=false;
  for(const r of rows){const key=type==='history'?r.observationDate:r.instrumentId;const prev=unique.get(key);if(prev&&prev.value!==r.value)conflict=true;else unique.set(key,r);}
  const x=[...unique.values()],sorted=x.map(f=>f.value).sort((a,b)=>a-b),n=sorted.length;
  if(!n||conflict)return {status:conflict?'BLOCKED':'MISSING',sampleSize:n,median:null,reason:conflict?'CONFLICTING_COMPARABLE_RECORDS':'NO_COMPARABLE_RECORDS',records:x};
  const median=n%2?sorted[(n-1)/2]:(sorted[n/2-1]+sorted[n/2])/2;
  return {status:x.every(f=>f.realDataVerified===true)&&current.realDataVerified===true?'VERIFIED':'PARTIAL',calculationStatus:'CALCULATED',sampleSize:n,median,currentVsMedianPct:round((current.value/median-1)*100,6),historicalPercentile:type==='history'?round(sorted.filter(v=>v<=current.value).length/n*100,6):null,records:x};
 };
 return {status:'PARTIAL',current,history:summarize(hist,'history'),industry:summarize(peer,'peers'),excluded:[...history,...peers].filter(x=>!hist.includes(x)&&!peer.includes(x)),interpretation:'GPT_REVIEW_ONLY'};
}
export function buildCorporateMetrics({facts=[],asOf,instrumentId,industryClass=null,valuationComparison=null}={}){
 strictTimestamp(asOf);const selection=financialSelection(facts,{asOf,instrumentId});
 const selected=selection.selected.filter(f=>!f.periodEnd||f.periodEnd<=asOf.slice(0,10));
 const groups=new Map();for(const f of selected.filter(f=>f.periodKind!=='INSTANT')){const k=groupKey(f);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(f);}
 const ttm=[];
 for(const account of ADDITIVE){
  const scopes=new Map();for(const f of selected.filter(f=>f.account===account&&f.periodKind==='QUARTER')){const k=[f.instrumentId,f.currency,f.fsDiv,f.accountingBasis,f.comparisonBasis].join('|');if(!scopes.has(k))scopes.set(k,[]);scopes.get(k).push(f);}
  for(const rows of scopes.values()){rows.sort((a,b)=>a.periodEnd.localeCompare(b.periodEnd));if(rows.length>=4){const m=deriveTtm(rows.slice(-4));ttm.push(m);if(m.value!==null){const k=groupKey(m);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(m);}}}
 }
 const epsReconciliation=f=>{
  if(!f||!['basicEps','dilutedEps'].includes(f.account))return null;
  const get=account=>{const rows=selected.filter(x=>groupKey(x)===groupKey(f)&&x.account===account);return rows.length===1?rows[0]:null;};
  const all=calculateEps({reportedBasic:f.account==='basicEps'?f:null,reportedDiluted:f.account==='dilutedEps'?f:null,profitCommon:get('profitCommon'),weightedBasicShares:get('weightedBasicShares'),dilutedNumerator:get('dilutedEpsNumerator'),weightedDilutedShares:get('weightedDilutedShares'),asOf});
  return all[f.account==='basicEps'?'basic':'diluted'].reconciliation||null;
 };
 const growth=selected.filter(f=>['revenue','operatingIncome','netIncome','basicEps','dilutedEps'].includes(f.account)&&['QUARTER','ANNUAL'].includes(f.periodKind)).map(f=>{
  const candidates=selected.filter(p=>annualPrior(f,p));const p=candidates.length===1?candidates[0]:null;
  const reconciliations=[epsReconciliation(f),epsReconciliation(p)].filter(Boolean);
  if(reconciliations.some(x=>x.status==='CONFLICT'))return metric(`${f.account}.yoyPct`,null,[f,p],{unit:'PCT',reason:'EPS_SOURCE_RECONCILIATION_CONFLICT',details:{periodStart:f.periodStart,periodEnd:f.periodEnd,periodKind:f.periodKind,change:growthChange(null,null),reconciliations}});
  const change=growthChange(f.value,p?.value);
  return {...metric(`${f.account}.yoyPct`,change.value,[f,p],{unit:'PCT',reason:p?null:'COMPARABLE_PRIOR_REQUIRED',formula:'(current / positive prior - 1) * 100',details:{periodStart:f.periodStart,periodEnd:f.periodEnd,periodKind:f.periodKind,change,comparisonDays:p?{current:dayCount(f),previous:dayCount(p),lengthAdjusted:false,warning:dayCount(f)!==dayCount(p)?'UNEQUAL_FISCAL_PERIOD_LENGTH':null}:null}}),calculationStatus:p?'CALCULATED':'UNAVAILABLE'};
 });
 const periods=[];
 for(const rows of groups.values()){
  const ref=rows[0],get=account=>{const x=rows.filter(f=>f.account===account);return x.length===1?x[0]:null;};
  const instant=(account,date)=>{const x=selected.filter(f=>f.account===account&&f.periodKind==='INSTANT'&&f.periodEnd===date&&!scopeCompatible([ref,f],{samePeriod:false,sameUnit:false}));return x.length===1?x[0]:null;};
  const revenue=get('revenue'),op=get('operatingIncome'),income=get('netIncome'),ocf=get('operatingCashFlow'),interest=get('interestExpense'),profitCommon=get('profitCommon');
  const metrics={
   operatingMarginPct:pairMetric('operatingMarginPct',op,revenue,(a,b)=>a/b*100,{positiveDenominator:true,formula:'operating income / revenue * 100'}),
   netMarginPct:pairMetric('netMarginPct',income,revenue,(a,b)=>a/b*100,{positiveDenominator:true,formula:'net income / revenue * 100'}),
   ocfMarginPct:pairMetric('ocfMarginPct',ocf,revenue,(a,b)=>a/b*100,{positiveDenominator:true,formula:'operating cash flow / revenue * 100'}),
   cashEarningsGap:pairMetric('cashEarningsGap',ocf,income,(a,b)=>a-b,{unit:ref.currency,formula:'operating cash flow - net income'}),
   operatingProfitInterestCoverage:pairMetric('operatingProfitInterestCoverage',op,interest,(a,b)=>a/b,{unit:'MULTIPLE',positiveDenominator:true,formula:'operating income / interest expense; not EBIT coverage'}),
   ebitInterestCoverage:pairMetric('ebitInterestCoverage',get('ebit'),interest,(a,b)=>a/b,{unit:'MULTIPLE',positiveDenominator:true,formula:'explicit EBIT / interest expense'})
  };
  for(const [name,account,definition] of [['fcfPpe','capexPpe','OCF_MINUS_PPE_CASH_PURCHASES'],['fcfTotal','capexTotal','OCF_MINUS_PPE_AND_INTANGIBLE_CASH_PURCHASES']]){
   const capex=get(account);let reason=comparable(ocf,capex);
   if(!reason&&capex.value<0)reason='CAPEX_CASH_OUTFLOW_MUST_BE_POSITIVE';
   if(!reason&&account==='capexTotal'&&capex.definition!=='PPE_AND_INTANGIBLE_CASH_PURCHASES')reason='CAPEX_DEFINITION_REQUIRED';
   metrics[name]=metric(name,reason?null:ocf.value-capex.value,[ocf,capex],{unit:ref.currency,reason,formula:definition,details:{nonGaap:true,discretionaryCashClaim:false}});
  }
  const cash=instant('cash',ref.periodEnd),debt=instant('interestBearingDebt',ref.periodEnd),currentDebt=instant('currentDebt',ref.periodEnd);
  let debtReason=comparable(debt,cash);if(!debtReason&&(!hasText(debt.definition)||debt.value<0||cash.value<0))debtReason='DEBT_DEFINITION_OR_SIGN_REQUIRED';
  metrics.netDebt=metric('netDebt',debtReason?null:debt.value-cash.value,[debt,cash],{unit:ref.currency,reason:debtReason,formula:'explicit interest-bearing debt - cash and cash equivalents'});
  metrics.cashToCurrentDebt=pairMetric('cashToCurrentDebt',cash,currentDebt,(a,b)=>a/b,{unit:'MULTIPLE',positiveDenominator:true,formula:'cash / current interest-bearing debt'});
  const cfads=get('cashAvailableForDebtService'),service=get('debtServiceDue');
  metrics.debtServiceCoverage=pairMetric('debtServiceCoverage',cfads,service,(a,b)=>a/b,{unit:'MULTIPLE',positiveDenominator:true,formula:'explicit cash available for debt service / principal and interest due over the same period'});
  if(!hasText(cfads?.definition)||service?.definition!=='PRINCIPAL_AND_INTEREST_DUE')metrics.debtServiceCoverage=metric('debtServiceCoverage',null,[cfads,service],{reason:'CFADS_AND_DEBT_SERVICE_DEFINITIONS_REQUIRED'});
  const startEquity=ref.periodStart?instant('commonEquity',previousDate(ref.periodStart)):null,endEquity=instant('commonEquity',ref.periodEnd);
  let roeReason=scopeCompatible([profitCommon,startEquity,endEquity],{samePeriod:false});
  if(!roeReason&&(startEquity.value<=0||endEquity.value<=0))roeReason='NONPOSITIVE_COMMON_EQUITY';
  metrics.roePct=metric('roePct',roeReason?null:profitCommon.value/((startEquity.value+endEquity.value)/2)*100,[profitCommon,startEquity,endEquity],{unit:'PCT',reason:roeReason,formula:'profit attributable to common / average beginning and ending common equity * 100',details:{annualized:false,returnPeriod:ref.periodKind}});
  const tax=get('effectiveTaxRate'),startIC=ref.periodStart?instant('investedCapital',previousDate(ref.periodStart)):null,endIC=instant('investedCapital',ref.periodEnd);
  let roicReason=industryClass==='NON_FINANCIAL'?scopeCompatible([op,tax,startIC,endIC],{samePeriod:false,sameUnit:false}):'NOT_APPLICABLE';
  if(!roicReason&&(tax.unit!=='FRACTION'||tax.value<0||tax.value>1||tax.taxBasis!=='EXPLICIT_EFFECTIVE_TAX_RATE'||startIC.value<=0||endIC.value<=0||startIC.unit!==op.currency||endIC.unit!==op.currency||!hasText(startIC.definition)||startIC.definition!==endIC.definition))roicReason='ROIC_DEFINITION_OR_DENOMINATOR_REQUIRED';
  metrics.roicPct=metric('roicPct',roicReason?null:op.value*(1-tax.value)/((startIC.value+endIC.value)/2)*100,[op,tax,startIC,endIC],{unit:'PCT',reason:roicReason,formula:'operating income * (1 - explicit effective tax rate) / average defined invested capital * 100',details:{annualized:false,industryClass,returnPeriod:ref.periodKind,definition:startIC?.definition||null}});
  const basicShares=get('weightedBasicShares'),dilutedShares=get('weightedDilutedShares');
  metrics.dilutedShareIncrementPct=pairMetric('dilutedShareIncrementPct',dilutedShares,basicShares,(a,b)=>a>=b?(a/b-1)*100:NaN,{positiveDenominator:true,formula:'(weighted diluted shares / weighted basic shares - 1) * 100'});
  if(basicShares?.shareAdjustmentBasis!==dilutedShares?.shareAdjustmentBasis||!basicShares?.shareAdjustmentBasis)metrics.dilutedShareIncrementPct=metric('dilutedShareIncrementPct',null,[basicShares,dilutedShares],{reason:'SHARE_ADJUSTMENT_BASIS_REQUIRED'});
  const div=get('dividendsPaid'),fcf=metrics.fcfPpe;
  metrics.fcfPpeDividendCoverage=metric('fcfPpeDividendCoverage',fcf.value!==null&&div?.value>0&&!comparable(ocf,div)?fcf.value/div.value:null,[...fcf.inputs,div],{unit:'MULTIPLE',formula:'OCF less PPE purchases / cash dividends paid',reason:!div?'DIVIDENDS_REQUIRED':div.value<=0?'NONPOSITIVE_DENOMINATOR':null});
  const eps=calculateEps({reportedBasic:get('basicEps'),reportedDiluted:get('dilutedEps'),profitCommon,weightedBasicShares:basicShares,dilutedNumerator:get('dilutedEpsNumerator'),weightedDilutedShares:dilutedShares,asOf});
  periods.push({periodStart:ref.periodStart,periodEnd:ref.periodEnd,periodKind:ref.periodKind,currency:ref.currency,fsDiv:ref.fsDiv,metrics,eps,
   shareFacts:rows.filter(f=>['weightedBasicShares','weightedDilutedShares','stockBasedCompensation','repurchases','issuance','sharesCancelled'].includes(f.account)),reportedFcf:get('reportedFcf')});
 }
 const outstanding=selected.filter(f=>f.account==='sharesOutstanding'&&f.periodKind==='INSTANT').sort((a,b)=>a.periodEnd.localeCompare(b.periodEnd));
 const shareChanges=outstanding.map((f,i)=>{
  const prior=outstanding.slice(0,i).reverse().find(p=>!comparable(f,p,{samePeriod:false})&&p.shareAdjustmentBasis===f.shareAdjustmentBasis&&hasText(f.shareAdjustmentBasis));
  return metric('outstandingShareChangePct',prior&&prior.value>0?(f.value/prior.value-1)*100:null,[f,prior],{unit:'PCT',reason:prior?null:'COMPARABLE_SHARE_BASIS_REQUIRED',formula:'(current outstanding / prior outstanding - 1) * 100',details:{shareCountChangeIsNotDilutionConclusion:true}});
 });
 return {schema:'CORPORATE_OBJECTIVE_METRICS_V1',asOf,instrumentId,status:selection.conflicts.length?'BLOCKED':selected.length?'PARTIAL':'MISSING',periods:periods.sort((a,b)=>String(a.periodEnd).localeCompare(String(b.periodEnd))),growth,ttm,shareChanges,
  valuationComparisons:valuationComparison?compareValuations({...valuationComparison,asOf}):{status:'MISSING',reason:'COMPARABLE_VALUATION_INPUT_REQUIRED'},
  conflicts:selection.conflicts,quarantined:selection.quarantined,sourceHistory:selection.history,objectiveDataOnly:true,decisionAuthority:'GPT_REVIEW_ONLY',technicalScoreContribution:0,judgement:'NONE'};
}
