import {buildCorporateMetrics} from './corporate_metrics.mjs';
import {metric,scopeCompatible,financialSelection} from './financial_contract.mjs';
import {validateRecordEnvelope} from './data_record_contract.mjs';
import {conciseEvidence} from './core_review.mjs';
const missing=reason=>({value:null,status:'MISSING',calculationStatus:'UNAVAILABLE',reason,inputs:[]});

/** Optional objective data only. Never promotes the core, P0, or an action verdict. */
export function buildOptionalExtensions({assetType,instrumentId,asOf,facts=[],rawArtifacts=[],industryClass=null}={}){
 if(assetType!=='STOCK')return {schema:'OPTIONAL_OBJECTIVES_V1',status:'NOT_APPLICABLE',reason:'CORPORATE_RETURN_METRICS_DO_NOT_APPLY_TO_ETF',technicalScoreContribution:0};
 const rejected=facts.filter(f=>f.instrumentId!==instrumentId||!validateRecordEnvelope(f,{asOf,rawArtifacts}).valid);
 if(rejected.length)return {schema:'OPTIONAL_OBJECTIVES_V1',status:'BLOCKED',reason:'OPTIONAL_SOURCE_SCOPE_OR_EVIDENCE_INVALID',blockedRecordCount:rejected.length,coreUnaffected:true,technicalScoreContribution:0};
 const all=buildCorporateMetrics({facts,asOf,instrumentId,industryClass});
 if(all.conflicts.length)return {schema:'OPTIONAL_OBJECTIVES_V1',status:'BLOCKED',reason:'CONFLICTING_OPTIONAL_FACTS',coreUnaffected:true,technicalScoreContribution:0};
 const annual=all.periods.filter(p=>p.periodKind==='ANNUAL').at(-1);
 const selected=financialSelection(facts,{asOf,instrumentId}).selected.filter(f=>f.periodStart===annual?.periodStart&&f.periodEnd===annual?.periodEnd&&f.periodKind==='ANNUAL');
 const one=account=>{const a=selected.filter(f=>f.account===account);return a.length===1?a[0]:null;};
 const revenue=one('revenue');
 const accounts=['revenueIphone','revenueMac','revenueIpad','revenueWearables','revenueServices'];
 const parts=accounts.map(one);
 let reason=scopeCompatible([revenue,...parts]);
 if(!reason&&(revenue.value<=0||parts.some(f=>f.value<0)||parts.reduce((s,f)=>s+f.value,0)!==revenue.value))reason='COMPLETE_RECONCILED_REVENUE_BREAKDOWN_REQUIRED';
 const concentration=Object.fromEntries(accounts.map((account,i)=>[account+'Pct',metric(account+'Pct',reason?null:parts[i].value/revenue.value*100,[parts[i],revenue],{unit:'PCT',reason,formula:'reported product or service net sales / same-period total net sales * 100'})]));
 return conciseEvidence({schema:'OPTIONAL_OBJECTIVES_V1',status:'BOUNDED_RESEARCH_ONLY',period:annual?{start:annual.periodStart,end:annual.periodEnd,kind:annual.periodKind}:null,
  returns:{roePct:annual?.metrics.roePct||missing('COMMON_PROFIT_AND_AVERAGE_COMMON_EQUITY_REQUIRED'),roicPct:!industryClass?missing('INDUSTRY_CLASSIFICATION_REQUIRED'):annual?.metrics.roicPct||missing('EXPLICIT_ROIC_DEFINITION_REQUIRED')},
  concentration,valuation:all.valuationComparisons,
  deferred:{ownership13F:missing('MANAGER_HOLDINGS_ARE_DELAYED_POSITION_DISCLOSURES_NOT_REALTIME_FLOWS'),largeShareholders:missing('NO_REVIEWED_LARGE_HOLDING_SOURCE'),insiderTransactions:missing('NO_REVIEWED_INSIDER_SOURCE'),detailedFlow:missing('NO_REVIEWED_DIRECT_FLOW_SOURCE'),consensusEstimates:missing('NO_LICENSED_PUBLISHED_ASOF_ESTIMATE_HISTORY')},
  warnings:['HISTORICAL_SAMPLE_NOT_CURRENT','ROE_CAN_BE_HIGH_WITH_BUYBACK_REDUCED_EQUITY','ROIC_DEFINITION_EQUITY_PLUS_CP_AND_TERM_DEBT_MINUS_CASH_EXCLUDES_LEASES_AND_DOES_NOT_DEDUCT_MARKETABLE_SECURITIES','ACTUAL_EFFECTIVE_TAX_INCLUDES_ONE_TIME_ITEMS_NOT_NORMALIZED_TAX','NO_STANDARDIZED_PEER_OR_HISTORICAL_VALUATION_CLAIM','CONCENTRATION_DESCRIBES_REVENUE_NOT_AN_AUTOMATIC_RISK_SCORE'],
  technicalScoreContribution:0,actionAllowed:false,judgement:'NONE',independentApproval:'HOLD'});
}
