import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {strictTimestamp} from './common.mjs';
import {digest} from './review_run_store.mjs';
import {buildCoreReview} from './core_review.mjs';
import {validateRecordEnvelope} from './data_record_contract.mjs';
import {buildCoreSamples} from '../tools/build_core_samples.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
export const RULE_SHA='327f91d760e5d703ba6c970e3b9fa8a036de9187';
export function checkBasicRules(){
 const bytes=fs.readFileSync(path.join(root,'rulesync/gpt-rules-current.json'));
 const blob=createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${bytes.length}\0`),bytes])).digest('hex');
 const rules=JSON.parse(bytes);
 if(blob!==RULE_SHA||rules.version!=='1.1.2'||rules.projectWorkflow?.instructionRevision!=='PROJECT_ENTRY_V2_20261001')throw Error('RULE_SNAPSHOT_MISMATCH');
 return {version:rules.version,blobSha:blob,sha256:digest(bytes),policy:rules,sourceVerifiedAt:JSON.parse(fs.readFileSync(path.join(root,'verification/basic_release/RULE_RECEIPT.json'))).verifiedAt};
}
export function assertNoSecrets(value,depth=0){
 if(depth>40)throw Error('INPUT_DEPTH_LIMIT');
 if(value&&typeof value==='object')for(const [k,v] of Object.entries(value)){
  if(/^(api_?key|access_?token|refresh_?token|authorization|password|secret|private_?key|cookie|bearer_?token|dartApiKey|krxApiKey)$/i.test(k))throw Error('SECRETS_MUST_STAY_OUTSIDE_INPUT_PACK');
  assertNoSecrets(v,depth+1);
 }else if(typeof value==='string'&&(/[?&](token|api_?key|secret|signature|sig)=/i.test(value)||/\bBearer\s+[A-Za-z0-9._-]+/.test(value)))throw Error('SECRET_IN_SOURCE_TEXT');
}
export function readInputPack(file){
 const p=fs.realpathSync(file);if(fs.statSync(p).size>64*1024*1024)throw Error('INPUT_SIZE_LIMIT');
 const bytes=fs.readFileSync(p);if(bytes.length>64*1024*1024)throw Error('INPUT_SIZE_LIMIT');
 const config=JSON.parse(bytes.toString('utf8'));assertNoSecrets(config);
 return {config,inputDir:path.dirname(p),fileHash:digest(bytes)};
}
const id=x=>{if(typeof x!=='string'||! /^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$/.test(x))throw Error('INVALID_INSTRUMENT_ID');return x;};
function markSubmittedSourceClaims(value){
 if(!value||typeof value!=='object')return;
 if(value.dataContractVersion||(Object.hasOwn(value,'value')&&(value.account||value.key||value.status==='VERIFIED'))){
  value.submittedEvidenceClaim={status:value.status,realDataVerified:value.realDataVerified,sourceVerification:structuredClone(value.sourceVerification)};
  if(value.status==='VERIFIED')value.status='PARTIAL';
  value.realDataVerified=false;
  if(value.sourceVerification?.status!=='CONFLICT')value.sourceVerification={...value.sourceVerification,status:'UNVERIFIED',evidenceRef:'SUBMITTED_CLAIM_NOT_INDEPENDENTLY_MATCHED_BY_IMPORT'};
 }
 for(const [key,node] of Object.entries(value))if(key!=='submittedEvidenceClaim')markSubmittedSourceClaims(node);
}
export function prepareBasicData(config,{inputDir=root,now=new Date().toISOString()}={}){
 assertNoSecrets(config);checkBasicRules();
 if(!config||config.schema!=='BASIC_RELEASE_INPUT_V1'||!['EMPTY','HISTORICAL_SAMPLE','IMPORTED'].includes(config.mode))throw Error('BASIC_INPUT_SCHEMA_REQUIRED');
 const allowed=['schema','mode','analysisAsOf','instruments','artifacts','market','portfolio','sixLayer','integratedPortfolio','decisionBoard','multiHorizon','globalEnvironment'];
 if(Object.keys(config).some(k=>!allowed.includes(k)))throw Error('UNKNOWN_BASIC_INPUT_FIELD');
 const asOf=config.analysisAsOf||now;strictTimestamp(asOf);if(Date.parse(asOf)>Date.parse(now))throw Error('FUTURE_ANALYSIS_TIME');
 if(config.mode!=='IMPORTED'&&(config.instruments?.length||config.artifacts?.length))throw Error('SAMPLE_OR_EMPTY_CANNOT_MIX_IMPORTED_DATA');
 let sample,rawFiles=new Map();
 if(config.mode==='HISTORICAL_SAMPLE'){
  sample=buildCoreSamples();if(Date.parse(sample.asOf)>Date.parse(asOf))throw Error('FUTURE_SOURCE_SNAPSHOT');
  for(const a of sample.artifacts){
   const candidates=['data/real_samples','data/reconciliation','data/phase04_08','data/phase09_11'].map(p=>path.join(root,p,a.localFile||'kodex_379810_dom.txt')).filter(p=>fs.existsSync(p)&&digest(fs.readFileSync(p))===a.sha256);
   if(candidates.length!==1)throw Error('RAW_SOURCE_NOT_UNIQUELY_RESOLVED');rawFiles.set(a.artifactId,candidates[0]);
  }
 }else{
  if(!Array.isArray(config.instruments??[])||!Array.isArray(config.artifacts??[])||(config.instruments?.length||0)>3000||(config.artifacts?.length||0)>500)throw Error('INPUT_COLLECTION_LIMIT_OR_TYPE');
  const artifacts=(config.artifacts||[]).map(a=>{
   if(!a||! /^[A-Za-z0-9_-]{1,80}$/.test(a.artifactId||'')||rawFiles.has(a.artifactId)||! /^[a-f0-9]{64}$/.test(a.sha256||''))throw Error('RAW_ARTIFACT_ID_OR_HASH');
   if(typeof a.localFile!=='string'||path.isAbsolute(a.localFile)||a.localFile.includes('\\')||a.localFile.split('/').includes('..'))throw Error('RAW_PATH_NOT_ALLOWED');
   const p=path.resolve(inputDir,a.localFile),base=fs.realpathSync(inputDir);
   if(!p.startsWith(base+path.sep)||fs.realpathSync(p)!==p||!fs.statSync(p).isFile()||fs.statSync(p).size>32*1024*1024)throw Error('RAW_PATH_NOT_ALLOWED');
   if(digest(fs.readFileSync(p))!==a.sha256)throw Error('RAW_HASH_MISMATCH');
   strictTimestamp(a.retrievedAt);if(Date.parse(a.retrievedAt)>Date.parse(asOf))throw Error('FUTURE_RAW_CAPTURE');
   rawFiles.set(a.artifactId,p);return structuredClone(a);
  });
  const seen=new Set(),contexts={},inputs=[],reviews=[],etfHistory=[];
  for(const item of config.instruments||[]){
   if(!item||Object.keys(item).some(k=>!['input','history'].includes(k)))throw Error('INSTRUMENT_INPUT_CONTRACT');
   const input=structuredClone(item.input);if(!input||!['ETF','STOCK'].includes(input.assetMode))throw Error('ASSET_MODE_REQUIRED');
   const symbol=id(input.assetMode==='STOCK'?input.stockContextInput?.identity?.symbol:input.etfMetricsInput?.instrumentId);
   if(seen.has(symbol))throw Error('DUPLICATE_INSTRUMENT_ID');seen.add(symbol);
   if(input.analysisAsOf!==asOf)throw Error('INPUT_ANALYSIS_TIME_MISMATCH');
   if(input.reviewPacket||input.reviewContract)throw Error('TRUSTED_PRIVATE_CONTRACT_USE_SEPARATE_EXISTING_SIDECAR_PATH');
   const container=input.assetMode==='STOCK'?input.stockContextInput:input.etfMetricsInput;
   container.evidenceBundle={rawArtifacts:artifacts};
   if(item.history&&!Array.isArray(item.history))throw Error('HISTORY_ARRAY_REQUIRED');
   const records=[...(item.history||[]),...(input.assetMode==='STOCK'?container.fundamentalFacts||[]:input.sourceFacts||[])];
   for(const record of records){
    if(record.instrumentId!==symbol)throw Error('HISTORY_IDENTITY_MISMATCH');
    if(record.dataContractVersion){const checked=validateRecordEnvelope(record,{asOf,rawArtifacts:artifacts});if(!checked.valid)throw Error('IMPORTED_RECORD_CONTRACT:'+checked.errors.join(','));}
    else if([record.availableAt,record.retrievedAt,record.observedAt].some(x=>x&&Date.parse(x)>Date.parse(asOf))||[record.tradeDate,record.measurementDate,record.periodEnd].some(x=>x&&x>asOf.slice(0,10)))throw Error('FUTURE_IMPORTED_RECORD');
   }
   // All history enters the existing envelope/temporal validation path; it cannot be a display-only bypass.
   if(input.assetMode==='STOCK')container.fundamentalFacts=[...(container.fundamentalFacts||[]),...structuredClone(item.history||[])];
   else input.sourceFacts=[...(input.sourceFacts||[]),...structuredClone(item.history||[])];
   // A matching file hash proves transport integrity, not that caller-authored rows match that file.
   // Keep every original claim separately; calculations may remain partial, but source verification
   // and selection authority cannot be obtained by declaring VERIFIED in an imported JSON file.
   markSubmittedSourceClaims(input);
   const review=buildCoreReview(input);if(!review.instrumentName)throw Error('INSTRUMENT_NAME_REQUIRED');
   inputs.push(input);reviews.push(review);
   if(input.assetMode==='STOCK')contexts[symbol]={fundamental:{history:container.fundamentalFacts||[]}};
   else etfHistory.push(...(input.sourceFacts||[]));
  }
  sample={asOf,reviews,inputs,contexts,artifacts,etfHistory,stage04Gate:{status:'NOT_RUN_FOR_IMPORTED_PACK',passed:false}};
 }
 for(const r of sample.reviews)id(r.instrumentId);
 return {sample,rawFiles,analysisAsOf:asOf,mode:config.mode};
}
