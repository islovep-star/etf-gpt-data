import {inflateRawSync} from 'node:zlib';

// A bounded in-memory reader for the single XML member in OpenDART corpCode.
// Never extracts files to disk. ZIP64, encryption and multipart archives fail closed.
const MAX_ARCHIVE=32*1024*1024, MAX_XML=64*1024*1024;
function fail(code){throw new Error('DART_CORP_ZIP_'+code);}
function crc32(b){let c=0xffffffff;for(const x of b){c^=x;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}
export function decodeDartCorpArchive(input){
 const b=Buffer.from(input);if(b.length>MAX_ARCHIVE)fail('TOO_LARGE');
 if(b.length<4||b.readUInt32LE(0)!==0x04034b50){
  const text=b.toString('utf8'),code=text.match(/<status>\s*(\d+)\s*<\/status>/)?.[1];
  if(code)throw new Error('DART_CORP_API_ERROR:'+code);
  fail('BINARY_RESPONSE_REQUIRED');
 }
 let end=-1;
 for(let i=b.length-22;i>=Math.max(0,b.length-65557);i--){
  if(b.readUInt32LE(i)===0x06054b50&&i+22+b.readUInt16LE(i+20)===b.length){end=i;break;}
 }
 if(end<0)fail('EOCD_MISSING');
 const count=b.readUInt16LE(end+10),size=b.readUInt32LE(end+12),offset=b.readUInt32LE(end+16);
 if(b.readUInt16LE(end+4)||b.readUInt16LE(end+6)||b.readUInt16LE(end+8)!==count)fail('MULTIPART');
 if(count!==1||offset===0xffffffff||size===0xffffffff||offset+size!==end)fail('SINGLE_XML_REQUIRED');
 if(offset+46>end||b.readUInt32LE(offset)!==0x02014b50)fail('CENTRAL_DIRECTORY');
 const flags=b.readUInt16LE(offset+8),method=b.readUInt16LE(offset+10),crc=b.readUInt32LE(offset+16);
 const compressed=b.readUInt32LE(offset+20),expanded=b.readUInt32LE(offset+24);
 const nameLen=b.readUInt16LE(offset+28),extraLen=b.readUInt16LE(offset+30),commentLen=b.readUInt16LE(offset+32),local=b.readUInt32LE(offset+42);
 if(flags&1||![0,8].includes(method)||compressed===0xffffffff||expanded===0xffffffff||expanded>MAX_XML)fail('UNSUPPORTED_OR_OVERSIZE');
 if(b.readUInt16LE(offset+34)!==0||offset+46+nameLen+extraLen+commentLen!==end)fail('DIRECTORY_BOUNDS');
 const name=b.subarray(offset+46,offset+46+nameLen);
 if(name.toString('utf8').toUpperCase()!=='CORPCODE.XML'||((b.readUInt32LE(offset+38)>>>16)&0xf000)===0xa000)fail('MEMBER_NAME');
 if(local!==0||local+30>offset||b.readUInt32LE(local)!==0x04034b50)fail('LOCAL_HEADER');
 const localNameLen=b.readUInt16LE(local+26),localExtraLen=b.readUInt16LE(local+28),start=local+30+localNameLen+localExtraLen;
 if(b.readUInt16LE(local+6)!==flags||b.readUInt16LE(local+8)!==method||!name.equals(b.subarray(local+30,local+30+localNameLen)))fail('HEADER_MISMATCH');
 if(start>offset||start+compressed>offset)fail('MEMBER_BOUNDS');
 if(!(flags&8)&&(b.readUInt32LE(local+14)!==crc||b.readUInt32LE(local+18)!==compressed||b.readUInt32LE(local+22)!==expanded))fail('HEADER_SIZE_MISMATCH');
 let xml;
 try{xml=method===0?b.subarray(start,start+compressed):inflateRawSync(b.subarray(start,start+compressed),{maxOutputLength:MAX_XML});}catch{fail('DECOMPRESSION');}
 if(xml.length!==expanded||crc32(xml)!==crc)fail('INTEGRITY');
 return new TextDecoder('utf-8',{fatal:true}).decode(xml);
}
