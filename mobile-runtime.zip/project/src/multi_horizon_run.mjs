/** Reuses immutable V9 run receipts. Single-writer local chain; no remote storage. */
import fs from 'node:fs';
import path from 'node:path';
import {validateReviewRun} from './review_run_store.mjs';
import {verifyMultiHorizonPacket} from './multi_horizon.mjs';
export function lockMultiHorizonOutput(outputRoot){
 const root=path.resolve(outputRoot);fs.mkdirSync(root,{recursive:true,mode:0o700});
 if(fs.realpathSync(root)!==root)throw Error('OUTPUT_SYMLINK_FORBIDDEN');
 const file=path.join(root,'multi_horizon.writer.lock');
 let fd;try{fd=fs.openSync(file,'wx',0o600);}catch(e){if(e.code==='EEXIST')throw Error('MULTI_HORIZON_WRITER_LOCK_REQUIRES_REVIEW');throw e;}
 return ()=>{fs.closeSync(fd);fs.unlinkSync(file);};
}
export function previousMultiHorizonRun(outputRoot,{recoverRunId,excludeRunId}={}){
 const runs=path.resolve(outputRoot,'runs');if(!fs.existsSync(runs))return null;
 const packets=[];
 for(const name of fs.readdirSync(runs)){
  const dir=path.join(runs,name),file=path.join(dir,'multi_horizon/opportunity_packet.json');
  const receipt=path.join(dir,'run.json');
  if(fs.existsSync(receipt)&&JSON.parse(fs.readFileSync(receipt)).status!=='COMPLETE')throw Error('PENDING_EXECUTION_UNKNOWN');
  if(!fs.existsSync(file))continue;
  validateReviewRun(dir);const packet=JSON.parse(fs.readFileSync(file));verifyMultiHorizonPacket(packet);
  if(packet.runId!==name)throw Error('CHAIN_RUN_ID_MISMATCH');packets.push(packet);
 }
 if(!packets.length)return null;
 const parents=packets.map(p=>p.previousPacketHash).filter(Boolean);
 if(new Set(parents).size!==parents.length||packets.filter(p=>p.previousPacketHash===null).length!==1)throw Error('HISTORY_FORK_DETECTED');
 for(const p of packets){
  if(!p.previousPacketHash)continue;
  const parent=packets.find(q=>q.packetHash===p.previousPacketHash);
  if(!parent||JSON.stringify(p.history.slice(0,parent.history.length))!==JSON.stringify(parent.history)||Date.parse(parent.analysisAsOf)>=Date.parse(p.analysisAsOf))throw Error('HISTORY_OMITTED_OR_CHANGED');
 }
 const tips=packets.filter(p=>!parents.includes(p.packetHash));if(tips.length!==1)throw Error('HISTORY_FORK_DETECTED');
 // Validate the complete chain before recovering a prior run; do not remove
 // that run from the chain and make its descendants look orphaned.
 const recovered=packets.find(p=>p.runId===(recoverRunId||excludeRunId));
 return recovered?packets.find(p=>p.packetHash===recovered.previousPacketHash)||null:tips[0];
}
