import {isObject,hasText,strictDate,strictTimestamp,sha256} from './common.mjs';

const DAY=86400000;
export function civilDateAt(at,timeZone) {
  const parts=new Intl.DateTimeFormat('en-US',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(at));
  const p=Object.fromEntries(parts.map(x=>[x.type,x.value]));
  return `${p.year}-${p.month}-${p.day}`;
}

// Count civil dates, never add 24 hours to a New York timestamp across DST.
export function civilDates(start,end) {
  strictDate(start); strictDate(end);
  const first=Date.parse(start+'T00:00:00Z'),last=Date.parse(end+'T00:00:00Z');
  if(last<first||last-first>4000*DAY)throw new Error('CALENDAR_COVERAGE_RANGE_INVALID');
  return Array.from({length:(last-first)/DAY+1},(_,i)=>new Date(first+i*DAY).toISOString().slice(0,10));
}

function marketTime(date,hhmm) {
  // This adapter only emits US regular equity market times, away from DST transitions.
  if(!['09:30','13:00','16:00'].includes(hhmm))throw new Error('US_SESSION_TIME_UNSUPPORTED');
  const fmt=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
  const target=Date.parse(`${date}T${hhmm}:00Z`);
  let guess=target;
  for(let i=0;i<3;i++){
    const p=Object.fromEntries(fmt.formatToParts(new Date(guess)).map(x=>[x.type,x.value]));
    const represented=Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}Z`);
    const delta=target-represented;
    if(delta===0)return new Date(guess).toISOString();
    guess+=delta;
  }
  throw new Error('TIME_ZONE_CONVERSION_FAILED');
}

export function buildOfficialUsCalendar(source,exchange) {
  if(!isObject(source)||source.schema!=='OFFICIAL_US_SCHEDULE_SOURCE_V1'||source.status!=='REVIEWED_OFFICIAL_SCHEDULE')throw new Error('OFFICIAL_SCHEDULE_SOURCE_REQUIRED');
  if(!['NYSE','NASDAQ'].includes(exchange))throw new Error('EXCHANGE_UNSUPPORTED');
  if(source.year!==2026||source.sessionScope!=='REGULAR_SESSION'||source.assetClass!=='CASH_EQUITIES')throw new Error('SOURCE_SCOPE_UNSUPPORTED');
  const evidence=(Array.isArray(source.exchanges)?source.exchanges:[]).filter(x=>x.exchange===exchange);
  if(evidence.length!==1)throw new Error('EXCHANGE_SOURCE_REQUIRED');
  const e=evidence[0];
  if(!hasText(e.sourceRef)||!hasText(e.hoursSourceRef)||e.timeZone!=='America/New_York'||e.regularOpen!=='09:30'||e.regularClose!=='16:00')throw new Error('SOURCE_METADATA_INVALID');
  strictTimestamp(e.observedNoLaterThan,'source.observedNoLaterThan');
  if(!Array.isArray(e.holidays)||!Array.isArray(e.earlyCloses))throw new Error('SOURCE_EXCEPTIONS_REQUIRED');
  const exceptions=new Map();
  for(const [list,status] of [[e.holidays,'HOLIDAY'],[e.earlyCloses,'EARLY_CLOSE']])for(const x of list){
    strictDate(x.date);
    if(!x.date.startsWith(source.year+'-')||exceptions.has(x.date)||!hasText(x.reason))throw new Error('SOURCE_EXCEPTION_INVALID');
    if([0,6].includes(new Date(x.date+'T00:00:00Z').getUTCDay()))throw new Error('SOURCE_EXCEPTION_ON_WEEKEND');
    if(status==='EARLY_CLOSE'&&x.close!=='13:00')throw new Error('EARLY_CLOSE_TIME_UNSUPPORTED');
    exceptions.set(x.date,{...x,status});
  }
  const coverage={start:`${source.year}-01-01`,end:`${source.year}-12-31`};
  const sessions=civilDates(coverage.start,coverage.end).map(date=>{
    const x=exceptions.get(date);
    const weekend=[0,6].includes(new Date(date+'T00:00:00Z').getUTCDay());
    if(weekend||x?.status==='HOLIDAY')return {date,status:'HOLIDAY',reason:weekend?'WEEKEND':x.reason};
    return {date,status:x?.status||'OPEN',...(x?{reason:x.reason}:{}),openAt:marketTime(date,'09:30'),closeAt:marketTime(date,x?.close||'16:00')};
  });
  return {
    schema:'TRADING_CALENDAR_V1',contractRevision:2,market:exchange,status:'VERIFIED',
    verificationScope:'PUBLISHED_SCHEDULE_ONLY',sessionScope:source.sessionScope,assetClass:source.assetClass,
    timeZone:e.timeZone,coverage,sourceRef:e.sourceRef,hoursSourceRef:e.hoursSourceRef,
    versionId:`${exchange}-${source.year}-${sha256(e).slice(0,16)}`,sourceEvidenceSha256:sha256(e),
    availableAt:e.observedNoLaterThan,availableAtBasis:'OBSERVATION_RECEIPT_UPPER_BOUND',
    observedTradingVerified:false,unscheduledClosuresVerified:false,
    warnings:['SCHEDULE_ONLY_UNSCHEDULED_EVENTS_NOT_VERIFIED','HISTORICAL_PUBLICATION_TIME_NOT_PROVEN'],sessions
  };
}
