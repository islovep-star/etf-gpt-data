import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
export const digest=b=>createHash('sha256').update(b).digest('hex');
export function classifyReviewError(error){
 const s=error?.status||error?.statusCode;
 const category=[401,403].includes(s)?'AUTH':error?.name==='AbortError'||/TIMEOUT|ETIMEDOUT/.test(error?.code||error?.message||'')?'TIMEOUT':/ECONN|ENOTFOUND|NETWORK/.test(error?.code||error?.message||'')?'NETWORK':/PENDING|EXECUTION_UNKNOWN/.test(error?.code||error?.message||'')?'PENDING':'DATA';
 return {category,executionState:category==='PENDING'||category==='TIMEOUT'||category==='NETWORK'?'UNKNOWN':'FAILED',automaticResend:false,recovery:'READ_SAME_RUN_ID_FIRST'};
}
export function validateReviewRun(runDir,{expectedRunId=path.basename(path.resolve(runDir)),expectedInputHash}={}){
 const dir=path.resolve(runDir);
 if(fs.realpathSync(dir)!==dir)throw new Error('RECOVERED_FILE_INTEGRITY_ERROR');
 const receiptPath=path.join(dir,'run.json');
 if(fs.realpathSync(receiptPath)!==receiptPath)throw new Error('RECOVERED_FILE_INTEGRITY_ERROR');
 let receipt;try{receipt=JSON.parse(fs.readFileSync(receiptPath));}catch{throw new Error('PENDING_EXECUTION_UNKNOWN');}
 if(receipt.schema!=='LOCAL_REVIEW_RUN_V1'||receipt.runId!==expectedRunId)throw new Error('RUN_IDENTITY_MISMATCH');
 if(expectedInputHash!==undefined&&receipt.inputHash!==expectedInputHash)throw new Error('RUN_ID_INPUT_CONFLICT');
 if(receipt.status!=='COMPLETE')throw new Error('PENDING_EXECUTION_UNKNOWN');
 if(!Array.isArray(receipt.files)||!receipt.files.length)throw new Error('RECOVERED_FILE_INTEGRITY_ERROR');
 const seen=new Set();
 for(const item of receipt.files){
  if(typeof item.path!=='string'||item.path==='run.json'||item.path==='run.next.json'||item.path.includes('\\')||path.posix.normalize(item.path)!==item.path||seen.has(item.path)||!Number.isSafeInteger(item.bytes)||item.bytes<0||!/^[a-f0-9]{64}$/.test(item.sha256))throw new Error('RECOVERED_FILE_INTEGRITY_ERROR');
  seen.add(item.path);const target=path.resolve(dir,item.path);
  if(!target.startsWith(dir+path.sep)||!fs.existsSync(target)||fs.realpathSync(target)!==target||!fs.statSync(target).isFile())throw new Error('RECOVERED_FILE_INTEGRITY_ERROR');
  const bytes=fs.readFileSync(target);if(bytes.length!==item.bytes||digest(bytes)!==item.sha256)throw new Error('RECOVERED_FILE_INTEGRITY_ERROR');
 }
 return receipt;
}
export function beginReviewRun(outputRoot,runId,inputHash){
 if(!/^[A-Za-z0-9_-]{1,64}$/.test(runId))throw new Error('INVALID_RUN_ID');
 const dir=path.resolve(outputRoot,'runs',runId);fs.mkdirSync(path.dirname(dir),{recursive:true});
 if(fs.existsSync(dir)){
  if(!fs.existsSync(path.join(dir,'run.json')))throw new Error('PENDING_EXECUTION_UNKNOWN');
  const previous=validateReviewRun(dir,{expectedRunId:runId,expectedInputHash:inputHash});
  return {dir,recovered:true,receipt:previous};
 }
 try{fs.mkdirSync(dir,{recursive:false,mode:0o700});}catch(e){if(e.code==='EEXIST')throw new Error('PENDING_EXECUTION_UNKNOWN');throw e;}
 const receipt={schema:'LOCAL_REVIEW_RUN_V1',runId,inputHash,status:'PENDING',automaticResend:false,startedAt:new Date().toISOString(),deployment:'NOT_ATTEMPTED'};
 fs.writeFileSync(path.join(dir,'run.json'),JSON.stringify(receipt,null,2)+'\n');return {dir,recovered:false,receipt};
}
export function completeReviewRun(run){
 const files=[];
 const walk=dir=>{for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory())walk(p);else if(item.name!=='run.json'){if(item.isSymbolicLink())throw new Error('OUTPUT_SYMLINK_FORBIDDEN');const b=fs.readFileSync(p);files.push({path:path.relative(run.dir,p),bytes:b.length,sha256:digest(b)});}}};walk(run.dir);
 if(!files.length)throw new Error('OUTPUT_FILES_REQUIRED');
 if(run.receipt.runId!==path.basename(path.resolve(run.dir)))throw new Error('RUN_IDENTITY_MISMATCH');
 const receipt={...run.receipt,status:'COMPLETE',completedAt:new Date().toISOString(),files:files.sort((a,b)=>a.path.localeCompare(b.path)),transportStatus:'LOCAL_FILES_WRITTEN',operation:'LOCAL_REVIEW_ONLY'};
 fs.writeFileSync(path.join(run.dir,'run.next.json'),JSON.stringify(receipt,null,2)+'\n');fs.renameSync(path.join(run.dir,'run.next.json'),path.join(run.dir,'run.json'));
 return receipt;
}
