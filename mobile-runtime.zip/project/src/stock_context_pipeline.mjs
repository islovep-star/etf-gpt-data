import {emptyStockContext,validateStockContext,buildCompactStockPacket} from './stock_context_schema.mjs';
import {selectLatestAvailable,hasText,isObject,strictTimestamp,sha256,factIdentity} from './common.mjs';
import {buildCorporateMetrics} from './corporate_metrics.mjs';
import {applyRecordEvidence,versionedPacketEvidence} from './data_record_contract.mjs';
import {assertTechnicalScope,assertObservationTimes,assertEventScope} from './temporal_scope.mjs';

function mergeSources(...arrays){
  const map=new Map();for(const x of arrays.flat().filter(Boolean)){const key=`${x.sourceRef||''}|${x.versionId||''}`;if(!map.has(key))map.set(key,{sourceRef:x.sourceRef||null,versionId:x.versionId||null,availableAt:x.availableAt||null});}
  return [...map.values()];
}
function factsAt(facts,asOf){return selectLatestAvailable(facts||[],asOf,factIdentity);}

export function buildStockContext(input){
  const evidenceOptions={...input?.evidenceBundle,asOf:input?.asOf};
  input={...input,...Object.fromEntries(['fundamentalFacts','valuationFacts','flowFacts','ownershipFacts'].map(k=>[k,applyRecordEvidence(input?.[k],evidenceOptions)]))};
  const {identity,asOf}=input||{};strictTimestamp(asOf,'asOf');
  if(identity?.assetType&&identity.assetType!=='STOCK')throw new Error('STOCK_CONTEXT_REQUIRES_STOCK_USE_ETF_METRICS');
  const ctx=emptyStockContext({...identity,asOf});
  assertTechnicalScope(input.technical,{asOf,instrumentId:ctx.identity.symbol});
  assertObservationTimes(input.market,asOf,'MARKET');
  for(const event of input.events||[])assertEventScope(event,ctx.identity.symbol);
  if(input.valuation?.current&&strictTimestamp(input.valuation.current.availableAt,'valuation.current.availableAt')>strictTimestamp(asOf))throw new Error('VALUATION_CURRENT_LOOKAHEAD');
  ctx.technical=input.technical||null;
  const fundamentalSelection=factsAt(input.fundamentalFacts,asOf);
  const fundamentalFacts=fundamentalSelection.selected;
  const valuationSelection=factsAt(input.valuationFacts,asOf);
  const valuationFacts=valuationSelection.selected;
  const flowSelection=factsAt(input.flowFacts,asOf);
  const flowFacts=flowSelection.selected;
  const ownershipSelection=factsAt(input.ownershipFacts,asOf);
  const ownershipFacts=ownershipSelection.selected;
  const events=(input.events||[]).filter(x=>Date.parse(x.availableAt)<=Date.parse(asOf));
  ctx.fundamental={...(input.fundamental||ctx.fundamental),facts:fundamentalFacts};
  ctx.valuation={...(input.valuation||ctx.valuation),facts:valuationFacts};
  ctx.flow={...(input.flow||ctx.flow),facts:flowFacts};
  ctx.ownership={...(input.ownership||ctx.ownership),facts:ownershipFacts};
  ctx.fundamental.history=(input.fundamentalFacts||[]).filter(f=>{try{return strictTimestamp(f.availableAt)<=strictTimestamp(asOf);}catch{return false;}});
  ctx.fundamental.metrics=buildCorporateMetrics({...input.financialOptions,facts:fundamentalFacts,asOf,instrumentId:identity.symbol});
  ctx.valuation.comparisons=ctx.fundamental.metrics.valuationComparisons;
  ctx.events=events;
  ctx.market=input.market||null;
  const sections={
    technical:input.quality?.technical||{status:ctx.technical?'PARTIAL':'MISSING'},
    fundamental:input.quality?.fundamental||{status:fundamentalFacts.length?'PARTIAL':'MISSING'},
    valuation:input.quality?.valuation||{status:valuationFacts.length?'PARTIAL':'MISSING'},
    flow:input.quality?.flow||{status:flowFacts.length?'PARTIAL':'MISSING'},
    ownership:input.quality?.ownership||{status:ownershipFacts.length?'PARTIAL':'MISSING'},
    events:input.quality?.events||{status:events.length?'PARTIAL':'MISSING'},
    market:input.quality?.market||{status:ctx.market?'PARTIAL':'MISSING'}
  };
  const conflictingEvidence={};
  for(const [name,facts] of Object.entries({fundamental:fundamentalFacts,valuation:valuationFacts,flow:flowFacts,ownership:ownershipFacts})){
    if(facts.some(f=>f.instrumentId&&f.instrumentId!==identity.symbol||f.periodEnd&&f.periodEnd>asOf.slice(0,10)||f.status==='BLOCKED'))sections[name]={...sections[name],status:'BLOCKED',reason:'FACT_SCOPE_OR_STATUS_BLOCKED'};
    else if(!facts.some(f=>f.value!==null&&f.value!==undefined))sections[name]={...sections[name],status:'MISSING'};
    else if(facts.some(f=>f.status!=='VERIFIED')&&sections[name].status==='VERIFIED')sections[name]={...sections[name],status:'PARTIAL',reason:'FACTS_NOT_FULLY_VERIFIED'};
  }
  for(const [name,selection] of Object.entries({fundamental:fundamentalSelection,valuation:valuationSelection,flow:flowSelection,ownership:ownershipSelection})){
    if(selection.conflicts.length){
      sections[name]={...sections[name],status:'BLOCKED',conflicts:selection.conflicts};
      conflictingEvidence[name]=(input[name+'Facts']||[]).filter(f=>selection.conflicts.includes(factIdentity(f))&&Date.parse(f.availableAt)<=Date.parse(asOf));
    }
  }
  const blockers=Object.entries(sections).filter(([,x])=>x.status==='BLOCKED').map(([k])=>`SECTION_BLOCKED:${k}`);
  const missing=Object.entries(sections).filter(([,x])=>x.status==='MISSING').map(([k])=>k);
  const warnings=[...(input.warnings||[])];
  ctx.dataQuality={status:blockers.length?'BLOCKED':Object.values(sections).every(x=>x.status==='VERIFIED')?'VERIFIED':'PARTIAL',sections,blockers,warnings,conflictingEvidence};
  ctx.meta={availableAt:asOf,sources:mergeSources(fundamentalFacts,valuationFacts,flowFacts,ownershipFacts,events),warnings,missing};
  ctx.meta.evidence={...versionedPacketEvidence(['fundamentalFacts','valuationFacts','flowFacts','ownershipFacts'].flatMap(k=>input[k])),rawArtifacts:input.evidenceBundle?.rawArtifacts||[]};
  const validation=validateStockContext(ctx);
  if(!validation.valid)throw new Error(`STOCK_CONTEXT_BUILD_FAILED:${validation.blockers.join(',')}`);
  return {...ctx,contextHash:sha256(ctx)};
}

export function buildStockAnalysisPacket(input,options){return buildCompactStockPacket(buildStockContext(input),options);}

export function stockContextCapabilities(ctx){
  const sections=ctx?.dataQuality?.sections||{};
  return {
    technical:Boolean(ctx?.technical),
    fundamental:(ctx?.fundamental?.facts||[]).length>0,
    valuation:(ctx?.valuation?.facts||[]).length>0,
    flow:(ctx?.flow?.facts||[]).some(f=>f.value!==null&&['VERIFIED','PARTIAL'].includes(f.status)),
    ownership:(ctx?.ownership?.facts||[]).length>0,
    events:(ctx?.events||[]).length>0,
    market:Boolean(ctx?.market),
    actionReady:false,
    automaticTradingAllowed:false,
    sectionStatus:Object.fromEntries(Object.entries(sections).map(([k,v])=>[k,v.status]))
  };
}
