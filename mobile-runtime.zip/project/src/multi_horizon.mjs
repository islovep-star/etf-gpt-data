/** Informational, opt-in review boundary. Never creates an order, amount or rank. */
import {actualTree} from './multi_horizon_dossiers.mjs';
import {sha256,strictTimestamp,strictDate,hasText,stableStringify} from './common.mjs';
export const MH_SCHEMA='MULTI_HORIZON_OPPORTUNITIES_V1';
export const MH_RULES={namespace:'multiHorizonReview',version:'V10_REBUILT_20260930',maxPerHorizon:2,allowedActions:['OBSERVE','WAIT','REDUCE_OBSERVE'],technicalScoreContribution:0,scenarioStatus:'NOT_IMPLEMENTED_INPUTS_REQUIRED',scope:'REVIEWED_UNIVERSE_ONLY',automaticTradingAllowed:false};
const clone=x=>structuredClone(x), text=x=>hasText(x)&&x.length<=4000;
const unique=(xs,label)=>{if(new Set(xs).size!==xs.length)throw Error('DUPLICATE_'+label);};
const only=(x,keys)=>{if(!x||Array.isArray(x)||typeof x!=='object'||Object.keys(x).some(k=>!keys.includes(k)))throw Error('UNSUPPORTED_REVIEW_FIELD');};
const hash=/^[a-f0-9]{64}$/;
const snapshotHash=({analysisAsOf,...source})=>sha256(source);
function timeOK(t,cutoff){try{return strictTimestamp(t)<=cutoff;}catch{return false;}}
function evidenceOK(e,cutoff){return e?.status==='VERIFIED'&&text(e.sourceRef)&&hash.test(e.sha256||'')&&timeOK(e.availableAt,cutoff)&&timeOK(e.retrievedAt,cutoff)&&Date.parse(e.availableAt)<=Date.parse(e.retrievedAt);}
function identityOK(i,cutoff){return i&&['STOCK','ETF'].includes(i.assetType)&&['KR','US'].includes(i.listingMarket)&&text(i.currency)&&text(i.underlyingCountry)&&text(i.exposureCluster)&&text(i.name)&&evidenceOK(i.evidence,cutoff);}
function marketReady(m,id,cutoff,currency,policy){
 if(!policy||!Number.isFinite(policy.maxAgeSeconds)||policy.maxAgeSeconds<0||!evidenceOK(policy.evidence,cutoff))return false;
 if(!m||!timeOK(m.asOf,cutoff)||cutoff-Date.parse(m.asOf)>policy.maxAgeSeconds*1000||!evidenceOK(m.evidence,cutoff))return false;
 const matches=m.prices?.filter(p=>p.instrumentId===id)||[];if(matches.length!==1)return false;const p=matches[0];
 return !!p&&p.kind==='ACTUAL'&&p.currency===currency&&Number.isFinite(p.close)&&p.close>0&&p.asOf===m.asOf&&p.tradeDate===m.asOf.slice(0,10)&&evidenceOK(p.evidence,cutoff)&&
 (m.flows||[]).every(f=>f.kind==='ACTUAL'&&Number.isFinite(f.value)&&f.asOf===m.asOf&&evidenceOK(f.evidence,cutoff));
}
export function validateHistory(history){
 if(!Array.isArray(history))throw Error('HISTORY_REQUIRED');let previousHash=null;const ids=[];
 for(const event of history){const {eventHash,...body}=event;if(body.previousHash!==previousHash||sha256(body)!==eventHash)throw Error('HISTORY_CHAIN_INVALID');ids.push(event.eventId);previousHash=eventHash;}
 unique(ids,'HISTORY_EVENT');return previousHash;
}
export function verifyMultiHorizonPacket(packet){
 const {packetHash,...body}=packet||{};if(body.schema!==MH_SCHEMA||sha256(body)!==packetHash)throw Error('PREVIOUS_PACKET_HASH_INVALID');
 if(validateHistory(packet.history)!==packet.historyHead)throw Error('PREVIOUS_HISTORY_HEAD_INVALID');return true;
}
export function prepareMultiHorizonInput({analysisAsOf,sourceAsOf,dossiers,registry={identities:[],accountPolicies:[]},market=null,theses=[],legacyContext={},ruleProposalSha256=null}){
 const cutoff=strictTimestamp(analysisAsOf);if(strictTimestamp(sourceAsOf)>cutoff)throw Error('FUTURE_SOURCE_SNAPSHOT');
 if(!Array.isArray(dossiers)||!Array.isArray(theses))throw Error('DOSSIERS_AND_THESES_REQUIRED');
 unique(dossiers.map(d=>d.instrumentId),'INSTRUMENT');unique(theses.map(t=>t.thesisId),'THESIS');
 unique((registry.identities||[]).map(i=>i.instrumentId),'IDENTITY');unique((registry.accountPolicies||[]).map(p=>p.accountId),'ACCOUNT');
 for(const d of dossiers){if(!text(d.instrumentId)||!['STOCK','ETF'].includes(d.assetType)||!Array.isArray(d.metrics)||!Array.isArray(d.missing)||strictTimestamp(d.sourceAsOf)>cutoff)throw Error('INVALID_DOSSIER');unique(d.metrics.map(m=>m.metricId),'METRIC');
  if(d.metrics.some(m=>!actualTree(m)||m.actualOrEstimate!=='ACTUAL'||m.status!=='VERIFIED'||!Number.isFinite(m.value)||!Array.isArray(m.sourceRefs)||!m.sourceRefs.length||m.sourceRefs.some(e=>!text(e.artifactId)||!hash.test(e.sha256||'')||!text(e.locator))))throw Error('UNVERIFIED_DOSSIER_METRIC');
 }
 for(const t of theses){
  only(t,['thesisId','instrumentId','mainHorizon','horizonStart','horizonEnd','portfolioRole','accountScope','cashNeededBy','comparisonPeriod','invalidated','overconcentrated','priceBurden','holdingLink','replacedBy']);
  if(!text(t.thesisId)||!text(t.instrumentId)||!['LONG','MEDIUM'].includes(t.mainHorizon)||!['CORE','SATELLITE','TACTICAL','REFERENCE'].includes(t.portfolioRole))throw Error('INVALID_THESIS');
  strictDate(t.horizonStart);strictDate(t.horizonEnd);if(t.horizonStart>t.horizonEnd)throw Error('REVERSED_HORIZON');
  if(t.cashNeededBy!=null)strictDate(t.cashNeededBy);
 }
 if(ruleProposalSha256!==null&&!hash.test(ruleProposalSha256))throw Error('RULE_PROPOSAL_HASH_INVALID');
 const objective={ruleProposalSha256,analysisAsOf,sourceAsOf,dossiers:clone(dossiers),registry:clone(registry),market:clone(market),theses:clone(theses),legacyContext:clone(legacyContext),rules:MH_RULES};
 return {schema:'MULTI_HORIZON_GPT_REVIEW_INPUT_V1',...objective,sourceSnapshotId:'MH_SOURCE_'+snapshotHash(objective),instruction:'GPT supplies interpretation and explicit selections bound to this snapshot and thesis IDs. Do not rewrite facts, rank, forecast returns or authorize trades.'};
}
export function buildMultiHorizonPacket({input,gptReview=null,previousPacket=null,expectedPreviousPacketHash=null,runId}){
 const {schema,sourceSnapshotId,instruction,...objective}=input||{};
 if(schema!=='MULTI_HORIZON_GPT_REVIEW_INPUT_V1'||sourceSnapshotId!=='MH_SOURCE_'+snapshotHash(objective)||sha256(objective.rules)!==sha256(MH_RULES))throw Error('INPUT_SNAPSHOT_BINDING_INVALID');
 if(prepareMultiHorizonInput(objective).sourceSnapshotId!==sourceSnapshotId)throw Error('INPUT_CONTRACT_INVALID');
 if(!/^[A-Za-z0-9_-]{1,64}$/.test(runId||''))throw Error('RUN_ID_REQUIRED');
 const cutoff=strictTimestamp(input.analysisAsOf),lookup=new Map(input.dossiers.map(d=>[d.instrumentId,d]));
 let history=[],previous=[];
 if(previousPacket){verifyMultiHorizonPacket(previousPacket);if(previousPacket.packetHash!==expectedPreviousPacketHash)throw Error('PREVIOUS_PACKET_BINDING_REQUIRED');if(Date.parse(previousPacket.analysisAsOf)>=cutoff)throw Error('NON_INCREASING_ANALYSIS_TIME');history=clone(previousPacket.history);previous=previousPacket.records;}
 else if(expectedPreviousPacketHash!==null)throw Error('PREVIOUS_HISTORY_OMITTED');
 let decisions=[];
 if(gptReview){
  only(gptReview,['schema','sourceSnapshotId','reviewedAt','scope','decisions']);
  if(gptReview.schema!=='MULTI_HORIZON_GPT_REVIEW_V1'||gptReview.sourceSnapshotId!==sourceSnapshotId||gptReview.scope!=='REVIEWED_UNIVERSE_ONLY'||!timeOK(gptReview.reviewedAt,cutoff)||Date.parse(gptReview.reviewedAt)<Date.parse(input.sourceAsOf)||!Array.isArray(gptReview.decisions))throw Error('GPT_REVIEW_BINDING_INVALID');
  decisions=gptReview.decisions;unique(decisions.map(x=>x.thesisId),'REVIEW');
 }
 for(const r of decisions){
  only(r,['thesisId','instrumentId','sourceSnapshotId','selected','reason','supportingMetricIds','opposingEvidence','valuationContext','downsideContext','alternatives','actionState','invalidationCondition','nextReview','changeReason','transitionApproved','benchmark']);
  if(!input.theses.some(t=>t.thesisId===r.thesisId&&t.instrumentId===r.instrumentId)||r.sourceSnapshotId!==sourceSnapshotId||typeof r.selected!=='boolean'||!text(r.reason)||!MH_RULES.allowedActions.includes(r.actionState))throw Error('DECISION_IDENTITY_OR_ACTION_INVALID');
  if(!Array.isArray(r.supportingMetricIds)||!Array.isArray(r.alternatives))throw Error('REVIEW_EVIDENCE_REQUIRED');unique(r.supportingMetricIds,'SUPPORTING_EVIDENCE');
  for(const id of r.supportingMetricIds)if(!lookup.get(r.instrumentId)?.metrics.some(m=>m.metricId===id&&m.status==='VERIFIED'&&m.actualOrEstimate==='ACTUAL'&&Number.isFinite(m.value)))throw Error('UNVERIFIED_SUPPORTING_METRIC');
  for(const a of r.alternatives){only(a,['instrumentId','reason']);if(a.instrumentId===r.instrumentId||!lookup.has(a.instrumentId)||!text(a.reason))throw Error('ALTERNATIVE_NOT_IN_REVIEWED_UNIVERSE');}
  unique(r.alternatives.map(a=>a.instrumentId),'ALTERNATIVE');
  for(const k of ['opposingEvidence','valuationContext','downsideContext','invalidationCondition'])if(!text(r[k]))throw Error('REVIEW_COUNTEREVIDENCE_REQUIRED');
  strictDate(r.nextReview);if(r.nextReview<input.analysisAsOf.slice(0,10))throw Error('REVIEW_DATE_PAST');
  if(r.transitionApproved!==undefined&&typeof r.transitionApproved!=='boolean')throw Error('TRANSITION_APPROVAL_INVALID');
  if(r.benchmark){
   only(r.benchmark,['instrumentId','periodStart','periodEnd','currency','returnBasis','sourceRefs']);const b=r.benchmark;
   strictDate(b.periodStart);strictDate(b.periodEnd);
   if(b.periodStart>b.periodEnd||b.periodEnd>input.analysisAsOf.slice(0,10)||!text(b.currency)||!text(b.returnBasis)||!Array.isArray(b.sourceRefs)||!b.sourceRefs.length||!b.sourceRefs.every(e=>evidenceOK(e,cutoff)))throw Error('BENCHMARK_BASIS_INVALID');
   const t=input.theses.find(t=>t.thesisId===r.thesisId);if(b.periodStart!==t.comparisonPeriod?.start||b.periodEnd!==t.comparisonPeriod?.end||b.currency!==t.comparisonPeriod?.currency||b.returnBasis!==t.comparisonPeriod?.returnBasis)throw Error('BENCHMARK_NOT_COMPARABLE');
  }
 }
 const records=input.theses.map(t=>{
  const d=lookup.get(t.instrumentId),i=input.registry.identities?.find(i=>i.instrumentId===t.instrumentId),r=decisions.find(r=>r.thesisId===t.thesisId),reasons=[];
  if(!d)reasons.push('DOSSIER_MISSING');
  if(!identityOK(i,cutoff)||i?.assetType!==d?.assetType)reasons.push('VERIFIED_IDENTITY_REQUIRED');
  if(!r)reasons.push('EXPLICIT_GPT_REVIEW_REQUIRED');
  if(!r?.supportingMetricIds?.length)reasons.push('ACTUAL_SUPPORTING_FACTS_REQUIRED');
  if(!marketReady(input.market,t.instrumentId,cutoff,i?.currency,input.registry.marketPolicy))reasons.push('CURRENT_MARKET_AND_PRICE_REQUIRED');
  if(t.horizonStart>input.analysisAsOf.slice(0,10)||t.horizonEnd<input.analysisAsOf.slice(0,10))reasons.push('HORIZON_REVIEW_REQUIRED');
  const policy=input.registry.accountPolicies?.find(p=>p.accountId===t.accountScope);
  if(t.portfolioRole!=='REFERENCE'){
   if(!policy||!evidenceOK(policy.evidence,cutoff))reasons.push('VERIFIED_ACCOUNT_POLICY_REQUIRED');
   else {
    if(t.portfolioRole==='CORE'&&!(policy.approvedCoreIds||[]).includes(t.instrumentId))reasons.push('APPROVED_CORE_REQUIRED');
    if(t.portfolioRole!=='CORE'&&i?.underlyingCountry!=='KR')reasons.push('DOMESTIC_UNDERLYING_ONLY');
    if(i?.leveraged!==false&&policy.allowLeverage!==true)reasons.push('LEVERAGE_NOT_ALLOWED_OR_UNKNOWN');
   }
  }
  if(t.cashNeededBy&&t.cashNeededBy<t.horizonEnd)reasons.push('CASH_HORIZON_CONFLICT');
  if(t.invalidated===true)reasons.push('THESIS_INVALIDATED_REVIEW_REQUIRED');
  const prior=previous.find(p=>p.thesisId===t.thesisId), priorInstrument=previous.find(p=>p.instrumentId===t.instrumentId);
  const changed=prior&&['mainHorizon','horizonStart','horizonEnd','instrumentId','portfolioRole','accountScope','cashNeededBy'].some(k=>stableStringify(prior[k]??null)!==stableStringify(t[k]??null));
  const shortTransition=(input.legacyContext.shortTerm||[]).some(x=>x.instrumentId===t.instrumentId&&x.lossOrFailure===true);
  if((changed||shortTransition||(priorInstrument&&!prior))&&!(r?.transitionApproved===true&&text(r?.changeReason)))reasons.push('EXPLICIT_HORIZON_TRANSITION_REVIEW_REQUIRED');
  const holdingOverlap=(input.legacyContext.holdings||[]).flatMap(h=>{
   const hi=input.registry.identities?.find(x=>x.instrumentId===h.instrumentId);
   const same=h.instrumentId===t.instrumentId;
   const matched=identityOK(hi,cutoff)&&((i?.indexId&&hi.indexId===i.indexId)||(i?.exposureCluster&&hi.exposureCluster===i.exposureCluster));
   return same||matched?[{instrumentId:h.instrumentId,reason:same?'ALREADY_HELD':'EXPOSURE_ALREADY_HELD',additionalAllocationBlocked:h.additionalAllocationBlocked===true}]:[];
  });
  const selected=r?.selected===true&&reasons.length===0;
  let actionState=r?.actionState||'OBSERVE';
  if(selected&&(t.overconcentrated===true||policy?.additionalAllocationBlocked===true||t.priceBurden===true||holdingOverlap.some(h=>h.additionalAllocationBlocked)))actionState='WAIT';
  return {opportunityId:sha256([t.thesisId,t.instrumentId]),...clone(t),instrumentName:i?.name||d?.instrumentName||t.instrumentId,sourceSnapshotId,evidenceAsOf:input.sourceAsOf,reviewedAt:gptReview?.reviewedAt||null,sourceRefs:r?.supportingMetricIds?.flatMap(id=>d?.metrics.find(m=>m.metricId===id)?.sourceRefs||[])||[],exposureCluster:i?.exposureCluster||null,indexId:i?.indexId||null,holdingLink:t.holdingLink||(holdingOverlap.some(h=>h.instrumentId===t.instrumentId)?d?.detailRef||null:null),holdingOverlap,selected,reviewStatus:!r?'NOT_REVIEWED':selected?'INFORMATIONAL_REVIEWED':reasons.length?'BLOCKED':'EXCLUDED_BY_REVIEW',blockerCodes:reasons,interpretation:r?clone(r):null,actionState,actionAllowed:false,technicalScoreContribution:0,scenarioStatus:MH_RULES.scenarioStatus,priorSafety:clone(d?.safety||null),allocationStatus:'NO_ALLOCATION_AUTHORITY'};
 });
 // Reject contradictory selections; do not rank or silently choose one for GPT.
 const selected=records.filter(x=>x.selected);
 for(const horizon of ['LONG','MEDIUM'])if(selected.filter(x=>x.mainHorizon===horizon).length>2)throw Error('HORIZON_CAP_EXCEEDED');
 unique(selected.map(x=>x.instrumentId),'SELECTED_INSTRUMENT');
 const indexes=selected.map(x=>x.indexId).filter(Boolean);unique(indexes,'SELECTED_INDEX');
 const concentrationWarnings=[];
 for(const r of selected){const overlaps=selected.filter(o=>o!==r&&o.exposureCluster===r.exposureCluster);if(overlaps.length)concentrationWarnings.push({instrumentId:r.instrumentId,overlaps:overlaps.map(o=>o.instrumentId),reason:'SHARED_EXPOSURE_NOT_INDEPENDENT_DIVERSIFICATION'});}
 for(const p of previous.filter(p=>!records.some(r=>r.thesisId===p.thesisId)))records.push({...clone(p),selected:false,reviewStatus:'REMOVED_FROM_CURRENT_INPUT',actionState:'OBSERVE',blockerCodes:['REMOVAL_REQUIRES_REVIEW'],removalSourceSnapshotId:sourceSnapshotId,removalRecordedAt:input.analysisAsOf,reviewedAt:null});
 for(const r of records){
  const old=previous.find(p=>p.thesisId===r.thesisId),eventType=!old?'NEW':r.reviewStatus==='REMOVED_FROM_CURRENT_INPUT'?'REMOVED':r.reviewStatus==='BLOCKED'?'BLOCKED':old.mainHorizon!==r.mainHorizon||old.horizonEnd!==r.horizonEnd?'HORIZON_CHANGED':!r.selected?'EXCLUDED':stableStringify(old.interpretation)===stableStringify(r.interpretation)?'RETAINED':'REVIEWED';
  const body={eventId:runId+':'+r.thesisId,runId,thesisId:r.thesisId,instrumentId:r.instrumentId,analysisAsOf:input.analysisAsOf,sourceSnapshotId,eventType,selected:r.selected,reason:r.reviewStatus==='REMOVED_FROM_CURRENT_INPUT'?'REMOVAL_REQUIRES_REVIEW':r.interpretation?.changeReason||r.interpretation?.reason||r.blockerCodes.join(','),recordHash:sha256(r),previousHash:history.at(-1)?.eventHash||null};history.push({...body,eventHash:sha256(body)});
 }
 validateHistory(history);
 const zeroCandidateReason=selected.length?null:records.some(r=>r.blockerCodes.length)?'VERIFIED_INPUTS_AND_EXPLICIT_REVIEW_REQUIRED_NO_FORCED_SELECTION':decisions.length?'EXPLICIT_REVIEW_SELECTED_NONE':'THESIS_INPUT_NOT_PROVIDED';
 const out={schema:MH_SCHEMA,runId,analysisAsOf:input.analysisAsOf,sourceAsOf:input.sourceAsOf,sourceSnapshotId,previousPacketHash:previousPacket?.packetHash||null,rules:MH_RULES,scopeLabel:'검토한 범위 내 대표 후보',reviewedInstrumentIds:input.dossiers.map(d=>d.instrumentId),long:records.filter(r=>r.selected&&r.mainHorizon==='LONG'),medium:records.filter(r=>r.selected&&r.mainHorizon==='MEDIUM'),zeroCandidateReason,records,history,historyHead:history.at(-1)?.eventHash||null,concentrationWarnings,legacyContext:clone(input.legacyContext),automaticTradingAllowed:false,actionAllowed:false,technicalScoreContribution:0,investmentPerformanceApproval:'HOLD',independentApproval:'HOLD',scenarioStatus:MH_RULES.scenarioStatus};
 return {...out,packetHash:sha256(out)};
}
