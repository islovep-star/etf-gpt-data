import {derivedRecordEvidence} from './data_record_contract.mjs';
import {hasText,isObject,parseAmount,strictTimestamp,strictDate,round} from './common.mjs';
import {growthChange,scopeCompatible,nextDate,dayCount} from './financial_contract.mjs';

const REPORTS={
  '11011':{label:'FY',kind:'ANNUAL',cumulative:true},
  '11012':{label:'H1',kind:'INTERIM',cumulative:true},
  '11013':{label:'Q1',kind:'QUARTER',cumulative:false},
  '11014':{label:'Q3',kind:'INTERIM',cumulative:true}
};
const ACCOUNT_PATTERNS={
  revenue:[/^(매출액|수익\(매출액\)|영업수익)$/],
  operatingIncome:[/^영업(이익|손실)(\(손실\))?$/],
  profitCommon:[/^보통주.*귀속.*(순이익|순손실)/],
  netIncome:[/^(당기|분기|반기)순(이익|손실)(\(손실\))?$/],
  basicEps:[/^기본주당(이익|손익|순이익)/],dilutedEps:[/^희석주당(이익|손익|순이익)/],
  weightedBasicShares:[/^기본.*가중평균.*주식수/],weightedDilutedShares:[/^희석.*가중평균.*주식수/],
  assets:[/^자산총계$/],liabilities:[/^부채총계$/],equity:[/^자본총계$/],
  commonEquity:[/^보통주자본$/],cash:[/^현금및현금성자산$/],
  operatingCashFlow:[/^영업활동(으로 인한|으로부터의)? ?현금흐름$/],
  capexPpe:[/^유형자산의? ?취득$/],interestExpense:[/^이자비용$/],
  stockBasedCompensation:[/^주식보상비용$/],dividendsPaid:[/^배당금(의)? ?지급$/]
};
const STANDARD_ACCOUNTS={Revenue:'revenue',ProfitLoss:'netIncome',Assets:'assets',Liabilities:'liabilities',Equity:'equity',
 BasicEarningsLossPerShare:'basicEps',DilutedEarningsLossPerShare:'dilutedEps',CashAndCashEquivalents:'cash',
 CashFlowsFromUsedInOperatingActivities:'operatingCashFlow',PurchaseOfPropertyPlantAndEquipment:'capexPpe'};
const INSTANT=new Set(['assets','liabilities','equity','commonEquity','cash','interestBearingDebt','currentDebt','sharesOutstanding']);

export function buildDartCorpCodeUrl(apiKey){
  if(!hasText(apiKey))throw new Error('DART_API_KEY_REQUIRED');
  return `https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key=${encodeURIComponent(apiKey)}`;
}
export function buildDartFinancialUrl({apiKey,corpCode,businessYear,reportCode,fsDiv='CFS'}){
  if(!hasText(apiKey)||!/^\d{8}$/.test(String(corpCode||''))||!/^\d{4}$/.test(String(businessYear||''))||!REPORTS[reportCode]||!['CFS','OFS'].includes(fsDiv))throw new Error('INVALID_DART_FINANCIAL_REQUEST');
  const q=new URLSearchParams({crtfc_key:apiKey,corp_code:corpCode,bsns_year:String(businessYear),reprt_code:reportCode,fs_div:fsDiv});
  return `https://opendart.fss.or.kr/api/fnlttSinglAcntAll.json?${q}`;
}
export function buildDartDisclosureListUrl({apiKey,corpCode,startDate,endDate,pageCount=100}){
  if(!hasText(apiKey)||!/^\d{8}$/.test(String(corpCode||'')))throw new Error('INVALID_DART_LIST_REQUEST');
  const q=new URLSearchParams({crtfc_key:apiKey,corp_code:corpCode,bgn_de:String(startDate).replaceAll('-',''),end_de:String(endDate).replaceAll('-',''),page_count:String(pageCount)});
  return `https://opendart.fss.or.kr/api/list.json?${q}`;
}

function decodeXml(s){return String(s||'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'");}
function tag(block,name){
  const re=new RegExp(`<(?:\\w+:)?${name}[^>]*>([\\s\\S]*?)<\\/(?:\\w+:)?${name}>`,'i');
  const m=String(block).match(re);return m?decodeXml(m[1].trim()):null;
}
export function parseCorpCodeXml(xml,{availableAt,sourceRef='OPENDART_CORP_CODE'}={}){
  strictTimestamp(availableAt,'availableAt');
  const blocks=String(xml||'').match(/<list>[\s\S]*?<\/list>/gi)||[];
  const entries=[];const seen=new Set();
  for(const b of blocks){
    const corpCode=tag(b,'corp_code'),corpName=tag(b,'corp_name'),stockCode=(tag(b,'stock_code')||'').trim(),modifyDate=tag(b,'modify_date');
    if(!/^\d{8}$/.test(corpCode||'')||!/^\d{6}$/.test(stockCode)||!hasText(corpName))continue;
    if(seen.has(stockCode))throw new Error(`DUPLICATE_DART_STOCK_CODE:${stockCode}`);seen.add(stockCode);
    entries.push({symbol:stockCode,corpCode,corpName,modifyDate,availableAt,sourceRef,status:'VERIFIED'});
  }
  if(!entries.length)throw new Error('NO_LISTED_CORP_CODES');
  return entries.sort((a,b)=>a.symbol.localeCompare(b.symbol));
}

function accountKey(row){
 const id=String(row.account_id||'').replace(/^(ifrs-full|ifrs)_/,'');
 if(STANDARD_ACCOUNTS[id])return STANDARD_ACCOUNTS[id];
 const name=String(row.account_nm||row.account_name||'').replace(/\s+/g,' ').trim();
 for(const [key,patterns] of Object.entries(ACCOUNT_PATTERNS))if(patterns.some(re=>re.test(name)))return key;
 return null;
}
function normalizeDate(date){
  const s=String(date||'').replaceAll('.','-').replaceAll('/','-');
  return /^\d{8}$/.test(s)?`${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6)}`:s;
}

export function parseDartFinancialResponse(json,meta){
 if(!isObject(json)||json.status!=='000'||!Array.isArray(json.list))throw new Error(`DART_FINANCIAL_ERROR:${json?.status||'INVALID'}`);
 const {symbol,corpCode,businessYear,reportCode,fsDiv='CFS',filedAt,sourceRef='OPENDART_FNLTT'}=meta||{};
 if(!/^\d{6}$/.test(String(symbol||''))||!/^\d{8}$/.test(String(corpCode||''))||!/^\d{4}$/.test(String(businessYear))||!REPORTS[reportCode]||!['CFS','OFS'].includes(fsDiv))throw new Error('DART_META_REQUIRED');
 strictTimestamp(filedAt,'filedAt');
 const report=REPORTS[reportCode],facts=[],warnings=[];
 const validDate=d=>{try{return strictDate(normalizeDate(d).trim());}catch{return null;}};
 for(const row of json.list){
  // A response identity must never be overwritten by request metadata.
  const requestedIdentity={corp_code:corpCode,bsns_year:String(businessYear),reprt_code:reportCode,rcept_no:meta.filingId??null};
  for(const [field,expected] of Object.entries(requestedIdentity))if(row[field]!==undefined&&row[field]!==null&&String(row[field]).trim()!==''&&expected!==null&&String(row[field]).trim()!==String(expected))throw new Error(`DART_RESPONSE_IDENTITY_MISMATCH:${field}`);
  const responseIdentity=Object.fromEntries(Object.keys(requestedIdentity).map(field=>[field,row[field]===undefined||row[field]===null||String(row[field]).trim()===''?null:String(row[field]).trim()]));
  const responseIdentityVerified=Object.keys(requestedIdentity).every(field=>requestedIdentity[field]!==null&&responseIdentity[field]===String(requestedIdentity[field]));
  if(!responseIdentityVerified)warnings.push('DART_RESPONSE_IDENTITY_METADATA_INCOMPLETE');
  if(row.fs_div&&row.fs_div!==fsDiv)continue;
  const account=accountKey(row);if(!account)continue;
  const sj=row.sj_div||(INSTANT.has(account)?'BS':account==='operatingCashFlow'||account==='capexPpe'||account==='dividendsPaid'?'CF':'IS');
  if(sj==='SCE'||!['BS','IS','CIS','CF'].includes(sj))continue;
  const instant=sj==='BS';if(instant!==INSTANT.has(account))continue;
  const range=String(row.thstrm_dt||'').split('~');
  const end=validDate(row.thstrm_end_dt||meta.reportPeriodEnd||range.at(-1));
  const rawStart=validDate(row.thstrm_start_dt||(range.length===2?range[0]:null));
  const yearStart=validDate(meta.fiscalYearStart)||(reportCode==='11013'||reportCode==='11011'?rawStart:null);
  const quarterStart=validDate(meta.quarterStart)||(reportCode==='11013'?rawStart:null);
  const currency=row.currency||meta.currency||null;
  const unit=/Eps$/.test(account)?currency?`${currency}_PER_SHARE`:null:/Shares$/.test(account)?'SHARES':currency;
  const emit=(field,kind,start,cumulative,label)=>{
   const value=parseAmount(row[field],`dart.${account}.${field}`);if(value===null)return;
   const complete=!!end&&(instant||!!start)&&!!currency&&!!row.sj_div;
   const period=`${businessYear}-${label}`;
   facts.push({key:`fundamental.${account}.${period}.${fsDiv}.${kind}.actual`,account,period,periodStart:instant?null:start,periodEnd:end,periodKind:kind,
    fiscalYear:String(businessYear),fiscalYearStart:yearStart,fiscalQuarter:reportCode==='11013'?1:reportCode==='11012'?2:reportCode==='11014'?3:4,
    value,unit,currency,fsDiv,accountingBasis:meta.accountingBasis||'K_IFRS',reportCode,reportKind:report.kind,cumulative,
    actualOrEstimate:'ACTUAL',instrumentId:symbol,corpCode,filingId:meta.filingId||responseIdentity.rcept_no||null,statement:sj,sourceField:field,responseIdentity,responseIdentityVerified,
    sourceAccount:row.account_id||row.account_nm,shareAdjustmentBasis:meta.shareAdjustmentBasis||null,comparisonBasis:meta.comparisonBasis||null,
    availableAt:filedAt,availabilityBasis:'CALLER_SUPPLIED_FILING_TIMESTAMP',apiFirstSeenVerified:false,
    sourceRef,versionId:meta.versionId||meta.filingId||responseIdentity.rcept_no||`${corpCode}-${businessYear}-${reportCode}-${fsDiv}`,status:complete&&responseIdentityVerified?'VERIFIED':'PARTIAL',realDataVerified:meta.realDataVerified===true&&complete&&responseIdentityVerified});
   if(!complete)warnings.push('DART_PERIOD_CURRENCY_OR_STATEMENT_METADATA_INCOMPLETE');
  };
  if(instant)emit('thstrm_amount','INSTANT',null,false,report.label);
  else if(reportCode==='11011')emit('thstrm_amount','ANNUAL',yearStart,true,'FY');
  else if(sj==='IS'||sj==='CIS'){
   emit('thstrm_amount','QUARTER',quarterStart,false,`Q${reportCode==='11013'?1:reportCode==='11012'?2:3}`);
   // Q1 is already the whole first quarter; do not duplicate an equivalent YTD observation.
   if(reportCode!=='11013')emit('thstrm_add_amount','YTD',yearStart,true,report.label);
  } else emit('thstrm_amount',reportCode==='11013'?'QUARTER':'YTD',yearStart,reportCode!=='11013',report.label);
 }
 return {facts,report:{businessYear,reportCode,...report,fsDiv,filedAt},warnings:[...new Set(facts.length?warnings:[...warnings,'NO_TARGET_ACCOUNTS_FOUND'])]};
}

export function deriveStandaloneQuarter({currentCumulative:a,previousCumulative:b,quarter,availableAt,sourceRef}){
 if(!['Q2','Q3','Q4'].includes(quarter))throw new Error('DERIVATION_QUARTER_INVALID');
 const mismatch=scopeCompatible([a,b],{samePeriod:false});
 if(mismatch||a.account!==b.account)throw new Error(`DERIVATION_INPUT_MISMATCH:${mismatch||'account'}`);
 if(!new Set(['revenue','operatingIncome','netIncome','profitCommon','operatingCashFlow','capexPpe','interestExpense','dividendsPaid','stockBasedCompensation','repurchases']).has(a.account)||!a.cumulative||!['YTD','ANNUAL'].includes(a.periodKind)||!(b.cumulative||b.fiscalQuarter===1)||a.periodStart!==b.periodStart||a.fiscalYear!==b.fiscalYear||!a.fiscalYear||a.fiscalQuarter!==Number(quarter.slice(1))||b.fiscalQuarter!==a.fiscalQuarter-1||a.periodEnd<=b.periodEnd)throw new Error('DERIVATION_PERIOD_MISMATCH');
 if(!a.comparisonBasis||a.comparisonBasis!==b.comparisonBasis)throw new Error('DERIVATION_COMPARISON_BASIS_REQUIRED');
 const at=strictTimestamp(availableAt);if(at<Math.max(strictTimestamp(a.availableAt),strictTimestamp(b.availableAt)))throw new Error('DERIVATION_LOOKAHEAD');
 const start=nextDate(b.periodEnd);const days=dayCount({periodStart:start,periodEnd:a.periodEnd});
 if(days<70||days>110)throw new Error('DERIVATION_QUARTER_LENGTH_MISMATCH');
 return derivedRecordEvidence({...a,key:`fundamental.${a.account}.${a.fiscalYear}-${quarter}.${a.fsDiv}.QUARTER.actual`,period:`${a.fiscalYear}-${quarter}`,periodStart:start,periodKind:'QUARTER',value:a.value-b.value,cumulative:false,
  derived:true,derivationInputs:[a,b],calculationStatus:'CALCULATED',status:a.status==='VERIFIED'&&b.status==='VERIFIED'&&a.realDataVerified===true&&b.realDataVerified===true?'VERIFIED':'PARTIAL',realDataVerified:a.realDataVerified===true&&b.realDataVerified===true,
  availableAt,sourceRef,versionId:`DERIVED:${a.versionId}:${b.versionId}`},[a,b]);
}

function classifyEvent(name){
  const n=String(name||'');
  if(/잠정.*실적|영업.*실적|사업보고서|분기보고서|반기보고서/.test(n))return 'EARNINGS';
  if(/자기주식.*취득/.test(n))return 'BUYBACK';
  if(/자기주식.*소각/.test(n))return 'TREASURY_CANCEL';
  if(/유상증자/.test(n))return 'CAPITAL_RAISE';
  if(/전환사채|신주인수권/.test(n))return 'CB_BW';
  if(/배당/.test(n))return 'DIVIDEND';
  if(/합병|분할|인수/.test(n))return 'M&A';
  if(/최대주주.*변경/.test(n))return 'MAJOR_HOLDER';
  if(/단일판매.*공급계약|수주/.test(n))return 'LARGE_CONTRACT';
  if(/거래정지|거래재개/.test(n))return 'TRADING_HALT';
  return 'OTHER_MAJOR';
}
export function parseDartDisclosureList(json,{symbol,corpCode,retrievedAt,sourceRef='OPENDART_DISCLOSURE_LIST'}={}){
  if(!isObject(json)||json.status!=='000'||!Array.isArray(json.list))throw new Error(`DART_LIST_ERROR:${json?.status||'INVALID'}`);
  strictTimestamp(retrievedAt,'retrievedAt');
  return json.list.map(row=>{
    const d=String(row.rcept_dt||'');const eventDate=/^\d{8}$/.test(d)?`${d.slice(0,4)}-${d.slice(4,6)}-${d.slice(6)}`:null;
    return {key:`event.${row.rcept_no}`,type:classifyEvent(row.report_nm),eventDate,title:row.report_nm,filingId:row.rcept_no,corpCode,instrumentId:symbol,
      availableAt:retrievedAt,availabilityBasis:'OBSERVED_AT_RETRIEVAL_NOT_FILING_TIME',historicalAvailabilityVerified:false,retrievedAt,sourceRef,versionId:row.rcept_no,status:'VERIFIED',facts:{flrName:row.flr_nm||null,remark:row.rm||null}};
  }).filter(x=>x.eventDate);
}

export function summarizeFundamentalFacts(facts){
  const byAccount={};
  for(const f of facts||[]){(byAccount[f.account]??=[]).push(f);}
  for(const rows of Object.values(byAccount))rows.sort((a,b)=>a.period.localeCompare(b.period));
  const ratios={};
  for(const account of ['revenue','operatingIncome','netIncome']){
    const rows=(byAccount[account]||[]).filter(x=>!x.cumulative).slice(-8);
    ratios[account]=rows.map((x,i)=>{const candidates=rows.filter(y=>y.period===x.period.replace(/^(\d{4})/,(_,y)=>String(Number(y)-1))&&!scopeCompatible([x,y],{samePeriod:false})&&x.periodKind===y.periodKind&&x.shareAdjustmentBasis===y.shareAdjustmentBasis);const prior=candidates.length===1?candidates[0]:null;return {period:x.period,value:x.value,...growthChange(x.value,prior?.value),yoyPct:growthChange(x.value,prior?.value).value};});
  }
  return {byAccount,ratios};
}
