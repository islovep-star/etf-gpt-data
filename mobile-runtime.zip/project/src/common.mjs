import crypto from 'node:crypto';

export const isObject = x => !!x && typeof x === 'object' && !Array.isArray(x);
export const hasText = x => typeof x === 'string' && x.trim().length > 0;
export const isFiniteNumber = x => typeof x === 'number' && Number.isFinite(x);
export const nonNegative = x => isFiniteNumber(x) && x >= 0;

export function strictTimestamp(value, field='timestamp') {
  if (!hasText(value) || !/^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d{1,3})?(?:Z|[+-](?:0\d|1[0-4]):[0-5]\d)$/.test(value)) throw new Error(`INVALID_TIME:${field}`);
  strictDate(value.slice(0,10),field);
  const ms = Date.parse(value);
  if (!Number.isFinite(ms)) throw new Error(`INVALID_TIME:${field}`);
  return ms;
}

export function strictDate(value, field='date') {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value||''))) throw new Error(`INVALID_DATE:${field}`);
  const ms = Date.parse(`${value}T00:00:00Z`);
  if (!Number.isFinite(ms) || new Date(ms).toISOString().slice(0,10)!==value) throw new Error(`INVALID_DATE:${field}`);
  return value;
}

export function parseAmount(value, field='amount') {
  if (isFiniteNumber(value)) return value;
  if (value === null || value === undefined || value === '') return null;
  const raw = String(value).trim();
  if (!raw || raw === '-' || raw.toLowerCase() === 'null') return null;
  const negative = /^\(.*\)$/.test(raw) || raw.startsWith('-');
  const normalized = raw.replace(/[(),\s]/g,'').replace(/^-/,'');
  if (!/^\d+(?:\.\d+)?$/.test(normalized)) throw new Error(`INVALID_NUMBER:${field}`);
  const n = Number(normalized);
  if (!Number.isFinite(n)) throw new Error(`INVALID_NUMBER:${field}`);
  return negative ? -n : n;
}

export function stableSort(value) {
  if (Array.isArray(value)) return value.map(stableSort);
  if (isObject(value)) return Object.fromEntries(Object.keys(value).sort().map(k=>[k,stableSort(value[k])]));
  return value;
}
export function stableStringify(value) { return JSON.stringify(stableSort(value)); }
export function sha256(value) { return crypto.createHash('sha256').update(typeof value==='string'?value:stableStringify(value)).digest('hex'); }

export function selectLatestAvailable(records, asOf, keyFn=x=>x.key) {
  const cutoff = strictTimestamp(asOf,'analysis_as_of');
  const groups = new Map();
  for (const record of records||[]) {
    if (!isObject(record)) continue;
    let at;
    try { at = strictTimestamp(record.availableAt,'availableAt'); } catch { continue; }
    if (at > cutoff) continue;
    const key = keyFn(record);
    if (!hasText(key)) continue;
    const arr = groups.get(key)||[];
    arr.push({record,at}); groups.set(key,arr);
  }
  const selected=[]; const conflicts=[];
  for (const [key, arr] of groups) {
    const max = Math.max(...arr.map(x=>x.at));
    const latest=arr.filter(x=>x.at===max).map(x=>x.record);
    const unique = new Map(latest.map(x=>[stableStringify(x),x]));
    if (unique.size>1) { conflicts.push(key); continue; }
    selected.push(latest[0]);
  }
  return {selected,conflicts};
}

export function requireFields(obj, fields, prefix='MISSING_FIELD') {
  if (!isObject(obj)) throw new Error('INVALID_OBJECT');
  for (const f of fields) if (!(f in obj) || obj[f] === null || obj[f] === '') throw new Error(`${prefix}:${f}`);
}

export function clamp(n,min,max){ return Math.min(max,Math.max(min,n)); }
export function round(n,digits=4){ return isFiniteNumber(n)?Math.round(n*10**digits)/10**digits:null; }

// Retain different periods and units; revisions of the same measurement compete.
export function factIdentity(f){return [f?.instrumentId||'',f?.account||f?.key,f?.periodStart||'',f?.periodEnd||f?.period||'',f?.periodKind||'',f?.cumulative??'',f?.unit||'',f?.currency||'',f?.fsDiv||'',f?.accountingBasis||'',f?.actualOrEstimate||'',f?.shareAdjustmentBasis||'',f?.comparisonBasis||''].join('|');}
