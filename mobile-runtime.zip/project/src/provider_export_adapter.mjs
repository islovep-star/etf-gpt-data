import {bindRecordEvidence,validateRecordEnvelope} from './data_record_contract.mjs';
import {hasText,sha256} from './common.mjs';

const scales={CURRENCY:1,MILLIONS_CURRENCY:1e6,SHARES:1,THOUSANDS_SHARES:1e3,PER_SHARE:1,PCT:1,PER_UNIT:1,PCT_PER_YEAR:1};
// Reviewed original-export rows; the extractor must supply the unit/header/column evidence.
export function normalizeProviderExport(rows,{rawArtifacts,asOf}={}){
 return rows.map(row=>{
  if(!Object.hasOwn(scales,row.sourceUnit)||!Number.isFinite(row.sourceValue))throw new Error('EXPLICIT_SOURCE_UNIT_AND_VALUE_REQUIRED');
  if(!hasText(row.unitEvidence)||!hasText(row.matchEvidence)||!hasText(row.sourceAccount))throw new Error('SOURCE_ROW_MATCH_REQUIRED');
  const expected=/Eps$/.test(row.account)?'PER_SHARE':(/Shares$/.test(row.account)||row.account==='sharesOutstanding')?'SHARES':'CURRENCY';
  if((row.recordKind||'FINANCIAL')==='FINANCIAL'&&!(expected==='SHARES'?['SHARES','THOUSANDS_SHARES']:expected==='CURRENCY'?['CURRENCY','MILLIONS_CURRENCY']:['PER_SHARE']).includes(row.sourceUnit))throw new Error('SOURCE_UNIT_ACCOUNT_MISMATCH');
  const artifact=rawArtifacts.find(a=>a.artifactId===row.artifactId);
  const f={...row,key:row.key||`fundamental.${row.account}`,value:row.sourceValue*scales[row.sourceUnit],normalization:{sourceValue:row.sourceValue,sourceUnit:row.sourceUnit,multiplier:scales[row.sourceUnit],unitEvidence:row.unitEvidence},sourceRef:artifact?.url,versionId:`EXPORT:${row.artifactId}:${sha256(row).slice(0,16)}`,actualOrEstimate:'ACTUAL'};
  const bound=bindRecordEvidence(f,{artifact,locator:row.locator,sourceAccount:row.sourceAccount,matchEvidence:row.matchEvidence,recordKind:row.recordKind||'FINANCIAL'});
  const validation=validateRecordEnvelope(bound,{asOf,rawArtifacts});if(!validation.valid)throw new Error(`EXPORT_RECORD_INVALID:${validation.errors.join(',')}`);
  return bound;
 });
}
