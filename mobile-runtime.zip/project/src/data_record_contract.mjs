import {createHash} from 'node:crypto';
import {hasText,isFiniteNumber,strictTimestamp,strictDate,sha256,stableStringify,factIdentity} from './common.mjs';

export const DATA_RECORD_CONTRACT='OBJECTIVE_DATA_RECORD_V2';
export const CONTRACT_COMPATIBILITY={schema:DATA_RECORD_CONTRACT,stockContext:'STOCK_CONTEXT_V1',gptPacket:'GPT_STOCK_ANALYSIS_PACKET_V1',migration:'ADDITIVE_EVIDENCE_ENVELOPE',legacyWithoutEnvelope:'LEGACY_UNVERIFIED_PROVENANCE'};

export function sourceArtifact(bytes,{url,retrievedAt,mediaType,artifactId,transportStatus='RECEIVED'}={}){
 strictTimestamp(retrievedAt);if(!hasText(url)||!hasText(mediaType)||!hasText(artifactId))throw new Error('RAW_ARTIFACT_METADATA_REQUIRED');
 const body=Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes);
 return {schema:'RAW_SOURCE_ARTIFACT_V1',artifactId,url,mediaType,retrievedAt,sha256:createHash('sha256').update(body).digest('hex'),byteLength:body.length,transportStatus,hashEncoding:'RAW_BYTES'};
}

export function validateRecordEnvelope(record,{asOf,rawArtifacts=[],depth=0}={}){
 if(depth>8)return {valid:false,errors:['DERIVATION_DEPTH_LIMIT']};
 if(!record||typeof record!=='object')return {valid:false,errors:['RECORD_REQUIRED']};
 const errors=[];let cutoff;try{cutoff=strictTimestamp(asOf);}catch{errors.push('AS_OF_REQUIRED');}
 if(record?.dataContractVersion!==DATA_RECORD_CONTRACT)errors.push('RECORD_CONTRACT_VERSION_REQUIRED');
 if(!hasText(record?.instrumentId)||!hasText(record?.key)||!hasText(record?.sourceRef)||!hasText(record?.versionId)||!hasText(record?.sourceAccount))errors.push('RECORD_IDENTITY_OR_SOURCE_REQUIRED');
 if(!hasText(record?.unit)||!hasText(record?.currency))errors.push('UNIT_CURRENCY_REQUIRED');
 if(!['VERIFIED','PARTIAL','MISSING','BLOCKED','UNVERIFIED','NOT_APPLICABLE'].includes(record.status))errors.push('RECORD_STATUS_REQUIRED');
 if(record.status==='MISSING'&&record.value!==null)errors.push('MISSING_REQUIRES_NULL');
 if(record?.value===null){if(record.status!=='MISSING')errors.push('NULL_REQUIRES_MISSING');}
 else if(!isFiniteNumber(record?.value))errors.push('VALUE_MUST_BE_FINITE_OR_NULL');
 let available,retrieved,observed;
 try{available=strictTimestamp(record.availableAt);retrieved=strictTimestamp(record.retrievedAt);}catch{errors.push('AVAILABLE_RETRIEVED_TIME_REQUIRED');}
 if(available>cutoff)errors.push('AVAILABLE_AFTER_AS_OF');
 if(retrieved>cutoff)errors.push('RETRIEVED_AFTER_AS_OF');
 if(available>retrieved)errors.push('AVAILABLE_AFTER_RETRIEVAL');
 if(record.observedAt!==null&&record.observedAt!==undefined){try{observed=strictTimestamp(record.observedAt);if(observed>available||observed>retrieved)errors.push('OBSERVATION_TIME_INCONSISTENT');}catch{errors.push('OBSERVED_TIME_INVALID');}}
 if(!['EXACT_PUBLICATION','FIRST_OBSERVED_UPPER_BOUND'].includes(record.availabilityConfidence))errors.push('AVAILABILITY_CONFIDENCE_REQUIRED');
 if(record.availabilityConfidence==='FIRST_OBSERVED_UPPER_BOUND'&&record.availableAt!==record.retrievedAt)errors.push('OBSERVED_AVAILABILITY_MUST_EQUAL_RETRIEVAL');
 if(record.availabilityConfidence==='EXACT_PUBLICATION'&&!hasText(record.publicationTimeEvidence))errors.push('PUBLICATION_TIME_EVIDENCE_REQUIRED');
 if(record.pitVerified===true&&record.availabilityConfidence!=='EXACT_PUBLICATION')errors.push('PIT_CANNOT_BE_PROMOTED_FROM_OBSERVATION');
 if(record.pitVerified===true&&!hasText(record.pitEvidenceRef))errors.push('PIT_VERSION_EVIDENCE_REQUIRED');
 if(!['ORIGINAL_CAPTURE','RESTATED_CAPTURE','DERIVED'].includes(record.revisionState)||record.retainedVersion!==true)errors.push('REVISION_RETENTION_REQUIRED');
 if(!['FINANCIAL','PRICE','FLOW','ETF_METADATA'].includes(record.recordKind))errors.push('RECORD_KIND_REQUIRED');
 for(const field of ['tradeDate','measurementDate'])if(record[field]!==null&&record[field]!==undefined){try{strictDate(record[field]);if(record[field]>asOf?.slice(0,10))errors.push('FUTURE_MEASUREMENT');}catch{errors.push('MEASUREMENT_DATE_INVALID');}}
 if(record.recordKind==='FINANCIAL'){
  if(!['CFS','OFS'].includes(record.fsDiv)||!hasText(record.accountingBasis))errors.push('ACCOUNTING_SCOPE_REQUIRED');
  if(!['INSTANT','QUARTER','YTD','ANNUAL','TTM'].includes(record.periodKind))errors.push('PERIOD_KIND_REQUIRED');
  try{strictDate(record.periodEnd);if(record.periodKind==='INSTANT'){if(record.periodStart!==null)errors.push('INSTANT_START_MUST_BE_NULL');}else{strictDate(record.periodStart);if(record.periodStart>record.periodEnd)errors.push('PERIOD_REVERSED');}}catch{errors.push('PERIOD_DATES_REQUIRED');}
  if(record.actualOrEstimate!=='ESTIMATE'&&record.periodEnd>asOf?.slice(0,10))errors.push('FUTURE_ACTUAL_FINANCIAL_PERIOD');
 }
 const raw=rawArtifacts.find(x=>x.artifactId===record.rawReference?.artifactId);
 if(!raw||raw.sha256!==record.rawReference?.sha256||!hasText(record.rawReference?.locator))errors.push('RAW_REFERENCE_NOT_BOUND');
 if(raw&&Date.parse(raw.retrievedAt)!==retrieved)errors.push('RAW_RETRIEVAL_TIME_MISMATCH');
 if(!['UNVERIFIED','MATCHED_TO_ORIGINAL','CONFLICT'].includes(record.sourceVerification?.status))errors.push('SOURCE_VERIFICATION_REQUIRED');
 if(!['NOT_APPLICABLE','CALCULATED','UNAVAILABLE'].includes(record.calculationStatus))errors.push('CALCULATION_STATUS_REQUIRED');
 if(!['RECEIVED','NOT_SENT','FAILED'].includes(record.transportStatus))errors.push('TRANSPORT_STATUS_REQUIRED');
 if(record.realDataVerified===true&&(record.sourceVerification?.status!=='MATCHED_TO_ORIGINAL'||!hasText(record.sourceVerification?.evidenceRef)||!raw))errors.push('REAL_VERIFICATION_EVIDENCE_REQUIRED');
 if(record.sourceVerification?.status==='CONFLICT'&&record.status!=='BLOCKED')errors.push('CONFLICT_REQUIRES_BLOCKED');
 if(record.status==='VERIFIED'&&record.realDataVerified!==true)errors.push('VERIFIED_REQUIRES_ORIGINAL_MATCH');
 if(record.transportStatus!=='RECEIVED'&&record.realDataVerified===true)errors.push('SOURCE_NOT_RECEIVED');
 if(record.derived===true){
  if(record.sourceVerification?.scope!=='INPUTS_ONLY'||!Array.isArray(record.derivationInputs)||!record.derivationInputs.length)errors.push('DERIVATION_EVIDENCE_REQUIRED');
  else for(const input of record.derivationInputs){
   const c=validateRecordEnvelope(input,{asOf,rawArtifacts,depth:depth+1});
   if(!c.valid){errors.push('INVALID_DERIVATION_INPUT');errors.push(...c.errors.map(e=>'DERIVATION_INPUT:'+e));}
   if((record.status==='VERIFIED'||record.realDataVerified===true)&&(input.status!=='VERIFIED'||input.realDataVerified!==true||input.sourceVerification?.status!=='MATCHED_TO_ORIGINAL'))errors.push('DERIVED_VERIFICATION_EXCEEDS_INPUT_STATUS:'+String(input.status));
   if(Date.parse(input.availableAt)>available)errors.push('DERIVED_AVAILABLE_BEFORE_INPUT');
  }
 }
 return {valid:errors.length===0,errors:[...new Set(errors)]};
}

export function derivedRecordEvidence(result,inputs){
 if(!inputs.every(f=>f.dataContractVersion===DATA_RECORD_CONTRACT))return result;
 const latest=[...inputs].sort((a,b)=>Date.parse(b.retrievedAt)-Date.parse(a.retrievedAt))[0];
 const verified=inputs.every(f=>f.status==='VERIFIED'&&f.realDataVerified===true&&f.sourceVerification?.status==='MATCHED_TO_ORIGINAL');
 return {...result,observedAt:null,availableAt:latest.retrievedAt,retrievedAt:latest.retrievedAt,availabilityConfidence:'FIRST_OBSERVED_UPPER_BOUND',pitVerified:false,
  rawReference:latest.rawReference,rawReferences:inputs.map(f=>f.rawReference),derivationInputs:inputs,revisionState:'DERIVED',retainedVersion:true,
  sourceVerification:{status:verified?'MATCHED_TO_ORIGINAL':'UNVERIFIED',scope:'INPUTS_ONLY',evidenceRef:inputs.map(f=>f.sourceVerification.evidenceRef).join('|')},
  calculationStatus:'CALCULATED',realDataVerified:verified,status:verified?'VERIFIED':'PARTIAL'};
}

export function bindRecordEvidence(fact,{artifact,locator,sourceAccount,observedAt=null,publicationTime=null,publicationTimeEvidence=null,matchEvidence=null,recordKind='FINANCIAL'}={}){
 if(!artifact||!hasText(locator))throw new Error('ORIGINAL_REFERENCE_REQUIRED');
 const record={...fact,dataContractVersion:DATA_RECORD_CONTRACT,recordKind,sourceAccount:sourceAccount||fact.sourceAccount||fact.account,
  observedAt,availableAt:publicationTime||artifact.retrievedAt,retrievedAt:artifact.retrievedAt,
  availabilityConfidence:publicationTime?'EXACT_PUBLICATION':'FIRST_OBSERVED_UPPER_BOUND',publicationTimeEvidence,
  pitVerified:false,pitEvidenceRef:null,revisionState:fact.revisionState||'ORIGINAL_CAPTURE',retainedVersion:true,supersedesVersionId:fact.supersedesVersionId||null,rawReference:{artifactId:artifact.artifactId,sha256:artifact.sha256,locator},
  sourceVerification:{status:matchEvidence?'MATCHED_TO_ORIGINAL':'UNVERIFIED',evidenceRef:matchEvidence},
  calculationStatus:fact.derived?'CALCULATED':'NOT_APPLICABLE',transportStatus:artifact.transportStatus,
  realDataVerified:!!matchEvidence,status:fact.value===null?'MISSING':matchEvidence?'VERIFIED':'PARTIAL'};
 return record;
}

export function toP0Observation(record,{asOf,rawArtifacts}={}){
 const check=validateRecordEnvelope(record,{asOf,rawArtifacts});
 const observationErrors=[];
 const inspect=(f,depth)=>{
  if(depth>8){observationErrors.push('DERIVATION_DEPTH_LIMIT');return;}
  if(!f||f.status!=='VERIFIED'||f.value===null||f.realDataVerified!==true||!f.observedAt)observationErrors.push('SOURCE_OBSERVATION_NOT_VERIFIED:'+String(f?.status));
  if(f?.actualOrEstimate!==undefined&&f.actualOrEstimate!=='ACTUAL'||f?.kind!==undefined&&f.kind!=='OBSERVATION')observationErrors.push('ACTUAL_OBSERVATION_REQUIRED');
  // Research calculations have no supported P0 observation contract. Original
  // provider unit normalization remains eligible; relabeling a derived price does not.
  if(f?.derived===true||f?.revisionState==='DERIVED'||f?.calculationStatus==='CALCULATED')observationErrors.push('DERIVED_RESEARCH_IS_NOT_SOURCE_OBSERVATION');
  if(f?.derived===true&&Array.isArray(f.derivationInputs))for(const input of f.derivationInputs)inspect(input,depth+1);
 };
 inspect(record,0);
 if(!check.valid||observationErrors.length) return {status:'BLOCKED',reason:'P0_SOURCE_OBSERVATION_NOT_READY',errors:[...new Set([...check.errors,...observationErrors])],record};
 return {...record,kind:'OBSERVATION',status:'VERIFIED',evidenceEnvelope:record.rawReference,pitVerified:record.pitVerified===true};
}

// Shared adapter boundary: no source is promoted merely because parsing succeeded.
export function applyRecordEvidence(records,{asOf,rawArtifacts=[],bindings=[]}={}){
 return (records||[]).map(f=>{
  const matches=bindings.filter(b=>b.identity===factIdentity(f)&&b.versionId===f.versionId);
  if(matches.length>1)throw new Error('AMBIGUOUS_EVIDENCE_BINDING');
  const binding=matches[0];
  const record=binding?bindRecordEvidence(f,{...binding,artifact:rawArtifacts.find(a=>a.artifactId===binding.artifactId)}):f;
  if(Object.hasOwn(record,'dataContractVersion')){const check=validateRecordEnvelope(record,{asOf,rawArtifacts});if(!check.valid)throw new Error(`INVALID_DATA_RECORD:${check.errors.join(',')}`);}
  return record;
 });
}

export function versionedPacketEvidence(records){
 const references=records.filter(f=>f?.dataContractVersion===DATA_RECORD_CONTRACT).map(f=>({key:f.key,instrumentId:f.instrumentId,versionId:f.versionId,availableAt:f.availableAt,rawReference:f.rawReference,sourceVerification:f.sourceVerification}));
 return {dataContractVersion:DATA_RECORD_CONTRACT,compatibility:CONTRACT_COMPATIBILITY,recordReferences:references,legacyRecordCount:records.length-references.length,referenceHash:sha256(stableStringify(references))};
}
