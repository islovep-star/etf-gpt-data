import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {stableStringify} from './common.mjs';

// Bounded reviewed export fixture, not a registry accepting caller-supplied approvals.
// Updating this captured transcription requires source re-extraction and review.
const reviewedSha256='ffe023521b3b6a6ea4413fa00426486503dc6b4b47d34903514049580cecaba6';
const reviewedPath=new URL('../data/phase04_08/reviewed_core_rows.json',import.meta.url);
const hash=x=>createHash('sha256').update(x).digest('hex');

export function assertReviewedProductMetadata(product,{instrumentId,rawArtifacts=[]}={}){
 if(instrumentId!=='379810')throw new Error('PRODUCT_REVIEWED_TRANSCRIPTION_REQUIRED');
 const bytes=fs.readFileSync(reviewedPath);
 if(hash(bytes)!==reviewedSha256)throw new Error('PRODUCT_REVIEWED_TRANSCRIPTION_HASH_MISMATCH');
 const reviewed=JSON.parse(bytes);
 for(const [key,artifactId,locator] of [['monthly','kodex_20260831_pdf','page=1'],['pcf','kodex_holdings_20260923_xls','www.kodex.com!A1:G106']]){
  const source=reviewed.artifacts.find(a=>a.artifactId===artifactId);
  const actual=rawArtifacts.filter(a=>a.artifactId===artifactId);
  if(actual.length!==1||actual[0].sha256!==source.sha256)throw new Error('PRODUCT_REVIEWED_RAW_SOURCE_REQUIRED');
  const expected={...reviewed[key],rawReference:{artifactId,sha256:source.sha256,locator}};
  if(stableStringify(product[key])!==stableStringify(expected))throw new Error('PRODUCT_REVIEWED_VALUES_MISMATCH:'+key);
 }
 if(product.benchmark!==reviewed.monthly.benchmark||product.fundType!=='EQUITY')throw new Error('PRODUCT_REVIEWED_DEFINITION_MISMATCH');
 if(product.reportedManagementFee?.value!==reviewed.monthly.managementFeePct||product.reportedManagementFee?.definition!==reviewed.monthly.managementFeeDefinition)throw new Error('PRODUCT_REVIEWED_FEE_MISMATCH');
 return {status:'MATCHED_TO_REVIEWED_TRANSCRIPTION',reviewedSha256,scope:'ONE_BOUNDED_EXPORT_SAMPLE_NOT_GENERIC_SOURCE_AUTHENTICATION'};
}
