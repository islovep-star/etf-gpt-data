import {buildStockContext,stockContextCapabilities} from './stock_context_pipeline.mjs';
import {buildCompactStockPacket} from './stock_context_schema.mjs';
import {inspectR1521Quality} from '../vendor/p0/src/r1521_quality_adapter.mjs';
import {evaluateReview,publicDiagnostic} from '../vendor/p0/src/review_guard.mjs';
import {buildSixLayerContext} from '../vendor/g03g09/g08_six_layer_context.mjs';
import {buildIntegratedPortfolio} from '../vendor/g03g09/g09_integrated_portfolio.mjs';
import {sha256,hasText,strictTimestamp} from './common.mjs';
import {buildEtfMetrics} from './etf_metrics.mjs';
import {assertTechnicalScope} from './temporal_scope.mjs';

export function adaptR1521Technical(body,{frames=['daily','weekly'],requiredMAPeriods=[10,20,60,112,224],analysisAsOf}={}){
  // A standalone adapter still checks internal frame dates against its declared date.
  const cutoff=analysisAsOf||(/^\d{4}-\d{2}-\d{2}$/.test(body?.asOf||'')?body.asOf+'T23:59:59.999Z':body?.asOf);
  if(cutoff)assertTechnicalScope(body,{asOf:cutoff,instrumentId:body?.symbol});
  const quality=inspectR1521Quality(body,{frames,usesVolume:true,requiredMAPeriods});
  const technical={
    schema:'TECHNICAL_CONTEXT_V1',instrumentId:body?.symbol||null,asOf:body?.asOf||null,workerVersion:body?.workerVersion||null,
    frames:Object.fromEntries(frames.map(f=>[f,body?.frames?.[f]||null])),quality,
    objectiveDataOnly:true,judgement:'NONE',automaticTradingAllowed:false
  };
  return technical;
}

export function buildDecisionSupportBundle(input){
  const {assetMode='STOCK',analysisAsOf}=input||{};strictTimestamp(analysisAsOf,'analysisAsOf');
  if(!['ETF','STOCK'].includes(assetMode))throw new Error('ASSET_MODE_REQUIRED');
  const targets=[assetMode==='STOCK'?input.stockContextInput?.identity?.symbol:input.etfMetricsInput?.instrumentId,input.r1521Body?.symbol,input.sixLayerInput?.instrument_id,input.reviewContract?.targetInstrumentId].filter(Boolean);
  if(new Set(targets).size>1)throw new Error('BUNDLE_IDENTITY_MISMATCH');
  if(input.sixLayerInput&&input.reviewContract&&input.sixLayerInput.account_id!==input.reviewContract.scopeId)throw new Error('BUNDLE_ACCOUNT_SCOPE_MISMATCH');
  if(input.reviewContract&&input.integratedPortfolioInput?.assessments?.some(a=>a.account_id!==input.reviewContract.scopeId))throw new Error('BUNDLE_ACCOUNT_SCOPE_MISMATCH');
  if(input.r1521Body)assertTechnicalScope(input.r1521Body,{asOf:analysisAsOf,instrumentId:targets[0]||input.r1521Body.symbol});
  const result={schema:'ETF_STOCK_DECISION_SUPPORT_BUNDLE_V1',analysisAsOf,assetMode,automaticTradingAllowed:false,orderExecution:false,judgement:'NONE',sections:{},blockers:[],warnings:[]};

  if(assetMode==='STOCK'){
    const stockContext=buildStockContext({...input.stockContextInput,asOf:analysisAsOf});
    const packet=buildCompactStockPacket(stockContext);
    result.sections.stockContext=stockContext;
    result.sections.gptPacket=packet;
    result.sections.capabilities=stockContextCapabilities(stockContext);
    if(stockContext.dataQuality.status!=='VERIFIED')result.warnings.push('STOCK_CONTEXT_PARTIAL_OR_UNVERIFIED');
    result.blockers.push(...stockContext.dataQuality.blockers);
  } else if(input.r1521Body){
    result.sections.technical=adaptR1521Technical(input.r1521Body,{...input.technicalOptions,analysisAsOf});
    if(!result.sections.technical.quality.numericResearchUsable)result.blockers.push('R1521_TECHNICAL_NOT_USABLE');
    if(!result.sections.technical.quality.actionEvidenceReady)result.warnings.push('R1521_NOT_ACTION_EVIDENCE');
  }

  if(input.sixLayerInput){
    if(input.sixLayerInput.analysis_as_of!==analysisAsOf)throw new Error('SIX_LAYER_TIME_MISMATCH');
    result.sections.sixLayerContext=buildSixLayerContext(input.sixLayerInput);
  }
  if(assetMode==='ETF'){
    if(input.etfMetricsInput){
      if(input.etfMetricsInput.asOf&&input.etfMetricsInput.asOf!==analysisAsOf)throw new Error('ETF_METRICS_TIME_MISMATCH');
      if(input.r1521Body?.symbol&&input.etfMetricsInput.instrumentId!==input.r1521Body.symbol)throw new Error('ETF_METRICS_IDENTITY_MISMATCH');
      result.sections.etfMetrics=buildEtfMetrics({...input.etfMetricsInput,asOf:analysisAsOf});
    } else result.sections.etfMetrics={status:'MISSING',reason:'ETF_OBJECTIVE_INPUT_REQUIRED',corporateEps:'NOT_APPLICABLE'};
  }
  if(input.integratedPortfolioInput){
    if(input.integratedPortfolioInput.analysis_as_of!==analysisAsOf)throw new Error('PORTFOLIO_TIME_MISMATCH');
    result.sections.integratedPortfolio=buildIntegratedPortfolio(input.integratedPortfolioInput);
  }
  if(input.reviewPacket||input.reviewContract){
    if(!input.reviewPacket||!input.reviewContract)throw new Error('REVIEW_PACKET_AND_CONTRACT_REQUIRED');
    if(input.reviewPacket.asOf!==analysisAsOf)throw new Error('P0_REVIEW_TIME_MISMATCH');
    const review=evaluateReview(input.reviewPacket,input.reviewContract);
    result.sections.p0Review=review;
    result.sections.publicP0Diagnostic=publicDiagnostic(review);
    result.blockers.push(...review.blockers.map(x=>`P0:${x}`));
  }

  result.blockers=[...new Set(result.blockers)];result.warnings=[...new Set(result.warnings)];
  result.dataViewAvailable=true;
  result.readyForHumanReview=result.blockers.length===0&&result.sections.p0Review?.humanReviewCandidate===true;
  result.independentReviewStatus='HOLD';
  result.actionAllowed=false;
  result.hash=sha256(result);
  return result;
}

export function assertNoAutomaticAction(bundle){
  const serialized=JSON.stringify(bundle);
  if(bundle?.automaticTradingAllowed!==false||bundle?.orderExecution!==false)throw new Error('AUTO_ACTION_FLAG_VIOLATION');
  if(/"orderPayload"\s*:\s*\{/.test(serialized))throw new Error('ORDER_PAYLOAD_PRESENT');
  return true;
}
