import {decodeDartCorpArchive} from './dart_zip.mjs';
import {buildDartCorpCodeUrl,buildDartFinancialUrl,buildDartDisclosureListUrl,parseCorpCodeXml,parseDartFinancialResponse,parseDartDisclosureList} from './dart_adapter.mjs';
import {buildKrxRequest,parseKrxStockDaily,parseKrxInvestorFlow} from './krx_adapter.mjs';
import {normalizeCik,buildSecSubmissionsUrl,buildSecCompanyFactsUrl,buildSecFilingBaseUrl,secHeaders,discoverFilings,buildSecFundamentalFacts,parse13FInfoTableXml} from './sec_adapter.mjs';

async function request(url,{fetchImpl=fetch,headers={},timeoutMs=20000,responseType='json'}={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{
    const r=await fetchImpl(url,{headers,signal:controller.signal});
    if(!r?.ok)throw new Error(`HTTP_${r?.status||0}`);
    if(responseType==='bytes')return new Uint8Array(await r.arrayBuffer());
    return responseType==='text'?await r.text():await r.json();
  }catch(e){if(e?.name==='AbortError')throw new Error('UPSTREAM_TIMEOUT');throw e;}
  finally{clearTimeout(timer);}
}

export async function fetchDartCorpMap({apiKey,availableAt,fetchImpl}){
  const bytes=await request(buildDartCorpCodeUrl(apiKey),{fetchImpl,responseType:'bytes'});
  const xml=decodeDartCorpArchive(bytes);
  return parseCorpCodeXml(xml,{availableAt,sourceRef:'OPENDART_CORP_CODE'});
}
export async function fetchDartFinancial(args){
  for(const key of ['corpCode','businessYear','reportCode','fsDiv']){
    const requested=args[key]??(key==='fsDiv'?'CFS':undefined),parsed=args.meta?.[key]??(key==='fsDiv'?'CFS':undefined);
    if(requested===undefined||parsed===undefined||String(requested)!==String(parsed))throw new Error(`DART_REQUEST_META_MISMATCH:${key}`);
  }
  const json=await request(buildDartFinancialUrl(args),{fetchImpl:args.fetchImpl});
  return parseDartFinancialResponse(json,args.meta);
}
export async function fetchDartDisclosures(args){
  const json=await request(buildDartDisclosureListUrl(args),{fetchImpl:args.fetchImpl});
  return parseDartDisclosureList(json,args.meta);
}
export async function fetchKrxService({apiKey,basDd,config,asOf,mode='DAILY',symbol,availableAt,sourceRef,fetchImpl,turnoverScope=null}){
  const req=buildKrxRequest({apiKey,basDd,config,asOf});
  const json=await request(req.url,{fetchImpl,headers:req.headers});
  return mode==='FLOW'?parseKrxInvestorFlow(json,{symbol,availableAt,sourceRef,serviceId:config.serviceId,basDd,turnoverScope}):parseKrxStockDaily(json,{symbol,availableAt,sourceRef,serviceId:config.serviceId,basDd});
}
export async function fetchSecCompanyData({cik,instrumentId,asOf,userAgent,fetchImpl}){
  const headers=secHeaders(userAgent);
  const [submissions,companyFacts]=await Promise.all([
    request(buildSecSubmissionsUrl(cik),{fetchImpl,headers}),
    request(buildSecCompanyFactsUrl(cik),{fetchImpl,headers})
  ]);
  if(normalizeCik(submissions.cik)!==normalizeCik(cik))throw new Error('SEC_SUBMISSIONS_CIK_MISMATCH');
  const diagnostics=[],filings=discoverFilings(submissions,{asOf,diagnostics});
  const fundamentalFacts=buildSecFundamentalFacts(companyFacts,{cik,instrumentId,asOf,filings,diagnostics});
  return {filings,fundamentalFacts,diagnostics,warnings:['SEC_ACCEPTANCE_TIME_IS_NOT_API_FIRST_SEEN_TIME','SEC_OLDER_SUBMISSIONS_FILES_NOT_YET_COLLECTED',...(diagnostics.length?['SEC_RECORDS_QUARANTINED']:[])]};
}
export async function fetchSec13F({managerCik,accessionNumber,informationTableFile,periodEnd,availableAt,userAgent,fetchImpl}){
  const base=buildSecFilingBaseUrl({cik:managerCik,accessionNumber});
  const xml=await request(base+informationTableFile,{fetchImpl,headers:secHeaders(userAgent),responseType:'text'});
  return parse13FInfoTableXml(xml,{managerCik,accessionNumber,periodEnd,availableAt});
}
