import {assertNoSecrets} from './basic_release_input.mjs';
import {assertTechnicalScope} from './temporal_scope.mjs';

export const ETF_WORKER_ORIGIN='https://etf-market-api.islovep.workers.dev';
export function checkWorkerEtfTarget(t){
 const c=t.config,i=c?.identity;
 if(Object.keys(t).some(k=>!['provider','config'].includes(k))||!c||Object.keys(c).some(k=>k!=='identity')||!i||Object.keys(i).some(k=>!['symbol','instrumentName','market','assetType'].includes(k)))throw Error('REFRESH_WORKER_TARGET_FIELDS');
 if(i.assetType!=='ETF'||!['KR','US'].includes(i.market)||typeof i.instrumentName!=='string'||!i.instrumentName.trim()||i.instrumentName.length>200||!/^[A-Z0-9._-]{1,20}$/.test(i.symbol||'')||i.symbol.endsWith('.KS'))throw Error('REFRESH_WORKER_ETF_IDENTITY_REQUIRED');
 if(i.market==='KR'&&!/^(?:[0-9]{6}|[0-9]{4}[A-Z][0-9])$/.test(i.symbol))throw Error('REFRESH_WORKER_ETF_MARKET_MISMATCH');
}
// Public per-symbol endpoint: no snapshot secrets, six-symbol pilot or KV writes.
export async function collectWorkerEtf({identity,fetchImpl,asOf}){
 const u=new URL('/',ETF_WORKER_ORIGIN);u.searchParams.set('action','gpt-data');u.searchParams.set('symbol',identity.symbol);
 const r=await fetchImpl(u.toString(),{method:'GET',headers:{Accept:'application/json'},credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(90000)});
 if(!r.ok)throw Error('WORKER_ETF_HTTP_'+r.status);
 if(!(r.headers.get('content-type')||'').toLowerCase().includes('application/json'))throw Error('WORKER_ETF_JSON_REQUIRED');
 let body;try{body=await r.json();}catch{throw Error('WORKER_ETF_JSON_REQUIRED');}
 assertNoSecrets(body);
 if(body?.ok!==true||body.schema!=='ETF_GPT_NUMERIC_DIRECT_V1'||body.workerVersion!=='R15.21-QUALITY'||body.symbol!==identity.symbol||body.yahooSymbol!==(identity.market==='KR'?identity.symbol+'.KS':identity.symbol)||body.dataQuality?.validated!==true||body.judgement!=='NONE')throw Error('WORKER_ETF_CONTRACT_MISMATCH');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(body.asOf||''))throw Error('WORKER_ETF_DATA_DATE_REQUIRED');
 for(const f of ['daily','weekly','monthly'])if(!body.frames?.[f]?.latest||!Array.isArray(body.frames[f].records)||!body.frames[f].records.length)throw Error('WORKER_ETF_FRAME_REQUIRED');
 const collectedAt=asOf();const age=(Date.parse(collectedAt)-Date.parse(body.asOf))/86400000;
 if(!Number.isFinite(age)||age<0||age>7)throw Error('WORKER_ETF_DATA_DATE_OUTSIDE_WINDOW');
 assertTechnicalScope(body,{asOf:collectedAt,instrumentId:identity.symbol});
 return {input:{assetMode:'ETF',analysisAsOf:collectedAt,etfMetricsInput:{instrumentId:identity.symbol,instrumentName:identity.instrumentName,asOf:collectedAt,fundType:'OTHER'},sourceFacts:[],r1521Body:body,technicalSource:{sourceRef:u.toString(),retrievedAt:collectedAt,status:'COLLECTED_NOT_INDEPENDENTLY_SOURCE_CERTIFIED'}}};
}
