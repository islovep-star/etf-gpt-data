import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {digest} from './review_run_store.mjs';
import {vapidAuthorization,un64} from '../deployment/basic_app/push.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),app=path.join(root,'deployment/basic_app');
export const APP_ACCOUNT_ID='4c3526cb7cb53a75a01bca05756de22f';
export const APP_COMPATIBILITY_DATE='2026-07-30';
const SECRET_NAMES=['BASIC_PWA_READ_TOKEN','BASIC_APP_ADMIN_TOKEN','VAPID_PRIVATE_JWK'];
function safeConfig(c){
 if(!c||Object.keys(c).some(k=>!['name','account_id','main','compatibility_date','workers_dev','assets','kv_namespaces','vars'].includes(k)))throw Error('APP_CONFIG_FIELDS_INVALID');
 if(c.name!=='etf-basic-app'||c.account_id!==APP_ACCOUNT_ID||c.main!=='worker.mjs'||c.compatibility_date!==APP_COMPATIBILITY_DATE||c.workers_dev!==true)throw Error('APP_TARGET_OR_RUNTIME_MISMATCH');
 if(!c.assets||c.assets.directory!=='./public'||c.assets.binding!=='ASSETS'||c.assets.run_worker_first!==true||Object.keys(c.assets).some(k=>!['directory','binding','run_worker_first'].includes(k)))throw Error('APP_ASSET_ROUTING_REQUIRED');
 if(!Array.isArray(c.kv_namespaces)||c.kv_namespaces.length!==1||c.kv_namespaces[0].binding!=='BASIC_APP_KV'||Object.keys(c.kv_namespaces[0]).some(k=>!['binding','id'].includes(k))||!/^[0-9a-f]{32}$/i.test(c.kv_namespaces[0].id||'')||/^0+$/.test(c.kv_namespaces[0].id))throw Error('NEW_APP_KV_ID_REQUIRED');
 if(!c.vars||Object.keys(c.vars).some(k=>!['VAPID_PUBLIC_KEY','VAPID_SUBJECT'].includes(k)))throw Error('SECRETS_MUST_STAY_OUTSIDE_WRANGLER_CONFIG');
 if(!/^[A-Za-z0-9_-]{87}$/.test(c.vars.VAPID_PUBLIC_KEY||''))throw Error('VAPID_PUBLIC_KEY_REQUIRED');
 if(!/^mailto:[^\s@]+@[^\s@]+$/.test(c.vars.VAPID_SUBJECT||'')||c.vars.VAPID_SUBJECT.includes('REPLACE_'))throw Error('VAPID_CONTACT_REQUIRED');
 return c;
}
export async function inspectMobileDeployment({configFile=path.join(app,'wrangler.json'),env=process.env,configOnly=false}={}){
 const report={schema:'BASIC_APP_DEPLOYMENT_PREFLIGHT_V1',status:'BLOCKED_CONFIGURATION_REQUIRED',configuration:{status:'MISSING'},assets:{status:'UNVERIFIED'},runtimeSecrets:{scope:'LOCAL_PROCESS_ONLY_NOT_CLOUDFLARE_REGISTRATION',requiredNames:SECRET_NAMES,missingNames:SECRET_NAMES.filter(n=>!env[n]),status:configOnly?'NOT_CHECKED':'UNVERIFIED'},accountAccess:'UNVERIFIED_NO_ACCOUNT_API_CALL',deploymentAuthorized:false,remoteKVIdentityVerified:false,networkRequestsPerformed:false,filesWritten:false};
 let c,configDir=app;
 try{const p=fs.realpathSync(configFile);if(!fs.statSync(p).isFile()||fs.statSync(p).size>65536)throw Error('APP_CONFIG_FILE_INVALID');c=safeConfig(JSON.parse(fs.readFileSync(p)));configDir=path.dirname(p);for(const name of ['worker.mjs','push.mjs']){const f=path.join(configDir,name);if(fs.realpathSync(f)!==f||digest(fs.readFileSync(f))!==digest(fs.readFileSync(path.join(app,name))))throw Error('APP_WORKER_MODULE_MISMATCH');}report.configuration={status:'VALID',workerName:c.name,compatibilityDate:c.compatibility_date,configHash:digest(fs.readFileSync(p))};}
 catch(e){report.configuration.reason=fs.existsSync(configFile)?(typeof e.message==='string'&&/^[A-Z_]+$/.test(e.message)?e.message:'APP_CONFIG_JSON_INVALID'):'WRANGLER_CONFIG_REQUIRED';}
 try{
  const publicDir=path.join(configDir,'public'),receipt=JSON.parse(fs.readFileSync(path.join(app,'asset_build_receipt.json'))),seen=new Set();
  for(const f of receipt.files){const p=path.resolve(publicDir,f.path);if(!p.startsWith(publicDir+path.sep)||fs.realpathSync(p)!==p||seen.has(f.path)||digest(fs.readFileSync(p))!==f.sha256)throw Error('APP_ASSET_INTEGRITY_FAILURE');seen.add(f.path);}
  const walk=dir=>{for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isSymbolicLink())throw Error('APP_ASSET_SYMLINK_BLOCKED');if(e.isDirectory())walk(p);else if(!seen.has(path.relative(publicDir,p).split(path.sep).join('/')))throw Error('UNLISTED_PUBLIC_ASSET_BLOCKED');}};walk(publicDir);
  if(receipt.assetsOnly!==true||receipt.containsRunData!==false)throw Error('APP_ASSET_RECEIPT_INVALID');report.assets={status:'MATCHED_BUILD_BYTES',fileCount:seen.size};
 }catch{report.assets={status:'BLOCKED',reason:'APP_ASSET_INTEGRITY_OR_PRIVATE_FILE_FAILURE'};}
 if(!configOnly){
  if(report.runtimeSecrets.missingNames.length)report.runtimeSecrets.status='MISSING';
  else if(![env.BASIC_PWA_READ_TOKEN,env.BASIC_APP_ADMIN_TOKEN].every(s=>typeof s==='string'&&/^[A-Za-z0-9_-]{24,256}$/.test(s))||env.BASIC_PWA_READ_TOKEN===env.BASIC_APP_ADMIN_TOKEN)report.runtimeSecrets={...report.runtimeSecrets,status:'BLOCKED',reason:'DISTINCT_VALID_APP_TOKENS_REQUIRED'};
  else if(c)try{
   const authorization=await vapidAuthorization('https://fcm.googleapis.com/LOCAL_PREFLIGHT_ONLY',{...env,...c.vars}),jwt=authorization.split('t=')[1].split(',')[0].split('.'),key=await crypto.subtle.importKey('raw',un64(c.vars.VAPID_PUBLIC_KEY),{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
   if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,un64(jwt[2]),new TextEncoder().encode(jwt.slice(0,2).join('.'))))throw Error('VAPID_KEY_PAIR_MISMATCH');report.runtimeSecrets.status='LOCAL_SIGNATURE_AND_ROLES_CHECKED';
  }catch{report.runtimeSecrets={...report.runtimeSecrets,status:'BLOCKED',reason:'VAPID_CONFIG_OR_SIGNATURE_INVALID'};}
 }
 const localConfigReady=report.configuration.status==='VALID'&&report.assets.status==='MATCHED_BUILD_BYTES';
 report.status=localConfigReady&&(configOnly||report.runtimeSecrets.status==='LOCAL_SIGNATURE_AND_ROLES_CHECKED')?(configOnly?'LOCAL_CONFIG_READY_REMOTE_SECRETS_UNVERIFIED':'LOCAL_CONFIG_AND_SECRET_FORMATS_READY_REMOTE_ACCESS_UNVERIFIED'):'BLOCKED_CONFIGURATION_REQUIRED';
 return report;
}
export function prepareMobileConfig({kvId,publicKey,contact,outputFile=path.join(app,'wrangler.json')}={}){
 const c=safeConfig({name:'etf-basic-app',account_id:APP_ACCOUNT_ID,main:'worker.mjs',compatibility_date:APP_COMPATIBILITY_DATE,workers_dev:true,assets:{directory:'./public',binding:'ASSETS',run_worker_first:true},kv_namespaces:[{binding:'BASIC_APP_KV',id:kvId}],vars:{VAPID_PUBLIC_KEY:publicKey,VAPID_SUBJECT:contact}});
 // Exclusive create preserves a pre-existing real deployment configuration.
 fs.writeFileSync(outputFile,JSON.stringify(c,null,2)+'\n',{flag:'wx',mode:0o600});return {status:'LOCAL_WRANGLER_CONFIG_CREATED',workerName:c.name,secretsWritten:false,networkRequestsPerformed:false,deployed:false};
}
