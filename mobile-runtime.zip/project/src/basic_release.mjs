import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {prepareBasicData,checkBasicRules} from './basic_release_input.mjs';
import {beginReviewRun,completeReviewRun,validateReviewRun,digest,classifyReviewError} from './review_run_store.mjs';
import {buildMultiHorizonDossiers,projectLegacyReviewSummary} from './multi_horizon_dossiers.mjs';
import {prepareMultiHorizonInput,buildMultiHorizonPacket} from './multi_horizon.mjs';
import {lockMultiHorizonOutput,previousMultiHorizonRun} from './multi_horizon_run.mjs';
import {buildGlobalEnvironment} from './global_environment.mjs';
import {bindGlobalSourceReferences,readBoundGlobalSource} from './global_environment_sources.mjs';
import {buildCapturedGlobalConfig} from '../tools/build_captured_global_config.mjs';
import {adaptR1521Technical} from './unified_pipeline.mjs';
import {classifyAssetRotationWithEvidence} from '../vendor/g03g09/g03_engine.mjs';
import {classifyCountryMarketsWithEvidence} from '../vendor/g03g09/g04_market_board.mjs';
import {buildSectorThemeBoardWithEvidence} from '../vendor/g03g09/g05_evidence_overlap.mjs';
import {buildPortfolioApplication} from '../vendor/g03g09/g06_portfolio_accounts.mjs';
import {buildDecisionBoard} from '../vendor/g03g09/g07_decision_output.mjs';
import {buildSixLayerContext} from '../vendor/g03g09/g08_six_layer_context.mjs';
import {buildIntegratedPortfolio} from '../vendor/g03g09/g09_integrated_portfolio.mjs';
import {renderBasicRelease} from './basic_release_view.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
export const MODULES={assetRotation:{label:'자산군 상대 흐름',build:classifyAssetRotationWithEvidence},countryMarkets:{label:'국가·시장·시장 폭',build:classifyCountryMarketsWithEvidence},sectorTheme:{label:'섹터·테마·중복노출',build:buildSectorThemeBoardWithEvidence},portfolio:{label:'보유·계좌',build:buildPortfolioApplication},decisionBoard:{label:'종합 검토 출력',build:buildDecisionBoard},sixLayer:{label:'6계층 검토',build:buildSixLayerContext},integratedPortfolio:{label:'통합 계좌 검토',build:buildIntegratedPortfolio}};
const missing=label=>({status:'MISSING',label,reason:'INPUT_AND_SOURCE_EVIDENCE_REQUIRED',actionAllowed:false,automaticTradingAllowed:false});
const atomic=(p,v)=>{fs.writeFileSync(p+'.next',JSON.stringify(v,null,2)+'\n',{mode:0o600});fs.renameSync(p+'.next',p);};
export function latestBasicRun(outputRoot){
 const head=path.join(outputRoot,'latest.json');if(!fs.existsSync(head))return null;
 const pointer=JSON.parse(fs.readFileSync(head));
 if(pointer.schema!=='BASIC_RELEASE_HEAD_V1'||! /^[A-Za-z0-9_-]{1,64}$/.test(pointer.runId||''))throw Error('INVALID_BASIC_HEAD');
 const dir=path.resolve(outputRoot,'runs',pointer.runId),receipt=validateReviewRun(dir);
 if(receipt.inputHash!==pointer.inputHash||digest(fs.readFileSync(path.join(dir,'run.json')))!==pointer.receiptHash)throw Error('BASIC_HEAD_INTEGRITY_FAILURE');
 return {dir,receipt,runId:pointer.runId};
}
export function buildBasicRelease({config,outputRoot,runId,inputDir,priorRunDir,now=new Date().toISOString()}={}){
 const output=path.resolve(outputRoot);fs.mkdirSync(output,{recursive:true,mode:0o700});
 const release=lockMultiHorizonOutput(output);
 let begun=null;
 try{
  const rules=checkBasicRules(),localHead=latestBasicRun(output);
  if(priorRunDir&&localHead)throw Error('AMBIGUOUS_BASIC_PREVIOUS_RUN');
  const priorReceipt=priorRunDir?validateReviewRun(priorRunDir):null;
  if(priorReceipt&&!priorReceipt.files.some(x=>x.path==='multi_horizon/opportunity_packet.json'))throw Error('BASIC_PREVIOUS_PACKET_NOT_MANIFESTED');
  const previousHead=priorReceipt?{dir:priorRunDir,runId:priorReceipt.runId,receipt:priorReceipt}:localHead;
  const prepared=prepareBasicData(config,{inputDir,now}),{sample,rawFiles,analysisAsOf,mode}=prepared;
  if(config.market&&Object.keys(config.market).some(k=>!['assetRotation','countryMarkets','sectorTheme'].includes(k)))throw Error('UNKNOWN_MARKET_MODULE');
  const sections={};
  for(const [key,{label,build}] of Object.entries(MODULES)){
   const input=['assetRotation','countryMarkets','sectorTheme'].includes(key)?config.market?.[key]:config[key];
   if(!input){sections[key]=missing(label);continue;}
   if(input.analysis_as_of!==analysisAsOf)throw Error('SECTION_ANALYSIS_TIME_MISMATCH:'+key);
   if(key==='portfolio'){
    const seen=new Set();for(const h of input.holdings||[]){const k=h.account_id+'|'+h.instrument_id;if(seen.has(k))throw Error('DUPLICATE_HOLDING_TARGET');seen.add(k);if(Date.parse(h.effective_at)>Date.parse(analysisAsOf))throw Error('FUTURE_HOLDING');}
   }
   if(['decisionBoard','integratedPortfolio'].includes(key)){
    const rows=key==='decisionBoard'?input.cards||[]:input.assessments||[];
    if(rows.some(r=>['NOW_BUY','REDUCE','SELL','PARTIAL_ROTATION'].includes(r.status)))throw Error('BASIC_ACTION_REQUIRES_SEPARATE_TRUSTED_P0_REVIEW');
   }
   if(key==='portfolio')for(const c of input.candidates||[])if(c.domestic_underlying!==true||rules.policy.candidatePolicy.excludedNewCandidateSymbols.includes(c.instrument_id))throw Error('NEW_CANDIDATE_DOMESTIC_UNDERLYING_PROOF_REQUIRED');
   // A submitted reviewed decision remains a review input; this shell grants no trading authority.
   sections[key]={status:'CONTRACT_CHECKED_REVIEW_HOLD',label,result:build(input),actionAllowed:false,automaticTradingAllowed:false};
  }
  sections.technical={status:sample.inputs.some(x=>x.r1521Body)?'CONTRACT_CHECKED_REVIEW_HOLD':'MISSING',label:'일·주봉 기술자료',instruments:sample.inputs.filter(x=>x.r1521Body).map(x=>adaptR1521Technical(x.r1521Body,{...x.technicalOptions,analysisAsOf})),actionAllowed:false};
  const globalConfig=config.globalEnvironment|| (mode==='HISTORICAL_SAMPLE'?buildCapturedGlobalConfig({includeCboe:true}):{});
  if(!config.globalEnvironment)delete globalConfig.analysisAsOf;
  const boundGlobal=bindGlobalSourceReferences(globalConfig);
  const globalEnvironment=buildGlobalEnvironment({analysisAsOf,config:boundGlobal.config,sourceVerification:boundGlobal.manifest});
  sections.globalEnvironment={status:globalEnvironment.status,label:'세계 위험환경',result:globalEnvironment,actionAllowed:false};
  const mh=config.multiHorizon||{};
  if(Object.keys(mh).some(k=>!['registry','market','theses','gptReview','legacyContext'].includes(k)))throw Error('UNSUPPORTED_MULTI_HORIZON_CONFIG');
  const dossierPacket=buildMultiHorizonDossiers(sample,{analysisAsOf});
  const multiInput=prepareMultiHorizonInput({analysisAsOf,sourceAsOf:sample.asOf,ruleProposalSha256:digest(fs.readFileSync(path.join(root,'rulesync/gpt-rules-proposed-v1.1.2.json'))),dossiers:dossierPacket.dossiers,registry:mh.registry,market:mh.market,theses:mh.theses,legacyContext:projectLegacyReviewSummary(mh.legacyContext,{analysisAsOf})});
  const previous=priorReceipt?JSON.parse(fs.readFileSync(path.join(priorRunDir,'multi_horizon/opportunity_packet.json'))):previousMultiHorizonRun(output,{recoverRunId:runId});
  const multi=buildMultiHorizonPacket({input:multiInput,gptReview:mh.gptReview,previousPacket:previous,expectedPreviousPacketHash:previous?.packetHash||null,runId});
  sections.multiHorizon={status:multi.status||'REVIEW_HOLD',label:'장·중기 검토',result:multi,actionAllowed:false};
  const software=fs.readdirSync(path.join(root,'src')).filter(n=>n.endsWith('.mjs')).map(n=>'src/'+n);
  for(const dir of ['vendor/g03g09','vendor/g02','vendor/p0/src'])software.push(...fs.readdirSync(path.join(root,dir)).filter(n=>/\.(mjs|json)$/.test(n)).map(n=>dir+'/'+n));
  software.push('tools/build_core_samples.mjs','tools/build_captured_global_config.mjs');
  const codeHash=digest(software.sort().map(p=>p+':'+digest(fs.readFileSync(path.join(root,p)))).join('\n'));
  const inputHash=digest(JSON.stringify({config,codeHash,ruleSha:rules.blobSha,sourceAsOf:sample.asOf,analysisAsOf,reviewHashes:sample.reviews.map(x=>x.packetHash),raw:sample.artifacts.map(a=>a.sha256),globalHash:globalEnvironment.packetHash,previousHash:previous?.packetHash||null}));
  const run=beginReviewRun(output,runId,inputHash);begun=run;
  if(run.recovered)return {status:'RECOVERED',dir:run.dir,receipt:run.receipt,runId,automaticResend:false};
  const write=(name,data)=>{const p=path.join(run.dir,name);fs.mkdirSync(path.dirname(p),{recursive:true,mode:0o700});fs.writeFileSync(p,typeof data==='string'||Buffer.isBuffer(data)?data:JSON.stringify(data,null,2)+'\n',{mode:0o600});};
  const artifacts=sample.artifacts.map(a=>({...a,reviewLocalPath:'raw/'+a.artifactId+path.extname(rawFiles.get(a.artifactId))}));
  if(mode==='IMPORTED')write('submission/input_claims.json',config);
  for(const a of artifacts){const bytes=fs.readFileSync(rawFiles.get(a.artifactId));if(digest(bytes)!==a.sha256)throw Error('RAW_HASH_CHANGED_DURING_RUN');write(a.reviewLocalPath,bytes);}
  const index={schema:'BASIC_RELEASE_INDEX_V1',generation:runId,asOf:sample.asOf,analysisAsOf,count:sample.reviews.length,scope:mode,items:sample.reviews.map(r=>({instrumentId:r.instrumentId,name:r.instrumentName,assetType:r.assetType,asOf:r.analysisAsOf,detailRef:`details/${r.instrumentId}.json`,historyRef:`history/${r.instrumentId}.json`,status:'REVIEW_HOLD'}))};
  for(const r of sample.reviews){
   write(`details/${r.instrumentId}.json`,{generation:runId,review:r});
   const records=r.assetType==='STOCK'?sample.contexts[r.instrumentId]?.fundamental.history||[]:sample.etfHistory.filter(f=>f.instrumentId===r.instrumentId);
   write(`history/${r.instrumentId}.json`,{generation:runId,instrumentId:r.instrumentId,records});
  }
  write('sources.json',{schema:'REVIEW_RAW_MANIFEST_V1',artifacts});write('index.json',index);
  write('global_environment/context.json',globalEnvironment);write('global_environment/raw_manifest.json',boundGlobal.manifest);
  for(const a of boundGlobal.manifest.artifacts)write(a.reviewLocalPath,readBoundGlobalSource(a));
  write('multi_horizon/dossiers.json',dossierPacket);write('multi_horizon/gpt_review_input.json',multiInput);write('multi_horizon/opportunity_packet.json',multi);
  write('multi_horizon/review_history.json',{schema:'MULTI_HORIZON_HISTORY_V1',head:multi.historyHead,events:multi.history});
  for(const [key,section] of Object.entries(sections))write(`sections/${key}.json`,section);
  const metadata={schema:'BASIC_RELEASE_RUN_V1',runId,mode,analysisAsOf,sourceAsOf:sample.asOf,sourceVerification:mode==='IMPORTED'?'SUBMITTED_CLAIMS_UNVERIFIED_ORIGINAL_PRESERVED':mode==='HISTORICAL_SAMPLE'?'BOUNDED_PREVIOUSLY_MATCHED_SOURCE_SAMPLE':'NO_SOURCES',ruleVersion:rules.version,ruleBlobSha:rules.blobSha,ruleSourceVerifiedAt:rules.sourceVerifiedAt,ruleRemoteRechecked:false,sourceCodeHash:codeHash,objectiveDataOnly:true,automaticTradingAllowed:false,orderExecution:false,investmentApproval:'HOLD',deployment:'NOT_ATTEMPTED',previousRunId:previousHead?.runId||null,operational:{liveApis:'BLOCKED_CONFIGURATION_REQUIRED',targetUniverse:'NOT_APPROVED',mobilePwa:'PENDING_EXISTING_UI_INTEGRATION'}};
  const gpt={schema:'GPT_BASIC_RELEASE_PACKET_V1',generation:runId,metadata,reviews:sample.reviews,sections,detailIndexRef:'index.json',fullSourceManifestRef:'sources.json',fullHistoryPolicy:'READ_LINKED_HISTORY_WHEN_DETAIL_NEEDED',technicalScoreContribution:0,interpretationBy:'GPT',actionAllowed:false,automaticTradingAllowed:false};
  write('gpt_packet.json',gpt);write('program_status.json',metadata);
  write('review.html',renderBasicRelease({metadata,index,reviews:sample.reviews,sections,artifacts}));
  write('README_KO.txt','START 명령 또는 node tools/start_basic.mjs --resume --run-id '+runId+' 로 조회합니다. 과거 표본과 입력자료를 최신 시장/실계좌로 표시하지 않습니다. 모든 원문/전체 이력은 같은 폴더에 보존됩니다. 자동주문·운영 배포 없음.\n');
  const receipt=completeReviewRun(run);validateReviewRun(run.dir,{expectedInputHash:inputHash});
  atomic(path.join(output,'latest.json'),{schema:'BASIC_RELEASE_HEAD_V1',runId,inputHash,receiptHash:digest(fs.readFileSync(path.join(run.dir,'run.json'))),promotedAt:new Date().toISOString()});
  return {status:'COMPLETE',dir:run.dir,receipt,runId,automaticResend:false};
 }catch(e){
  const failure={schema:'BASIC_RELEASE_FAILURE_V1',runId:typeof runId==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(runId)?runId:null,...classifyReviewError(e),reason:String(e.message).slice(0,240),recordedAt:new Date().toISOString(),latestValidRunPreserved:true,pendingRunPreserved:Boolean(begun&&!begun.recovered)};
  fs.mkdirSync(path.join(output,'failures'),{recursive:true,mode:0o700});fs.writeFileSync(path.join(output,'failures',Date.now()+'-'+process.pid+'.json'),JSON.stringify(failure,null,2)+'\n',{mode:0o600});throw e;
 }finally{release();}
}
