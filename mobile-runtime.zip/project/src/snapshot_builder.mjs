import {sha256,hasText,isObject,strictTimestamp} from './common.mjs';

export function buildCompactSnapshot({asOf,items,datasetKind='MIXED',generatorVersion='INTEGRATION_V1',generation,scope}){
  strictTimestamp(asOf,'asOf');if(!Array.isArray(items)||!items.length)throw new Error('SNAPSHOT_ITEMS_REQUIRED');
  const seen=new Set(),normalized=[];
  for(const item of items){
    if(!isObject(item)||!hasText(item.instrumentId)||!hasText(item.instrumentType)||!hasText(item.packetHash))throw new Error('INVALID_SNAPSHOT_ITEM');
    if(seen.has(item.instrumentId))throw new Error(`DUPLICATE_INSTRUMENT:${item.instrumentId}`);seen.add(item.instrumentId);
    normalized.push({...item});
  }
  normalized.sort((a,b)=>a.instrumentId.localeCompare(b.instrumentId));
  const index=Object.fromEntries(normalized.map(x=>[x.instrumentId,{instrumentType:x.instrumentType,asOf:x.asOf||asOf,packetHash:x.packetHash,status:x.status||'AVAILABLE'}]));
  const snapshot={schema:'GPT_COMPACT_MULTI_ASSET_SNAPSHOT_V1',generatedAt:new Date().toISOString(),asOf,datasetKind,generatorVersion,count:normalized.length,items:normalized,index,
    objectiveDataOnly:true,automaticTradingAllowed:false,judgement:'NONE'};
  if(generation!==undefined){if(!hasText(generation))throw new Error('INVALID_SNAPSHOT_GENERATION');snapshot.generation=generation;}
  if(scope!==undefined){if(!hasText(scope))throw new Error('INVALID_SNAPSHOT_SCOPE');snapshot.scope=scope;}
  return {...snapshot,snapshotHash:sha256(snapshot)};
}

export function buildRawSegmentRequest({instrumentId,frame,from,to,reason,analysisAsOf}){
  if(!hasText(instrumentId)||!['daily','weekly','monthly'].includes(frame)||!hasText(reason))throw new Error('INVALID_RAW_SEGMENT_REQUEST');
  strictTimestamp(analysisAsOf,'analysisAsOf');
  return {schema:'RAW_SEGMENT_REQUEST_V1',instrumentId,frame,from:from||null,to:to||null,reason,analysisAsOf,readOnly:true,wholeHistoryRequired:false};
}
