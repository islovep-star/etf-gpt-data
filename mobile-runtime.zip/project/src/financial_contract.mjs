import {isFiniteNumber as finite,hasText,strictTimestamp,strictDate,round,factIdentity,selectLatestAvailable} from './common.mjs';

export const FINANCIAL_SCOPE_FIELDS=['instrumentId','currency','fsDiv','accountingBasis'];
export const nextDate=d=>new Date(Date.parse(`${d}T00:00:00Z`)+86400000).toISOString().slice(0,10);
export const previousDate=d=>new Date(Date.parse(`${d}T00:00:00Z`)-86400000).toISOString().slice(0,10);
export const dayCount=f=>(Date.parse(f?.periodEnd)-Date.parse(f?.periodStart))/86400000+1;
export function scopeCompatible(facts,{samePeriod=true,sameUnit=true}={}){
 if(!facts.length||facts.some(f=>!f||!finite(f.value)))return 'MISSING_INPUT';
 for(const field of FINANCIAL_SCOPE_FIELDS){
  if(facts.some(f=>!hasText(f[field])))return `SCOPE_REQUIRED:${field}`;
  if(new Set(facts.map(f=>f[field])).size!==1)return `SCOPE_MISMATCH:${field}`;
 }
 if(facts.some(f=>hasText(f.comparisonBasis))&&new Set(facts.map(f=>f.comparisonBasis||null)).size!==1)return 'COMPARISON_BASIS_MISMATCH';
 if(facts.some(f=>f.actualOrEstimate!=='ACTUAL'))return 'ACTUAL_BASIS_REQUIRED';
 if(facts.some(f=>!hasText(f.unit)))return 'UNIT_REQUIRED';
 if(sameUnit&&new Set(facts.map(f=>f.unit)).size!==1)return 'UNIT_MISMATCH';
 for(const f of facts){if(!['INSTANT','QUARTER','YTD','ANNUAL','TTM'].includes(f.periodKind))return 'PERIOD_KIND_REQUIRED';
  if(['ANNUAL','TTM'].includes(f.periodKind)&&(dayCount(f)<330||dayCount(f)>380))return 'ANNUAL_PERIOD_LENGTH_MISMATCH';
  if(f.periodKind==='QUARTER'&&(dayCount(f)<70||dayCount(f)>110))return 'QUARTER_PERIOD_LENGTH_MISMATCH';
  try{strictDate(f.periodEnd);if(f.periodKind!=='INSTANT'){strictDate(f.periodStart);if(f.periodStart>f.periodEnd)return 'INVALID_PERIOD';}}catch{return 'PERIOD_REQUIRED';}}
 if(samePeriod&&new Set(facts.map(f=>`${f.periodStart}|${f.periodEnd}|${f.periodKind}`)).size!==1)return 'PERIOD_MISMATCH';
 return null;
}
export function eligibleFact(f,asOf){
 try{return finite(f.value)&&['VERIFIED','PARTIAL'].includes(f.status)&&hasText(f.sourceRef)&&hasText(f.versionId)&&(!f.periodEnd||f.actualOrEstimate==='ESTIMATE'||f.periodEnd<=asOf.slice(0,10))&&strictTimestamp(f.availableAt)<=strictTimestamp(asOf);}catch{return false;}
}
export function metric(key,value,inputs=[],{unit=null,reason=null,formula=null,details={},calculationStatus=null}={}){
 const present=finite(value);const evidence=inputs.filter(Boolean);
 // VERIFIED is reserved for source evidence, not mathematical success.
 const sourceStatus=evidence.length&&evidence.every(f=>f.status==='VERIFIED'&&f.realDataVerified===true)?'VERIFIED':evidence.length?'PARTIAL':'MISSING';
 return {key,value:present?round(value,8):null,unit,status:present?sourceStatus:reason==='NOT_APPLICABLE'?'NOT_APPLICABLE':'MISSING',
  calculationStatus:calculationStatus||(present?'CALCULATED':reason==='NOT_APPLICABLE'?'NOT_APPLICABLE':'UNAVAILABLE'),sourceStatus,reason,formula,
  availableAt:evidence.length?evidence.map(f=>f.availableAt).filter(Boolean).sort((a,b)=>Date.parse(b)-Date.parse(a))[0]||null:null,
  inputs:evidence.map(f=>({...f})),...details};
}
export function financialSelection(facts,{asOf,instrumentId}){
 const accepted=[],quarantined=[];
 for(const f of facts||[]){
  const expectedUnit=/Eps$/.test(f.account||'')?`${f.currency}_PER_SHARE`:/Shares$/.test(f.account||'')||f.account==='sharesOutstanding'?'SHARES':f.account==='effectiveTaxRate'?'FRACTION':f.currency;
  if(f.instrumentId!==instrumentId||!eligibleFact(f,asOf)||f.unit!==expectedUnit||!hasText(expectedUnit))quarantined.push(f);else accepted.push(f);
 }
 const {selected,conflicts}=selectLatestAvailable(accepted,asOf,factIdentity);
 return {selected,history:accepted,conflicts,quarantined};
}
export function growthChange(current,previous){
 const base={value:null,absoluteChange:finite(current)&&finite(previous)?round(current-previous,8):null,lossChangePct:null};
 if(!finite(current)||!finite(previous))return {...base,status:'UNAVAILABLE'};
 if(previous===0)return {...base,status:current===0?'UNCHANGED_ZERO':current>0?'ZERO_TO_PROFIT':'ZERO_TO_LOSS'};
 if(previous<0){
  if(current>0)return {...base,status:'TURNAROUND_TO_PROFIT'};
  if(current===0)return {...base,status:'LOSS_TO_BREAK_EVEN'};
  return {...base,status:current>previous?'LOSS_NARROWED':current<previous?'LOSS_WIDENED':'LOSS_UNCHANGED',lossChangePct:round((Math.abs(current)/Math.abs(previous)-1)*100,4)};
 }
 if(current<0)return {...base,status:'TURNED_TO_LOSS'};
 return {...base,value:round((current/previous-1)*100,4),status:current===0?'PROFIT_TO_BREAK_EVEN':'COMPARABLE'};
}
export function calculateEps({reportedBasic,reportedDiluted,profitCommon,weightedBasicShares,dilutedNumerator,weightedDilutedShares,asOf}){
 const reported=(f,name)=>eligibleFact(f||{},asOf)&&f.account===name&&f.periodKind!=='INSTANT'&&!scopeCompatible([f])&&f.unit===`${f.currency}_PER_SHARE`&&hasText(f.shareAdjustmentBasis);
 const compute=(profit,shares,kind)=>{
  const inputs=[profit,shares];let reason=scopeCompatible(inputs,{sameUnit:false});
  if(!reason&&inputs.some(f=>!eligibleFact(f,asOf)))reason='EVIDENCE_UNAVAILABLE';
  if(!reason&&(profit.unit!==profit.currency||shares.unit!=='SHARES'))reason='UNIT_MISMATCH';
  if(!reason&&(profit.account!== (kind==='BASIC'?'profitCommon':'dilutedEpsNumerator')||shares.account!==(kind==='BASIC'?'weightedBasicShares':'weightedDilutedShares')))reason='EPS_ACCOUNT_BASIS_REQUIRED';
  if(!reason&&(!hasText(shares.shareAdjustmentBasis)||shares.shareAdjustmentBasis!==profit.shareAdjustmentBasis))reason='SHARE_ADJUSTMENT_BASIS_MISMATCH';
  if(!reason&&shares.value<=0)reason='NONPOSITIVE_DENOMINATOR';
  return metric(`eps.${kind.toLowerCase()}`,reason?null:profit.value/shares.value,inputs,{unit:profit?.currency?`${profit.currency}_PER_SHARE`:null,reason,formula:`${kind==='BASIC'?'profit attributable to common':'adjusted diluted EPS numerator'} / weighted average ${kind.toLowerCase()} shares`});
 };
 const choose=(f,profit,shares,kind)=>{
  const calculated=compute(profit,shares,kind),name=kind==='BASIC'?'basicEps':'dilutedEps';
  if(!reported(f,name))return calculated;
  // Original-row transcription and agreement with the EPS arithmetic are separate axes.
  // Keep the issuer's EPS; never replace it with a quotient on a discrepancy.
  const comparable=calculated.value!==null&&!scopeCompatible([f,profit,shares],{sameUnit:false})&&f.shareAdjustmentBasis===shares.shareAdjustmentBasis;
  const tolerance=f.currency==='KRW'?0.51:f.currency==='USD'?0.0051:null;
  const recomputedValue=comparable?profit.value/shares.value:null;
  const difference=comparable?Math.abs(recomputedValue-f.value):null;
  const status=!comparable||tolerance===null?'UNAVAILABLE':difference<=tolerance?'MATCHED':'CONFLICT';
  const reconciliation={status,reportedValue:f.value,recomputedValue,difference,tolerance,reason:!comparable?'COMPARABLE_NUMERATOR_AND_WEIGHTED_SHARES_REQUIRED':tolerance===null?'CURRENCY_PRECISION_NOT_CONFIGURED':null,inputReferences:[f,profit,shares].filter(Boolean).map(x=>({sourceRef:x.sourceRef,versionId:x.versionId,rawReference:x.rawReference}))};
  return metric(`eps.${kind.toLowerCase()}`,status==='CONFLICT'?null:f.value,status==='CONFLICT'?[f,profit,shares]:[f],{unit:f.unit,reason:status==='CONFLICT'?'EPS_SOURCE_RECONCILIATION_CONFLICT':null,calculationStatus:status==='CONFLICT'?'UNAVAILABLE':'REPORTED',details:{reconciliation}});
 };
 const basic=choose(reportedBasic,profitCommon,weightedBasicShares,'BASIC');
 const diluted=choose(reportedDiluted,dilutedNumerator,weightedDilutedShares,'DILUTED');
 return {basic,diluted};
}
