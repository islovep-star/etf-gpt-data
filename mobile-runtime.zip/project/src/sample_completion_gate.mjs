/** Stage 04 closes a bounded, inspectable sample, never unresolved source issues. */
export function assessSampleCompletion(financial, etf) {
 const checks=[]; const check=(id,pass)=>checks.push({id,pass:pass===true});
 check('KR_US_EIGHT_REVENUE_QUARTERS',['005930','AAPL'].every(s=>financial.contexts[s]?.coverage.quarterRevenuePeriods.length===8));
 check('ORIGINAL_RECORD_COUNTS',financial.normalizedCount===186&&financial.derivedCount===20&&etf.rows===1337&&etf.facts.length===4011);
 const exceptions=financial.epsChecks.filter(x=>!x.pass);
 check('ALL_EPS_CHECKS_ACCOUNTED',financial.epsChecks.length===40&&exceptions.length===1&&exceptions[0].instrumentId==='005930'&&exceptions[0].periodEnd==='2024-06-30');
 const p=financial.contexts['005930']?.context.fundamental.metrics.periods.find(x=>x.periodKind==='QUARTER'&&x.periodEnd==='2024-06-30');
 check('CONFLICT_QUARANTINED',p?.eps.basic.value===null&&p.eps.basic.reason==='EPS_SOURCE_RECONCILIATION_CONFLICT');
 check('CONFLICT_RAW_RETAINED',financial.contexts['005930']?.context.fundamental.history.some(f=>f.account==='basicEps'&&f.periodKind==='QUARTER'&&f.periodEnd==='2024-06-30'&&f.value===1419));
 check('EXPORT_ARITHMETIC_MATCH',etf.referenceAgreement);
 check('NO_VOLUME_RESCALE',etf.facts.filter(x=>x.account==='volume').every(x=>x.volumeMultiplier===1));
 check('NO_FALSE_PREMIUM',etf.etfMetrics.metrics.premiumDiscountPct.value===null);
 check('PIT_NOT_PROMOTED',etf.facts.every(x=>x.pitVerified===false)&&Object.values(financial.contexts).every(x=>x.context.fundamental.history.every(f=>f.pitVerified===false)));
 check('NO_WORKER_CLAIM',etf.productionIndicatorComparison==='DEFERRED_STAGE12');
 const passed=checks.every(x=>x.pass);
 return {schema:'BOUNDED_SAMPLE_COMPLETION_V1',status:passed?'COMPLETE_BOUNDED_WITH_OPEN_ITEMS':'BLOCKED',passed,checks,
  scope:['005930 historical issuer statements','AAPL historical issuer statements','379810 official export'],
  exactCriterion:'검사한 항목은 원문 대비 일치, 미확인 항목은 미확인으로 남음. 작은 실제 표본의 성공을 전체 종목 성공으로 승격하지 않는다.',
  unresolved:['S04-KR-EPS-2024Q2','S04-LIVE-API','S04-379810-PRICE-VOLUME','S04-KR-Q4-EPS','S11-INDEPENDENT','S12-WORKER'],
  sourceConflictResolved:false,universeVerified:false,pointInTimeVerified:false,automaticTradingAllowed:false,deployment:'NOT_ATTEMPTED'};
}
