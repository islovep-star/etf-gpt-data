import {applyRecordEvidence,versionedPacketEvidence} from './data_record_contract.mjs';
import {hasText,isFiniteNumber as finite,strictTimestamp,strictDate,round} from './common.mjs';
import {eligibleFact,metric,scopeCompatible,growthChange} from './financial_contract.mjs';

function usable(f,asOf,instrumentId){return !!f&&f.instrumentId===instrumentId&&eligibleFact(f,asOf);}
function paired(a,b,{asOf,instrumentId,sameTime=true,sameUnit=true}={}){
 if(!usable(a,asOf,instrumentId)||!usable(b,asOf,instrumentId))return 'EVIDENCE_REQUIRED';
 if(!hasText(a.currency)||a.currency!==b.currency||(sameUnit&&a.unit!==b.unit))return 'CURRENCY_OR_UNIT_MISMATCH';
 if(sameTime&&(!hasText(a.measurementAt)||a.measurementAt!==b.measurementAt))return 'MEASUREMENT_TIME_MISMATCH';
 try{if(sameTime&&strictTimestamp(a.measurementAt)>strictTimestamp(asOf))return 'FUTURE_MEASUREMENT';}catch{return 'MEASUREMENT_TIME_REQUIRED';}
 return null;
}
export function buildEtfMetrics({instrumentId,asOf,fundType,holdingsSnapshot=null,constituents=[],expenseRatio=null,price=null,nav=null,bid=null,ask=null,fundReturn=null,benchmarkReturn=null,evidenceBundle=null}={}){
 strictTimestamp(asOf);
 const attach=f=>f?applyRecordEvidence([f],{...evidenceBundle,asOf})[0]:f;
 [holdingsSnapshot,expenseRatio,price,nav,bid,ask,fundReturn,benchmarkReturn]=[holdingsSnapshot,expenseRatio,price,nav,bid,ask,fundReturn,benchmarkReturn].map(attach);
 constituents=constituents.map(c=>({...c,profitCurrent:attach(c.profitCurrent),profitPrevious:attach(c.profitPrevious),marketCap:attach(c.marketCap)}));
 const evidenceRecords=[holdingsSnapshot,expenseRatio,price,nav,bid,ask,fundReturn,benchmarkReturn,...constituents.flatMap(c=>[c.profitCurrent,c.profitPrevious,c.marketCap])].filter(Boolean);
 if(!hasText(instrumentId))throw new Error('ETF_INSTRUMENT_REQUIRED');
 if(!['EQUITY','BOND','COMMODITY','MULTI_ASSET','OTHER'].includes(fundType))fundType='OTHER';
 let snapshotTimeOk=false;try{snapshotTimeOk=strictTimestamp(holdingsSnapshot?.measurementAt)<=strictTimestamp(asOf);}catch{}
 const snapshotOk=usable(holdingsSnapshot,asOf,instrumentId)&&holdingsSnapshot.unit==='HOLDINGS_SNAPSHOT'&&snapshotTimeOk;
 const holdings=snapshotOk&&Array.isArray(holdingsSnapshot.holdings)?holdingsSnapshot.holdings:[];
 const validWeights=holdings.length>0&&holdings.every(h=>hasText(h.instrumentId)&&finite(h.weightPct)&&h.weightPct>=0&&h.weightPct<=100)&&new Set(holdings.map(h=>h.instrumentId)).size===holdings.length;
 const totalWeight=validWeights?holdings.reduce((a,h)=>a+h.weightPct,0):null;
 const complete=validWeights&&holdingsSnapshot.complete===true&&Math.abs(totalWeight-100)<1e-6;
 const weights=validWeights?[...holdings].sort((a,b)=>b.weightPct-a.weightPct):[];
 const coverage={reportedWeightPct:totalWeight,complete,holdingsDate:holdingsSnapshot?.measurementAt||null,observationCount:holdings.length,status:complete?'AVAILABLE':validWeights?'PARTIAL':'MISSING'};
 const metrics={
  top10WeightPct:metric('etf.top10WeightPct',complete?weights.slice(0,10).reduce((a,h)=>a+h.weightPct,0):null,[holdingsSnapshot],{unit:'PCT',reason:complete?null:'COMPLETE_UNIQUE_HOLDINGS_REQUIRED',formula:'sum of the ten largest disclosed weights'}),
  concentrationHhi:metric('etf.concentrationHhi',complete?weights.reduce((a,h)=>a+(h.weightPct/100)**2,0):null,[holdingsSnapshot],{unit:'FRACTION',reason:complete?null:'COMPLETE_UNIQUE_HOLDINGS_REQUIRED',formula:'sum squared portfolio weights; 0 to 1'}),
  expenseRatioPct:metric('etf.expenseRatioPct',usable(expenseRatio,asOf,instrumentId)&&expenseRatio.unit==='PCT_PER_YEAR'&&expenseRatio.value>=0&&['NET_TOTAL_EXPENSE_RATIO','GROSS_TOTAL_EXPENSE_RATIO'].includes(expenseRatio.definition)?expenseRatio.value:null,[expenseRatio],{unit:'PCT_PER_YEAR',reason:expenseRatio?'ANNUAL_TOTAL_EXPENSE_DEFINITION_REQUIRED':'EXPENSE_EVIDENCE_REQUIRED',formula:'reported annual expense ratio; not added again to NAV total return'})
 };
 if(metrics.expenseRatioPct.value!==null)metrics.expenseRatioPct.reason=null;
 let premiumReason=paired(price,nav,{asOf,instrumentId});if(!premiumReason&&(price.unit!==`${price.currency}_PER_UNIT`||price.value<=0||nav.value<=0))premiumReason='POSITIVE_PRICE_NAV_PER_UNIT_REQUIRED';
 metrics.premiumDiscountPct=metric('etf.premiumDiscountPct',premiumReason?null:(price.value/nav.value-1)*100,[price,nav],{unit:'PCT',reason:premiumReason,formula:'(simultaneous market price / NAV - 1) * 100'});
 let spreadReason=paired(bid,ask,{asOf,instrumentId});if(!spreadReason&&(bid.unit!==`${bid.currency}_PER_UNIT`||bid.value<=0||ask.value<bid.value))spreadReason='VALID_BID_ASK_REQUIRED';
 metrics.bidAskSpreadPct=metric('etf.bidAskSpreadPct',spreadReason?null:(ask.value-bid.value)/((ask.value+bid.value)/2)*100,[bid,ask],{unit:'PCT',reason:spreadReason,formula:'(ask - bid) / midpoint * 100'});
 let trackingReason=paired(fundReturn,benchmarkReturn,{asOf,instrumentId,sameTime:false});
 if(!trackingReason){try{strictDate(fundReturn.periodStart);strictDate(fundReturn.periodEnd);if(fundReturn.periodStart>=fundReturn.periodEnd||fundReturn.value< -100||benchmarkReturn.value< -100)trackingReason='INVALID_RETURN_PERIOD_OR_VALUE';}catch{trackingReason='INVALID_RETURN_PERIOD';}}
 if(!trackingReason&&(!hasText(fundReturn.periodStart)||!hasText(fundReturn.periodEnd)||fundReturn.periodEnd>asOf.slice(0,10)||fundReturn.periodStart!==benchmarkReturn.periodStart||fundReturn.periodEnd!==benchmarkReturn.periodEnd||fundReturn.unit!=='PCT'||fundReturn.returnBasis!=='NAV_TOTAL_RETURN'||benchmarkReturn.returnBasis!=='BENCHMARK_TOTAL_RETURN'||!hasText(fundReturn.benchmarkId)||fundReturn.benchmarkId!==benchmarkReturn.benchmarkId||!hasText(fundReturn.taxBasis)||fundReturn.taxBasis!==benchmarkReturn.taxBasis||!hasText(fundReturn.hedgingBasis)||fundReturn.hedgingBasis!==benchmarkReturn.hedgingBasis))trackingReason='COMPARABLE_TOTAL_RETURN_BASIS_REQUIRED';
 metrics.trackingDifferencePp=metric('etf.trackingDifferencePp',trackingReason?null:fundReturn.value-benchmarkReturn.value,[fundReturn,benchmarkReturn],{unit:'PERCENTAGE_POINTS',reason:trackingReason,formula:'NAV total return - matched benchmark total return; tracking error is a separate statistic'});
 const earningsApplicable=fundType==='EQUITY',stateWeights={},observations=[],excluded=[];let growthSum=0,growthCoverage=0,yieldSum=0,yieldCoverage=0;
 if(earningsApplicable&&validWeights)for(const h of holdings){
  const matches=constituents.filter(x=>x.instrumentId===h.instrumentId);if(matches.length!==1){excluded.push({instrumentId:h.instrumentId,reason:'UNIQUE_CONSTITUENT_DATA_REQUIRED'});continue;}
  const c=matches[0],a=c.profitCurrent,b=c.profitPrevious,cap=c.marketCap;
  let reason=scopeCompatible([a,b],{samePeriod:false});
  if(!reason&&(!usable(a,asOf,h.instrumentId)||!usable(b,asOf,h.instrumentId)||!['ANNUAL','TTM'].includes(a.periodKind)||a.periodKind!==b.periodKind||a.account!=='profitCommon'||b.account!=='profitCommon'||`${Number(a.periodStart.slice(0,4))-1}${a.periodStart.slice(4)}`!==b.periodStart||`${Number(a.periodEnd.slice(0,4))-1}${a.periodEnd.slice(4)}`!==b.periodEnd||a.periodEnd>holdingsSnapshot.measurementAt.slice(0,10)||a.comparisonBasis!==b.comparisonBasis))reason='COMPARABLE_CONSTITUENT_EARNINGS_REQUIRED';
  const change=reason?null:growthChange(a.value,b.value);
  if(change){stateWeights[change.status]=(stateWeights[change.status]||0)+h.weightPct;if(change.value!==null){growthSum+=h.weightPct/100*change.value;growthCoverage+=h.weightPct;}}
  else excluded.push({instrumentId:h.instrumentId,reason});
  let yieldReason=scopeCompatible([a,cap],{samePeriod:false});
  if(!yieldReason&&(!usable(a,asOf,h.instrumentId)||!usable(cap,asOf,h.instrumentId)||a.account!=='profitCommon'||!['ANNUAL','TTM'].includes(a.periodKind)||cap.account!=='marketCap'||cap.value<=0||cap.periodKind!=='INSTANT'||cap.periodEnd!==holdingsSnapshot.measurementAt.slice(0,10)||a.periodEnd>cap.periodEnd))yieldReason='COMPARABLE_MARKET_CAP_REQUIRED';
  if(!yieldReason){yieldSum+=h.weightPct/100*(a.value/cap.value*100);yieldCoverage+=h.weightPct;}
  observations.push({instrumentId:h.instrumentId,weightPct:h.weightPct,change,growthReason:reason,earningsYieldPct:yieldReason?null:round(a.value/cap.value*100,8),yieldReason,inputs:[a,b,cap].filter(Boolean)});
 }
 const evidence=[holdingsSnapshot,...observations.flatMap(o=>o.inputs)];
 const uniformEarningsBasis=new Set(observations.map(o=>{const f=o.inputs[0];return `${f?.periodStart}|${f?.periodEnd}|${f?.periodKind}|${f?.actualOrEstimate}`;})).size===1;
 const fullGrowth=complete&&uniformEarningsBasis&&Math.abs(growthCoverage-100)<1e-6,fullYield=complete&&uniformEarningsBasis&&Math.abs(yieldCoverage-100)<1e-6;
 const reason=earningsApplicable?'FULL_COMPARABLE_CONSTITUENT_COVERAGE_REQUIRED':'NOT_APPLICABLE';
 metrics.constituentEarningsGrowthPct=metric('etf.constituentEarningsGrowthPct',fullGrowth?growthSum:null,evidence,{unit:'PCT',reason:fullGrowth?null:reason,formula:'holdings-weighted constituent common earnings growth, not ETF EPS growth'});
 metrics.constituentEarningsYieldPct=metric('etf.constituentEarningsYieldPct',fullYield?yieldSum:null,evidence,{unit:'PCT',reason:fullYield?null:reason,formula:'sum(weight * common annual/TTM earnings / market cap), including losses'});
 metrics.constituentValuationMultiple=metric('etf.constituentValuationMultiple',fullYield&&yieldSum>0?100/yieldSum:null,evidence,{unit:'MULTIPLE',reason:!earningsApplicable?'NOT_APPLICABLE':!fullYield?reason:yieldSum<=0?'NONPOSITIVE_AGGREGATE_EARNINGS':null,formula:'reciprocal of full-coverage weighted earnings yield, not arithmetic mean of constituent PE'});
 return {schema:'ETF_OBJECTIVE_METRICS_V1',evidence:versionedPacketEvidence(evidenceRecords),assetType:'ETF',instrumentId,asOf,fundType,status:'PARTIAL',metrics,coverage,
  constituents:{growthCoveragePct:round(growthCoverage,6),valuationCoveragePct:round(yieldCoverage,6),uniformEarningsBasis,stateWeights,observations,excluded},
  applicability:{corporateEps:'NOT_APPLICABLE',constituentEarnings:earningsApplicable?'APPLICABLE':'NOT_APPLICABLE',constituentValuation:earningsApplicable?'APPLICABLE':'NOT_APPLICABLE'},
  missing:Object.entries(metrics).filter(([,m])=>m.value===null&&m.status!=='NOT_APPLICABLE').map(([k])=>k),
  objectiveDataOnly:true,technicalScoreContribution:0,decisionAuthority:'GPT_REVIEW_ONLY',judgement:'NONE',automaticTradingAllowed:false};
}
