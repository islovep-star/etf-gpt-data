import {hasText,isObject,isFiniteNumber,strictTimestamp,strictDate,selectLatestAvailable,round} from './common.mjs';

import {civilDateAt,civilDates} from './trading_calendar.mjs';
import {validateDailyScope} from './daily_scope.mjs';

export function validateCalendarEvidence(calendar, asOf) {
  const blockers=[],sessionMap=new Map();
  if (!isObject(calendar)||calendar.schema!=='TRADING_CALENDAR_V1') return {verified:false,blockers:['CALENDAR_SCHEMA_REQUIRED'],sessionMap};
  if (calendar.status!=='VERIFIED'||!hasText(calendar.sourceRef)||!hasText(calendar.versionId)) blockers.push('CALENDAR_PROVENANCE_REQUIRED');
  let cutoff, available, localAsOf, coveredDates=[];
  try { cutoff=strictTimestamp(asOf,'analysis_as_of'); available=strictTimestamp(calendar.availableAt,'calendar.availableAt'); }
  catch(e){ blockers.push(e.message); }
  if (Number.isFinite(cutoff)&&Number.isFinite(available)&&available>cutoff) blockers.push('CALENDAR_LOOKAHEAD');
  try {
    if(!hasText(calendar.timeZone))throw new Error();
    // Also validate the zone when asOf is invalid.
    civilDateAt(0,calendar.timeZone);
    if(Number.isFinite(cutoff))localAsOf=civilDateAt(cutoff,calendar.timeZone);
  } catch {blockers.push('CALENDAR_TIME_ZONE_REQUIRED_OR_INVALID');}
  try {
    if(!isObject(calendar.coverage))throw new Error();
    coveredDates=civilDates(calendar.coverage.start,calendar.coverage.end);
    if(localAsOf&&(localAsOf<calendar.coverage.start||localAsOf>calendar.coverage.end))blockers.push('CALENDAR_ASOF_OUTSIDE_COVERAGE');
  } catch {blockers.push('CALENDAR_COVERAGE_REQUIRED_OR_INVALID');}
  if(calendar.validForAnalysisThrough!==undefined){
    try{strictDate(calendar.validForAnalysisThrough,'calendar.validForAnalysisThrough');
      if(calendar.validForAnalysisThrough<calendar.coverage?.start||calendar.validForAnalysisThrough>calendar.coverage?.end)blockers.push('CALENDAR_ANALYSIS_VALIDITY_INVALID');
      if(localAsOf&&localAsOf>calendar.validForAnalysisThrough)blockers.push('CALENDAR_SPECIAL_NOTICES_REFRESH_REQUIRED');
    }catch{blockers.push('CALENDAR_ANALYSIS_VALIDITY_INVALID');}
  }
  const covered=new Set(coveredDates);
  const sessions=Array.isArray(calendar.sessions)?calendar.sessions:[];
  if (!sessions.length) blockers.push('CALENDAR_SESSIONS_REQUIRED');
  let previous='';
  for (const s of sessions) {
    if(!isObject(s)){blockers.push('INVALID_CALENDAR_SESSION');continue;}
    try { strictDate(s.date,'session.date'); } catch(e) { blockers.push(e.message); continue; }
    if (s.date<=previous) blockers.push('CALENDAR_UNSORTED_OR_DUPLICATE'); previous=s.date;
    if (sessionMap.has(s.date)) blockers.push('CALENDAR_DUPLICATE_DATE'); sessionMap.set(s.date,s);
    if(covered.size&&!covered.has(s.date))blockers.push('CALENDAR_SESSION_OUTSIDE_COVERAGE');
    if (!['OPEN','HOLIDAY','EARLY_CLOSE','SUSPENDED'].includes(s.status)) blockers.push('INVALID_SESSION_STATUS');
    if (['OPEN','EARLY_CLOSE'].includes(s.status)) {
      try {
        const open=strictTimestamp(s.openAt,'session.openAt'),close=strictTimestamp(s.closeAt,'session.closeAt');
        if(open>=close)blockers.push('SESSION_TIME_ORDER_INVALID');
        if(localAsOf&&(civilDateAt(open,calendar.timeZone)!==s.date||civilDateAt(close,calendar.timeZone)!==s.date))blockers.push('SESSION_LOCAL_DATE_MISMATCH');
      } catch(e){blockers.push(e.message);}
    } else if(s.openAt!=null||s.closeAt!=null) blockers.push('CLOSED_SESSION_HAS_TRADING_TIMES');
  }
  const missingCalendarDates=coveredDates.filter(d=>!sessionMap.has(d));
  if(missingCalendarDates.length)blockers.push('CALENDAR_DATES_MISSING');
  return {verified:blockers.length===0,blockers:[...new Set(blockers)],sessionMap,localAsOf,missingCalendarDates};
}

export function validateVolumeBasis(meta, asOf) {
  const blockers=[];
  if (!isObject(meta)||meta.schema!=='VOLUME_BASIS_V1') return {verified:false,blockers:['VOLUME_BASIS_SCHEMA_REQUIRED']};
  for (const k of ['sourceRef','versionId','unit','sessionScope','venueScope','aggregation','corporateActionPolicy','availableAt']) if(!hasText(meta[k])) blockers.push(`VOLUME_BASIS_FIELD_REQUIRED:${k}`);
  if (meta.status!=='VERIFIED') blockers.push('VOLUME_BASIS_NOT_VERIFIED');
  try { if(strictTimestamp(meta.availableAt,'volume.availableAt')>strictTimestamp(asOf,'analysis_as_of')) blockers.push('VOLUME_BASIS_LOOKAHEAD'); }
  catch(e){blockers.push(e.message);}
  if (!['SHARES','CONTRACTS','CURRENCY_NOTIONAL'].includes(meta.unit)) blockers.push('VOLUME_UNIT_UNSUPPORTED');
  if (!['REGULAR_SESSION','ALL_SESSIONS','DECLARED_CUSTOM'].includes(meta.sessionScope)) blockers.push('VOLUME_SESSION_SCOPE_INVALID');
  return {verified:blockers.length===0,blockers:[...new Set(blockers)]};
}

export function assessDailyFrame({rows,calendar,volumeBasis,priceBasis,analysisAsOf,graceMinutes=15,allowSuspensions=[]}) {
  const blockers=[],warnings=[];
  if(calendar?.verificationScope==='PUBLISHED_SCHEDULE_ONLY')warnings.push('SCHEDULE_ONLY_UNSCHEDULED_EVENTS_NOT_VERIFIED');
  const graceValid=isFiniteNumber(graceMinutes)&&graceMinutes>=0;
  if(!graceValid)blockers.push('INVALID_CLOSURE_GRACE');
  const sessionRows=Array.isArray(calendar?.sessions)?calendar.sessions:[];
  const priceRows=Array.isArray(rows)?rows:[];
  const cal=validateCalendarEvidence(calendar,analysisAsOf); blockers.push(...cal.blockers);
  const vol=validateVolumeBasis(volumeBasis,analysisAsOf); blockers.push(...vol.blockers);
  const scope=validateDailyScope({priceBasis,volumeBasis,calendar,asOf:analysisAsOf}); blockers.push(...scope.blockers);
  if (!Array.isArray(rows)||!rows.length) blockers.push('PRICE_ROWS_REQUIRED');
  let previous=''; const rowDates=new Set();
  for (const row of priceRows) {
    try{if(!isObject(row))throw new Error();strictDate(row.date);}catch{blockers.push('INVALID_PRICE_ROW_DATE');continue;}
    if(row.date<=previous)blockers.push('PRICE_ROWS_UNSORTED_OR_DUPLICATE');previous=row.date;
    if(rowDates.has(row.date))blockers.push('PRICE_ROWS_DUPLICATE_DATE');rowDates.add(row.date);
    if(!['open','high','low','close'].every(k=>isFiniteNumber(row[k])&&row[k]>0))blockers.push('INVALID_OHLC');
    if(row.high<Math.max(row.open,row.close,row.low)||row.low>Math.min(row.open,row.close,row.high))blockers.push('OHLC_RELATION_INVALID');
    if(!isFiniteNumber(row.volume)||row.volume<0)blockers.push('INVALID_VOLUME');
  }
  // A bare date list is not evidence of a suspension. Verified SUSPENDED sessions belong in the calendar.
  const allow=new Set();
  if(!Array.isArray(allowSuspensions)||allowSuspensions.length)blockers.push('SUSPENSION_EVIDENCE_REQUIRED');
  const expected=[];
  for(const s of sessionRows) if(['OPEN','EARLY_CLOSE'].includes(s?.status)) expected.push(s.date);
  const cutoff=Date.parse(analysisAsOf);
  let latestClosedDate=null;
  for(const s of sessionRows){
    if(!['OPEN','EARLY_CLOSE'].includes(s?.status)||!s.closeAt)continue;
    const closedAt=graceValid?Date.parse(s.closeAt)+graceMinutes*60_000:NaN;
    if(closedAt<=cutoff&&(!latestClosedDate||s.date>latestClosedDate))latestClosedDate=s.date;
  }
  const from=priceRows[0]?.date,to=latestClosedDate||priceRows.at(-1)?.date;
  const inRange=expected.filter(d=>!from||!to||(d>=from&&d<=to));
  const missing=inRange.filter(d=>!rowDates.has(d)&&!allow.has(d));
  const unexpected=[...rowDates].filter(d=>!cal.sessionMap?.has(d)||!['OPEN','EARLY_CLOSE'].includes(cal.sessionMap.get(d)?.status));
  if(missing.length)blockers.push('TRADING_SESSIONS_MISSING');
  if(unexpected.length)blockers.push('NON_TRADING_DATE_ROWS_PRESENT');
  const last=priceRows.at(-1)?.date||null;
  const closedCandlesVerified=!!last&&last===latestClosedDate&&cal.verified&&graceValid&&scope.priceCalendarVerified;
  if(!closedCandlesVerified)blockers.push('LATEST_CANDLE_CLOSURE_UNPROVEN');
  const calendarCompletenessVerified=cal.verified&&rowDates.size>0&&missing.length===0&&unexpected.length===0&&scope.priceCalendarVerified;
  return {
    schema:'DAILY_FRAME_QUALITY_V1',
    validated:blockers.length===0,
    calendarCompletenessVerified,
    closedCandlesVerified,
    volumeBasisVerified:vol.verified&&scope.verified,
    priceVolumeScopeVerified:scope.verified,
    latestClosedDate,lastDate:last,
    calendarVerificationScope:calendar?.verificationScope||null,
    observedTradingVerified:false,
    missingCalendarDates:cal.missingCalendarDates||[],
    missingSessions:missing,unexpectedDates:unexpected,
    blockers:[...new Set(blockers)],warnings:[...new Set(warnings)]
  };
}

export function assessCorporateActions({events,analysisAsOf,adjustmentPolicy}) {
  const blockers=[]; const cutoff=strictTimestamp(analysisAsOf,'analysis_as_of');
  if(!isObject(adjustmentPolicy)||!hasText(adjustmentPolicy.priceField)||!hasText(adjustmentPolicy.policyVersion)||!hasText(adjustmentPolicy.sourceRef)) blockers.push('ADJUSTMENT_POLICY_REQUIRED');
  const valid=[];
  for(const e of events||[]){
    if(!isObject(e)||!hasText(e.type)||!hasText(e.availableAt)||!hasText(e.eventDate)){blockers.push('INVALID_CORPORATE_ACTION');continue;}
    let a;try{a=strictTimestamp(e.availableAt,'event.availableAt');strictDate(e.eventDate,'event.eventDate');}catch(err){blockers.push(err.message);continue;}
    if(a>cutoff)continue;
    if(!['DIVIDEND','SPLIT','MERGER','RIGHTS','OTHER'].includes(e.type))blockers.push('CORPORATE_ACTION_TYPE_INVALID');
    valid.push(e);
  }
  return {verified:blockers.length===0,events:valid,blockers:[...new Set(blockers)]};
}

export function blindCutoff(records,analysisAsOf,keyFn=x=>x.key){
  const {selected,conflicts}=selectLatestAvailable(records,analysisAsOf,keyFn);
  return {selected,conflicts,ready:conflicts.length===0};
}

export function compareVolumeSeries(a,b,{toleranceAbs=0,tolerancePct=0}={}){
  const byDate=new Map((b||[]).map(x=>[x.date,x.volume]));
  const details=[];let matches=0,mismatches=0,missing=0;
  for(const x of a||[]){
    if(!byDate.has(x.date)){missing++;details.push({date:x.date,status:'MISSING_REFERENCE'});continue;}
    const y=byDate.get(x.date);const diff=x.volume-y;const pct=y===0?(x.volume===0?0:null):diff/y*100;
    const ok=Math.abs(diff)<=toleranceAbs||(pct!==null&&Math.abs(pct)<=tolerancePct);
    if(ok)matches++;else mismatches++;
    details.push({date:x.date,source:x.volume,reference:y,diff,pct:round(pct,6),status:ok?'MATCH':'MISMATCH'});
  }
  return {matches,mismatches,missing,total:(a||[]).length,details};
}
