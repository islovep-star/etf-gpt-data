import fs from 'node:fs';
import path from 'node:path';
import {latestBasicRun,buildBasicRelease} from './basic_release.mjs';
import {latestRefresh,readRefreshConfig,refreshPrerequisites,refreshBasic,checkRefreshInputs,refreshInputCheckReason} from './basic_refresh.mjs';
import {checkBasicRules,readInputPack} from './basic_release_input.mjs';

// Console diagnostics never include supplied values, paths, raw exceptions or credentials.
const reasons=new Set(['INVALID_BASIC_HEAD','BASIC_HEAD_INTEGRITY_FAILURE','REFRESH_HEAD_INVALID','REFRESH_HEAD_HASH_MISMATCH','REFRESH_INTEGRITY_FAILURE','REFRESH_GENERATION_INCOMPLETE','REFRESH_EXPLICIT_TARGETS_REQUIRED','REFRESH_PROVIDER_INVALID','REFRESH_STOCK_IDENTITY_REQUIRED','REFRESH_MARKET_MISMATCH','REFRESH_SEC_CIK_REQUIRED','REFRESH_KR_REQUEST_REQUIRED','REFRESH_LOCAL_PATH_INVALID','PWA_READ_TOKEN_FORMAT','NODE_20_OR_NEWER_REQUIRED','NO_COMPLETED_RUN_TO_RESUME','INVALID_RUN_COMPLETION_TIME','PORT_IN_USE_CHOOSE_ANOTHER_PORT']);
export function entryReason(error){return error?.code==='EADDRINUSE'?'PORT_IN_USE_CHOOSE_ANOTHER_PORT':reasons.has(error?.message)?error.message:'PROGRAM_INPUT_OR_INTEGRITY_CHECK_FAILED';}
export function validateEntryEnvironment(env=process.env){
 const token=env.BASIC_PWA_READ_TOKEN||'';
 if(typeof token!=='string'||token&&!/^[A-Za-z0-9_-]{24,256}$/.test(token))throw Error('PWA_READ_TOKEN_FORMAT');
 return {authMode:token?'ENV_READ_TOKEN':'LOCAL_LOOPBACK_ONLY'};
}
function headExists(file){try{fs.lstatSync(file);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
function readSource(outputRoot,source){
 const base=path.resolve(outputRoot),folder=source==='refresh'?path.join(base,'refresh'):base;
 const head=path.join(folder,source==='refresh'?'latest_refresh.json':'latest.json');
 if(!headExists(head))return null;
 if(fs.realpathSync(folder)!==folder||fs.realpathSync(head)!==head)throw Error('PROGRAM_INPUT_OR_INTEGRITY_CHECK_FAILED');
 const run=source==='refresh'?latestRefresh(folder):latestBasicRun(folder);
 if(!run)throw Error('PROGRAM_INPUT_OR_INTEGRITY_CHECK_FAILED');
 const completedAt=Date.parse(run.receipt.completedAt);
 if(!Number.isFinite(completedAt))throw Error('INVALID_RUN_COMPLETION_TIME');
 return {...run,source,completedAt};
}
export function selectEntryRun(outputRoot,source='auto'){
 if(!['auto','basic','refresh'].includes(source))throw Error('INVALID_SOURCE');
 const candidates=(source==='auto'?['basic','refresh']:[source]).map(s=>readSource(outputRoot,s)).filter(Boolean);
 // Both heads must validate in auto mode. Corruption must never trigger silent fallback.
 candidates.sort((a,b)=>b.completedAt-a.completedAt||a.source.localeCompare(b.source));
 return candidates[0]||null;
}
export function diagnoseEntry({outputRoot,configFile,source='auto',env=process.env,nodeVersion=process.versions.node}){
 if(!['auto','basic','refresh'].includes(source))throw Error('INVALID_SOURCE');
 const report={schema:'BASIC_ENTRY_DIAGNOSTIC_V1',status:'CONFIGURATION_DIAGNOSED',runtime:{nodeVersion,supported:+nodeVersion.split('.')[0]>=20},rules:{status:'UNVERIFIED',remoteRechecked:false},authentication:{status:'INVALID'},sources:{},refresh:{status:'CONFIGURATION_REQUIRED'},locks:{basic:headExists(path.join(outputRoot,'multi_horizon.writer.lock')),refresh:headExists(path.join(outputRoot,'refresh','.refresh.lock'))},networkRequestsPerformed:false,filesWritten:false,automaticResend:false,orderExecution:false,deployment:false};
 try{const r=checkBasicRules();report.rules={status:'LOCAL_SNAPSHOT_VERIFIED',version:r.version,blobSha:r.blobSha,remoteRechecked:false};}catch(e){report.rules.reason=entryReason(e);}
 try{report.authentication={status:'VALID',...validateEntryEnvironment(env)};}catch(e){report.authentication.reason=entryReason(e);}
 for(const s of ['basic','refresh'])try{const r=readSource(outputRoot,s);report.sources[s]=r?{status:'COMPLETE',runId:r.runId,completedAt:r.receipt.completedAt}:{status:'NO_COMPLETED_RUN'};}catch(e){report.sources[s]={status:'BLOCKED_INTEGRITY_CHECK',reason:entryReason(e)};}
 try{
  const loaded=readRefreshConfig(configFile),p=refreshPrerequisites(loaded.config,env);report.refresh={...p,status:'LOCAL_INPUT_CHECK_REQUIRED'};
  const checked=checkRefreshInputs(loaded);report.refresh.localInputs=checked.report;report.refresh.status=p.missingEnvironment.length?'ENVIRONMENT_REQUIRED':'READY_FOR_EXPLICIT_REFRESH';
 }catch(e){report.refresh.status='CONFIGURATION_OR_LOCAL_INPUT_BLOCKED';report.refresh.reason=refreshInputCheckReason(e);}
 const chosenSources=source==='auto'?['basic','refresh']:[source];
 report.startReady=report.runtime.supported&&report.rules.status==='LOCAL_SNAPSHOT_VERIFIED'&&report.authentication.status==='VALID'&&chosenSources.every(s=>report.sources[s].status!=='BLOCKED_INTEGRITY_CHECK')&&(chosenSources.some(s=>report.sources[s].status==='COMPLETE')||source!=='refresh'&&!report.locks.basic);
 report.refreshReady=report.runtime.supported&&report.rules.status==='LOCAL_SNAPSHOT_VERIFIED'&&report.authentication.status==='VALID'&&report.refresh.status==='READY_FOR_EXPLICIT_REFRESH'&&!report.locks.refresh&&report.sources.refresh.status!=='BLOCKED_INTEGRITY_CHECK';
 return report;
}
export async function prepareEntry({mode='start',source='auto',outputRoot,configFile,inputFile,runId,env=process.env,fetchImpl=fetch}){
 if(!['start','resume','sample','input','refresh'].includes(mode))throw Error('INVALID_MODE');
 validateEntryEnvironment(env);checkBasicRules();
 if(['start','resume'].includes(mode)){
  const existing=selectEntryRun(outputRoot,source);if(existing)return {...existing,status:'RESUMED',networkDataCollection:false};
  if(mode==='resume'||source==='refresh')throw Error('NO_COMPLETED_RUN_TO_RESUME');
 }
 const id=runId||'ENTRY_'+new Date().toISOString().replace(/[^0-9]/g,'')+'_'+process.pid;
 if(mode==='refresh'){
  const run=await refreshBasic({configFile,outputRoot:path.join(outputRoot,'refresh'),runId:id,env,fetchImpl});
  return {...run,source:'refresh',networkDataCollection:run.status==='COMPLETE'&&run.refreshReceipt.targetResults.some(t=>t.provider!=='INPUT_PACK')};
 }
 const input=mode==='input'?readInputPack(inputFile):{config:{schema:'BASIC_RELEASE_INPUT_V1',mode:mode==='sample'?'HISTORICAL_SAMPLE':'EMPTY'}};
 return {...buildBasicRelease({...input,outputRoot,runId:id}),source:'basic',networkDataCollection:false};
}
