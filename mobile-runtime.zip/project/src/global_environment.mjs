import fs from 'node:fs';
import crypto from 'node:crypto';
import {classifyRiskEnvironment} from '../vendor/g02/g02_engine.mjs';
import {observationStatus} from '../vendor/g02/g02_source_adapters.mjs';
const contract=JSON.parse(fs.readFileSync(new URL('../vendor/g02/G02_RISK_REGIME_CONTRACT.json',import.meta.url)));
export const GLOBAL_DOMAINS=Object.keys(contract.domains);
const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
export function buildGlobalEnvironment({analysisAsOf,config={},sourceVerification=null}={}){
 if(typeof analysisAsOf!=='string'||!Number.isFinite(Date.parse(analysisAsOf)))throw Error('INVALID_GLOBAL_ANALYSIS_TIME');
 if(!object(config)||Object.keys(config).some(k=>!['analysisAsOf','domainSignals','domainEvidence','limitations'].includes(k)))throw Error('UNSUPPORTED_GLOBAL_CONFIG');
 if(config.analysisAsOf!==undefined&&Date.parse(config.analysisAsOf)!==Date.parse(analysisAsOf))throw Error('GLOBAL_ANALYSIS_TIME_MISMATCH');
 for(const field of ['domainSignals','domainEvidence'])if(config[field]!==undefined&&(!object(config[field])||Object.keys(config[field]).some(k=>!GLOBAL_DOMAINS.includes(k))))throw Error('INVALID_GLOBAL_'+field);
 const limitations=config.limitations??[];if(!Array.isArray(limitations)||limitations.some(x=>typeof x!=='string'))throw Error('INVALID_GLOBAL_LIMITATIONS');
 const domain_evidence={},domain_signals={};
 for(const d of GLOBAL_DOMAINS){domain_signals[d]=config.domainSignals?.[d]??'UNKNOWN';const records=config.domainEvidence?.[d]??[];
  if(!Array.isArray(records)||records.length>100)throw Error('INVALID_GLOBAL_EVIDENCE');
  domain_evidence[d]=records.map(record=>{
   if(!object(record))throw Error('INVALID_GLOBAL_EVIDENCE');
   if(typeof record.retrieved_at!=='string'||!Number.isFinite(Date.parse(record.retrieved_at)))throw Error('INVALID_GLOBAL_RETRIEVAL_TIME');
   if(Date.parse(record.retrieved_at)>Date.parse(analysisAsOf))throw Error('GLOBAL_RETRIEVED_AFTER_ANALYSIS');
   const ageStatus=observationStatus(record.observed_at,analysisAsOf,record.frequency);
   return {...structuredClone(record),status:record.status==='VALID'&&ageStatus==='STALE'?'STALE':record.status};
  });
 }
 const result=classifyRiskEnvironment({analysis_as_of:analysisAsOf,domain_signals,domain_evidence,limitations});
 const packet={schema:'GLOBAL_ENVIRONMENT_REVIEW_V1',analysisAsOf,result,evidence:domain_evidence,sourceVerification:sourceVerification??{status:'EXTERNAL_G01_INPUT_NOT_BOUND_TO_CAPTURED_RAW'},
  status:'CANDIDATE_REVIEW_HOLD',contractVersion:contract.version,contractStatus:contract.status,
  interpretationBy:'GPT',signalDerivation:'EXTERNAL_INPUT_ONLY_RULES_NOT_FROZEN',independentApproval:'HOLD',investmentApproval:'HOLD',
  automaticTradingAllowed:false,technicalScoreContribution:0,sixLayerStanceApplied:false,
  missingDomains:result.unknown_domains,limitations:[...limitations,'실제 영역별 신호 산식·임계값 미동결','독립 시계열 반례 미검증','환경 후보는 매수·매도·배분 점수에 반영하지 않음']};
 packet.packetHash=crypto.createHash('sha256').update(JSON.stringify(packet)).digest('hex');return packet;
}
const escape=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels={EQUITY_BREADTH:'시장 참여 폭',VOLATILITY_STRESS:'변동성 스트레스',CREDIT:'신용',LIQUIDITY:'유동성',RATES:'금리',USD_FX:'달러·환율',CROSS_ASSET:'교차자산 확인'};
export function renderGlobalEnvironment(packet){
 const r=packet.result;return `<article id="global-environment"><div class="title"><h2>세계 위험환경 · 검토 후보</h2><b class="hold">독립 검증 HOLD</b></div><p>${r.state==='INSUFFICIENT_DATA'?'자료 부족':escape(r.state)} · 확인 ${r.known_domains}/7 영역</p><p class="meta">환경 분석 기준 ${escape(packet.analysisAsOf)} · 주식·ETF 원문 표본 기준과 별도</p><div class="table"><table><thead><tr><th>영역</th><th>입력 신호</th><th>자료 상태</th></tr></thead><tbody>${GLOBAL_DOMAINS.map(d=>`<tr><td>${labels[d]}</td><td>${escape(r.domain_signals[d])}</td><td>${escape(r.evidence_summary[d].statuses.join(', ')||'MISSING')} · 유효 ${r.evidence_summary[d].usable}</td></tr>`).join('')}</tbody></table></div><p>프로그램은 근거 검증과 보관 후보 규칙을 계산합니다. GPT가 해석하며, 기술점수·자동주문·배분에는 반영하지 않습니다.</p><ul>${packet.limitations.map(x=>`<li>${escape(x)}</li>`).join('')}</ul><a href="global_environment/context.json">환경 근거·상태 JSON</a>${packet.sourceVerification?.artifacts?.length?' · <a href="global_environment/raw_manifest.json">공식 CSV 원문 목록</a>'+packet.sourceVerification.artifacts.map(a=>` · <a href="${escape(a.reviewLocalPath)}">${escape(a.name)}</a>`).join(''):''}</article>`;
}
