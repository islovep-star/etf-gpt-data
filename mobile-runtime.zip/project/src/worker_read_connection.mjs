// Existing R15.21 read interface only. No upload, Cron run, or order execution.
export const WORKER_ORIGIN = 'https://etf-market-api.islovep.workers.dev';
const ID = /^[A-Z0-9._-]{1,20}$/;
export function connectionPlan(symbol = 'QQQM') {
  if (!ID.test(symbol)) throw Error('INVALID_SYMBOL');
  return {schema:'R1521_READ_CONNECTION_PLAN_V1',origin:WORKER_ORIGIN,symbol,
    requests:[{kind:'RAW_PRICE',path:'/?symbol='+encodeURIComponent(symbol)+'&range=1mo&interval=1d',authentication:false},
      {kind:'SNAPSHOT_META',path:'/snapshot-meta',authentication:true},
      {kind:'PILOT_STATUS',path:'/server-pilot-status?client=r1520',authentication:true}],
    readTokenEnvironment:'SNAPSHOT_READ_TOKEN',networkRequestsPerformed:false,
    writesAllowed:false,automaticResend:false,deployment:false};
}
async function readPacket(path,{token='',fetchImpl=fetch}={}) {
  const headers={Accept:'application/json'};
  if(token) headers.Authorization='Bearer '+token;
  let response;
  try { response=await fetchImpl(WORKER_ORIGIN+path,{method:'GET',headers,redirect:'error',cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(20000)}); }
  catch { return {status:'REQUEST_FAILED',originResponseVerified:false}; }
  // A non-JSON 403 may come from an access layer. Do not call it a Worker error.
  if(!response.headers.get('content-type')?.toLowerCase().includes('application/json'))
    return {status:'NON_JSON_RESPONSE',httpStatus:response.status,originResponseVerified:false};
  let body,bytes=0;const parts=[];
  try {
    if(!response.body) throw Error('EMPTY_BODY');
    const reader=response.body.getReader();
    try { for(;;){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;
      if(bytes>2*1024*1024)throw Error('BODY_TOO_LARGE');parts.push(value);} }
    finally { await reader.cancel().catch(()=>{}); }
    const all=new Uint8Array(bytes);let offset=0;for(const p of parts){all.set(p,offset);offset+=p.byteLength;}
    // Never print or save a response that echoes the supplied token.
    const raw=new TextDecoder().decode(all);if(token&&raw.includes(token))throw Error('CREDENTIAL_ECHO');
    body=JSON.parse(raw);
  } catch { return {status:'RESPONSE_PARSE_OR_PRIVACY_BLOCKED',httpStatus:response.status,originResponseVerified:false}; }
  if(!response.ok||body?.ok===false)return {status:'HTTP_OR_SERVICE_FAILURE',httpStatus:response.status,originResponseVerified:false};
  return {body,httpStatus:response.status};
}
export async function inspectWorker({symbol='QQQM',env=process.env,fetchImpl=fetch}={}) {
  const plan=connectionPlan(symbol),token=env.SNAPSHOT_READ_TOKEN?.trim()||'';
  if(token&&(/[\r\n]/.test(token)||token.length>8192))throw Error('READ_TOKEN_INVALID');
  const checks=[];
  for(const route of plan.requests){
    if(route.authentication&&!token){checks.push({kind:route.kind,status:'READ_TOKEN_ENVIRONMENT_REQUIRED'});continue;}
    const r=await readPacket(route.path,{token:route.authentication?token:'',fetchImpl});
    if(!r.body){checks.push({kind:route.kind,...r});continue;}
    const b=r.body;let matched=false,summary={};
    if(route.kind==='RAW_PRICE'){
      matched=b.ok===true&&b.workerVersion==='R15.21-QUALITY'&&b.responseSchemaVersion==='RAW_OHLCV_V2'&&
        typeof b.symbol==='string'&&b.symbol.replace(/\.KS$/i,'')===symbol&&Array.isArray(b.prices)&&b.count===b.prices.length&&b.count>0;
      summary={rowCount:Number.isSafeInteger(b.count)?b.count:null};
    }else if(route.kind==='SNAPSHOT_META'){
      matched=b.version==='R15.21-QUALITY'&&b.meta&&typeof b.meta==='object';
      summary={snapshotPresent:Boolean(b.meta)};
    }else{
      const states=['NOT_VERIFIED','FAILED','STALE','VERIFIED_RECENT'];
      matched=b.ok===true&&b.version==='R15.21-QUALITY'&&states.includes(b.cronState)&&
        Object.hasOwn(b,'lastManual')&&Object.hasOwn(b,'lastCron')&&Object.hasOwn(b,'published');
      summary={cronState:states.includes(b.cronState)?b.cronState:'UNKNOWN',publishedPresent:Boolean(b.published)};
    }
    checks.push({kind:route.kind,status:matched?'INTERFACE_MATCHED':'INTERFACE_MISMATCH',httpStatus:r.httpStatus,...summary});
  }
  return {schema:'R1521_READ_CONNECTION_CHECK_V1',checkedAt:new Date().toISOString(),origin:WORKER_ORIGIN,symbol,checks,
    status:checks.every(c=>c.status==='INTERFACE_MATCHED')?'READ_INTERFACES_MATCHED':'CONNECTION_NOT_FULLY_CONFIRMED',
    networkRequestsPerformed:true,writesPerformed:false,automaticResend:false,
    dataQualityCertified:false,fullUniverseVerified:false,remotePushVerified:false,orderExecution:false,deployment:false};
}
