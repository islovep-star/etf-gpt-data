import fs from 'node:fs';
import path from 'node:path';
import {performance} from 'node:perf_hooks';
import {digest,classifyReviewError} from './review_run_store.mjs';
import {strictTimestamp,stableStringify} from './common.mjs';
const HASH=/^[a-f0-9]{64}$/;
const ID=/^[A-Za-z0-9_-]{1,64}$/;
const json=x=>Buffer.from(stableStringify(x)+'\n');
function read(p){if(fs.realpathSync(p)!==path.resolve(p))throw new Error('STORE_SYMLINK_FORBIDDEN');return fs.readFileSync(p);}
function atomic(p,bytes){
 fs.mkdirSync(path.dirname(p),{recursive:true});
 if(fs.realpathSync(path.dirname(p))!==path.resolve(path.dirname(p)))throw new Error('STORE_SYMLINK_FORBIDDEN');
 const temp=p+'.next';const fd=fs.openSync(temp,'wx',0o600);
 try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
 fs.renameSync(temp,p);
 const parent=fs.openSync(path.dirname(p),'r');try{fs.fsyncSync(parent);}finally{fs.closeSync(parent);}
}
function immutable(p,bytes){
 if(fs.existsSync(p)){if(!read(p).equals(bytes))throw new Error('IMMUTABLE_OBJECT_CONFLICT');return false;}
 atomic(p,bytes);return true;
}
function object(root,hash,extension){if(!HASH.test(hash))throw new Error('INVALID_OBJECT_HASH');return path.join(root,'objects',hash+'.'+extension);}
function checkDetail(detail,id){
 if(!detail||typeof detail!=='object'||Array.isArray(detail)||detail.instrumentId!==id)throw new Error('DETAIL_IDENTITY_MISMATCH');
 const walk=x=>{if(typeof x==='number'&&!Number.isFinite(x))throw new Error('NONFINITE_DETAIL_VALUE');if(!x||typeof x!=='object')return;for(const [k,v] of Object.entries(x)){if(['actionAllowed','automaticTradingAllowed','orderExecution'].includes(k)&&v!==false)throw new Error('STORE_CANNOT_AUTHORIZE_ACTION');walk(v);}};walk(detail);
}
function verifyEntry(root,e){
 const {generation,inputHash,detailSha,...meta}=e;
 if(!ID.test(e.instrumentId)||!ID.test(e.sourceVersion)||digest(json(meta))!==inputHash||strictTimestamp(e.availableAt)>strictTimestamp(e.asOf))throw new Error('GENERATION_INPUT_BINDING_MISMATCH');
 const raw=read(object(root,e.rawSha,'bin')),detail=read(object(root,e.detailSha,'json'));
 if(digest(raw)!==e.rawSha||digest(detail)!==e.detailSha)throw new Error('GENERATION_OBJECT_HASH_MISMATCH');
 const body=JSON.parse(detail);
 if(body.schema!=='GENERATION_DETAIL_V1'||body.inputHash!==e.inputHash||body.rawSha!==e.rawSha||body.calculationHash!==e.calculationHash||body.instrumentId!==e.instrumentId)throw new Error('DETAIL_INPUT_BINDING_MISMATCH');
 checkDetail(body.detail,e.instrumentId);
}
function verifyManifest(root,m){
 if(m.schema!=='LOCAL_OBJECTIVE_GENERATION_V1'||m.status!=='COMPLETE'||!ID.test(m.scopeId)||!['BOUNDED_ACTUAL_SAMPLE','SYNTHETIC_LOAD','TARGET_LIST_UNVERIFIED'].includes(m.scopeKind)||!HASH.test(m.calculationHash)||!Array.isArray(m.index)||!m.index.length||!Array.isArray(m.expectedInstrumentIds))throw new Error('GENERATION_ALIGNMENT_ERROR');
 strictTimestamp(m.asOf);
 if(m.automaticTradingAllowed!==false||m.index.some(e=>e.generation!==m.generation||e.asOf!==m.asOf||e.calculationHash!==m.calculationHash)||new Set(m.index.map(e=>e.instrumentId)).size!==m.index.length||new Set(m.expectedInstrumentIds).size!==m.expectedInstrumentIds.length||m.expectedInstrumentIds.length!==m.index.length||m.expectedInstrumentIds.some(id=>!m.index.some(e=>e.instrumentId===id)))throw new Error('GENERATION_ALIGNMENT_ERROR');
 const ordered=[...m.index].sort((a,b)=>a.instrumentId.localeCompare(b.instrumentId));
 if(digest(json({scopeId:m.scopeId,scopeKind:m.scopeKind,asOf:m.asOf,calculationHash:m.calculationHash,inputs:ordered.map(e=>e.inputHash)}))!==m.generation)throw new Error('GENERATION_IDENTITY_MISMATCH');
 for(const e of m.index)verifyEntry(root,e);
}
function bindVersion(root,e){
 const key={instrumentId:e.instrumentId,sourceVersion:e.sourceVersion},p=path.join(root,'versions',digest(json(key))+'.json');
 const body={schema:'SOURCE_VERSION_BINDING_V1',...key,rawSha:e.rawSha};
 if(fs.existsSync(p)){if(!read(p).equals(json(body)))throw new Error('SOURCE_VERSION_CONTENT_CONFLICT');return;}
 immutable(p,json(body));
}
function ensureVersionBindings(root){
 const marker=path.join(root,'versions','initialized.json'),body=json({schema:'SOURCE_VERSION_BINDINGS_INITIALIZED_V1'});
 if(fs.existsSync(marker)){if(!read(marker).equals(body))throw new Error('SOURCE_VERSION_INDEX_INVALID');return;}
 // Import legacy completed generations and successful pending cache entries once.
 const generations=path.join(root,'generations');
 if(fs.existsSync(generations))for(const name of fs.readdirSync(generations)){
  if(!HASH.test(name))throw new Error('SOURCE_VERSION_LEGACY_GENERATION_INVALID');
  const manifest=JSON.parse(read(path.join(generations,name,'manifest.json')));verifyManifest(root,manifest);
  if(manifest.generation!==name)throw new Error('SOURCE_VERSION_LEGACY_GENERATION_INVALID');
  for(const e of manifest.index)bindVersion(root,e);
 }
 const cache=path.join(root,'cache');
 if(fs.existsSync(cache))for(const name of fs.readdirSync(cache)){
  if(!/^[a-f0-9]{64}\.json$/.test(name))throw new Error('SOURCE_VERSION_LEGACY_CACHE_INVALID');
  const e=JSON.parse(read(path.join(cache,name)));verifyEntry(root,e);
  if(name!==e.inputHash+'.json')throw new Error('SOURCE_VERSION_LEGACY_CACHE_INVALID');bindVersion(root,e);
 }
 immutable(marker,body);
}
export function readCurrentGeneration(root){
 root=path.resolve(root);const p=path.join(root,'current.json');if(!fs.existsSync(p))return null;
 const pointer=JSON.parse(read(p));if(!HASH.test(pointer.generation)||!HASH.test(pointer.manifestSha))throw new Error('GENERATION_POINTER_INVALID');
 const bytes=read(path.join(root,'generations',pointer.generation,'manifest.json'));
 if(digest(bytes)!==pointer.manifestSha)throw new Error('GENERATION_MANIFEST_HASH_MISMATCH');
 const m=JSON.parse(bytes);
 if(m.generation!==pointer.generation)throw new Error('GENERATION_ALIGNMENT_ERROR');verifyManifest(root,m);
 return {pointer,manifest:m};
}

/** Local, single-writer generation builder. No source fetching, timer, or Worker API. */
export async function buildGeneration({root,scopeId,scopeKind,expectedInstrumentIds,items,asOf,calculationHash,transform,maxItems=Infinity}={}){
 strictTimestamp(asOf);
 if(!ID.test(scopeId)||!['BOUNDED_ACTUAL_SAMPLE','SYNTHETIC_LOAD','TARGET_LIST_UNVERIFIED'].includes(scopeKind))throw new Error('EXPLICIT_BOUNDED_SCOPE_REQUIRED');
 if(!HASH.test(calculationHash)||typeof transform!=='function')throw new Error('FIXED_CALCULATION_REQUIRED');
 if(!Array.isArray(items)||!items.length||items.length>10000||!Array.isArray(expectedInstrumentIds)||new Set(expectedInstrumentIds).size!==expectedInstrumentIds.length)throw new Error('EXPECTED_UNIVERSE_REQUIRED');
 expectedInstrumentIds=[...expectedInstrumentIds];
 if(maxItems!==Infinity&&(!Number.isInteger(maxItems)||maxItems<1))throw new Error('INVALID_CHUNK_LIMIT');
 const seen=new Set(),prepared=[];
 for(const x of items){
  if(!ID.test(x.instrumentId)||seen.has(x.instrumentId)||!ID.test(x.sourceVersion))throw new Error('DUPLICATE_OR_INVALID_ITEM');
  seen.add(x.instrumentId);if(strictTimestamp(x.availableAt)>strictTimestamp(asOf))throw new Error('FUTURE_SOURCE');
  if(!Buffer.isBuffer(x.raw)||x.raw.length===0||x.raw.length>10*1024*1024)throw new Error('RAW_SIZE_LIMIT');
  const raw=Buffer.from(x.raw),rawSha=digest(raw),meta={instrumentId:x.instrumentId,sourceVersion:x.sourceVersion,availableAt:x.availableAt,rawSha,asOf,calculationHash};
  prepared.push({...meta,raw,inputHash:digest(json(meta))});
 }
 if(expectedInstrumentIds.length!==seen.size||expectedInstrumentIds.some(id=>!seen.has(id)))throw new Error('INCOMPLETE_EXPECTED_UNIVERSE');
 root=path.resolve(root);fs.mkdirSync(root,{recursive:true,mode:0o700});if(fs.realpathSync(root)!==root)throw new Error('STORE_SYMLINK_FORBIDDEN');
 const lock=path.join(root,'writer.lock');let fd;
 try{fd=fs.openSync(lock,'wx',0o600);}catch(e){if(e.code==='EEXIST')throw new Error('WRITER_LOCK_REQUIRES_REVIEW_NO_AUTO_STEAL');throw e;}
 const start=performance.now();
 try{
  const current=readCurrentGeneration(root),prior=current?.manifest;
  if(prior&&(prior.scopeId!==scopeId||prior.scopeKind!==scopeKind))throw new Error('GENERATION_SCOPE_CONFLICT');
  if(prior&&Date.parse(asOf)<Date.parse(prior.asOf))throw new Error('STALE_GENERATION');
  for(const x of prepared){const old=prior?.index.find(e=>e.instrumentId===x.instrumentId);
   if(old&&Date.parse(x.availableAt)<Date.parse(old.availableAt))throw new Error('STALE_SOURCE_VERSION');
   if(old&&old.sourceVersion===x.sourceVersion&&old.rawSha!==x.rawSha)throw new Error('SOURCE_VERSION_CONTENT_CONFLICT');
  }
  ensureVersionBindings(root);for(const x of prepared)bindVersion(root,x);
  prepared.sort((a,b)=>a.instrumentId.localeCompare(b.instrumentId));
  const generation=digest(json({scopeId,scopeKind,asOf,calculationHash,inputs:prepared.map(x=>x.inputHash)}));
  if(prior?.generation===generation)return {status:'RECOVERED',generation,processed:0,reused:items.length,failed:0,rawObjectsWritten:0,sourceRequests:0,elapsedMs:performance.now()-start};
  const index=[],failures=[],stats={processed:0,reused:0,rawObjectsWritten:0,sourceRequests:0};
  let remaining=0;
  for(const x of prepared){
   const cache=path.join(root,'cache',x.inputHash+'.json');
   try{
    if(fs.existsSync(cache)){const e=JSON.parse(read(cache));const {inputHash,detailSha,...meta}=e;if(digest(json(meta))!==x.inputHash||inputHash!==x.inputHash)throw new Error('CACHE_BINDING_MISMATCH');verifyEntry(root,e);index.push({...e,generation});stats.reused++;continue;}
    if(stats.processed+failures.length>=maxItems){remaining++;continue;}
    if(immutable(object(root,x.rawSha,'bin'),x.raw))stats.rawObjectsWritten++;
    const result=await transform({instrumentId:x.instrumentId,raw:Buffer.from(x.raw),asOf,sourceVersion:x.sourceVersion});
    checkDetail(result,x.instrumentId);
    const bytes=json({schema:'GENERATION_DETAIL_V1',instrumentId:x.instrumentId,inputHash:x.inputHash,rawSha:x.rawSha,calculationHash,detail:result});if(bytes.length>10*1024*1024)throw new Error('DETAIL_SIZE_LIMIT');
    const detailSha=digest(bytes);immutable(object(root,detailSha,'json'),bytes);
    const {raw,...meta}=x,e={...meta,detailSha};atomic(cache,json(e));index.push({...e,generation});stats.processed++;
   }catch(error){failures.push({instrumentId:x.instrumentId,inputHash:x.inputHash,...classifyReviewError(error),reasonCode:/^[A-Z_]+$/.test(error.message)?error.message:'LOCAL_TRANSFORM_FAILED'});}
  }
  const base={schema:'LOCAL_OBJECTIVE_GENERATION_V1',generation,scopeId,scopeKind,asOf,calculationHash,expectedInstrumentIds:[...expectedInstrumentIds].sort(),index,sourceRequests:0,automaticTradingAllowed:false};
  if(failures.length||remaining){
   atomic(path.join(root,'pending',generation+'.json'),json({...base,status:'PENDING',failures,remaining,automaticRetry:false,lastValidGeneration:prior?.generation||null}));
   return {status:'PENDING',generation,...stats,failed:failures.length,remaining,lastValidGeneration:prior?.generation||null,elapsedMs:performance.now()-start};
  }
  const manifest={...base,status:'COMPLETE'},bytes=json(manifest);
  verifyManifest(root,manifest);
  immutable(path.join(root,'generations',generation,'manifest.json'),bytes);
  atomic(path.join(root,'current.json'),json({generation,manifestSha:digest(bytes)}));
  return {status:'COMPLETE',generation,...stats,failed:0,remaining:0,elapsedMs:performance.now()-start};
 }finally{fs.closeSync(fd);fs.unlinkSync(lock);}
}
