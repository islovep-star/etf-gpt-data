import {isObject,hasText,strictTimestamp,strictDate,sha256} from './common.mjs';
import {civilDateAt,civilDates} from './trading_calendar.mjs';

export function buildKrxCalendar(source) {
  if(!isObject(source)||source.schema!=='OFFICIAL_KRX_SCHEDULE_SOURCE_V1'||source.status!=='REVIEWED_PUBLISHED_SCHEDULE')throw new Error('KRX_REVIEWED_SOURCE_REQUIRED');
  if(source.year!==2026||source.market!=='KRX'||source.timeZone!=='Asia/Seoul'||source.sessionScope!=='REGULAR_SESSION')throw new Error('KRX_CALENDAR_SCOPE_UNSUPPORTED');
  if(!hasText(source.sourceRef)||!Array.isArray(source.holidays)||!source.holidays.length||!Array.isArray(source.specialSessions))throw new Error('KRX_SOURCE_EVIDENCE_REQUIRED');
  const observed=strictTimestamp(source.observedNoLaterThan,'source.observedNoLaterThan');
  if(strictTimestamp(source.holidayTableObservedAt)>observed)throw new Error('KRX_SOURCE_TIME_ORDER');
  const through=civilDateAt(observed,'Asia/Seoul');
  if(!through.startsWith('2026-'))throw new Error('KRX_OBSERVATION_YEAR_MISMATCH');
  if(source.regularHours?.open!=='09:00'||source.regularHours?.close!=='15:30'||!hasText(source.regularHours?.sourceRef))throw new Error('KRX_REGULAR_HOURS_REQUIRED');
  const holidays=new Map(),special=new Map();
  for(const h of source.holidays){
    strictDate(h.date);
    if(!h.date.startsWith('2026-')||holidays.has(h.date)||!hasText(h.reason))throw new Error('KRX_HOLIDAY_INVALID');
    holidays.set(h.date,h);
  }
  for(const s of source.specialSessions){
    strictDate(s.date);
    if(!s.date.startsWith('2026-')||special.has(s.date)||holidays.has(s.date)||[0,6].includes(new Date(s.date+'T00:00:00Z').getUTCDay())||!hasText(s.sourceRef)||!hasText(s.reason))throw new Error('KRX_SPECIAL_SESSION_INVALID');
    const open=strictTimestamp(`${s.date}T${s.open}:00+09:00`),close=strictTimestamp(`${s.date}T${s.close}:00+09:00`);
    if(open>=close)throw new Error('KRX_SPECIAL_TIME_ORDER');
    special.set(s.date,s);
  }
  const coverage={start:'2026-01-01',end:'2026-12-31'};
  const sessions=civilDates(coverage.start,coverage.end).map(date=>{
    if(holidays.has(date))return {date,status:'HOLIDAY',reason:holidays.get(date).reason};
    if([0,6].includes(new Date(date+'T00:00:00Z').getUTCDay()))return {date,status:'HOLIDAY',reason:'WEEKEND'};
    const s=special.get(date),hours=s||source.regularHours;
    return {date,status:'OPEN',openAt:`${date}T${hours.open}:00+09:00`,closeAt:`${date}T${hours.close}:00+09:00`,...(s?{reason:s.reason,sessionTimeSourceRef:s.sourceRef}:{})};
  });
  return {
    schema:'TRADING_CALENDAR_V1',contractRevision:3,market:'KRX',status:'VERIFIED',
    assetClass:source.assetClass,sessionScope:'REGULAR_SESSION',timeZone:'Asia/Seoul',coverage,
    validForAnalysisThrough:through,verificationScope:'PUBLISHED_SCHEDULE_ONLY',
    sourceRef:source.sourceRef,versionId:`KRX-2026-${sha256(source).slice(0,16)}`,sourceEvidenceSha256:sha256(source),
    availableAt:source.observedNoLaterThan,availableAtBasis:'OBSERVATION_RECEIPT_UPPER_BOUND',
    observedTradingVerified:false,unscheduledClosuresVerified:false,
    warnings:['FUTURE_SPECIAL_SESSION_NOTICES_REQUIRE_REFRESH','SCHEDULE_ONLY_UNSCHEDULED_EVENTS_NOT_VERIFIED','UNDERLYING_MARKET_CALENDAR_IS_SEPARATE'],sessions
  };
}
