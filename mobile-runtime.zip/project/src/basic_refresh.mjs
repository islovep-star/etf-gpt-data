import fs from 'node:fs';
import path from 'node:path';
import {collectKrStockContext,collectUsStockContext} from './stock_context_runtime.mjs';
import {assertNoSecrets,checkBasicRules,readInputPack,prepareBasicData} from './basic_release_input.mjs';
import {buildBasicRelease} from './basic_release.mjs';
import {digest,validateReviewRun} from './review_run_store.mjs';
import {strictTimestamp} from './common.mjs';
import {checkWorkerEtfTarget,collectWorkerEtf} from './worker_etf_refresh.mjs';
import {buildKrxRequest} from './krx_adapter.mjs';

const json=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n',{mode:0o600});
const safeId=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(x);
const hosts=new Set(['data.sec.gov','www.sec.gov','opendart.fss.or.kr','data-dbg.krx.co.kr','etf-market-api.islovep.workers.dev']);
const symbolOf=i=>i.assetMode==='STOCK'?i.stockContextInput?.identity?.symbol:i.etfMetricsInput?.instrumentId;
function localFile(base,rel){
 if(typeof rel!=='string'||path.isAbsolute(rel)||rel.includes('\\')||rel.split('/').includes('..'))throw Error('REFRESH_LOCAL_PATH_INVALID');
 const root=fs.realpathSync(base),p=path.resolve(root,rel);
 if(!p.startsWith(root+path.sep)||fs.realpathSync(p)!==p||!fs.statSync(p).isFile())throw Error('REFRESH_LOCAL_PATH_INVALID');return p;
}
export function readRefreshConfig(file){
 const p=fs.realpathSync(file);if(fs.statSync(p).size>4*1024*1024)throw Error('REFRESH_CONFIG_SIZE_LIMIT');
 const bytes=fs.readFileSync(p),config=JSON.parse(bytes);assertNoSecrets(config);
 if(config.schema!=='BASIC_REFRESH_V1'||Object.keys(config).some(k=>!['schema','targets'].includes(k))||!Array.isArray(config.targets)||!config.targets.length||config.targets.length>250)throw Error('REFRESH_EXPLICIT_TARGETS_REQUIRED');
 for(const t of config.targets){
  if(!t||!['SEC_STOCK','KR_STOCK','INPUT_PACK','WORKER_ETF'].includes(t.provider))throw Error('REFRESH_PROVIDER_INVALID');
  if(t.provider==='WORKER_ETF'){checkWorkerEtfTarget(t);continue;}
  if(t.provider==='INPUT_PACK'){
   if(Object.keys(t).some(k=>!['provider','file'].includes(k)))throw Error('REFRESH_TARGET_FIELDS');localFile(path.dirname(p),t.file);
  }else{
   if(Object.keys(t).some(k=>!['provider','config'].includes(k))||typeof t.config?.identity?.instrumentName!=='string'||!t.config.identity.instrumentName.trim()||t.config.identity.assetType&&t.config.identity.assetType!=='STOCK')throw Error('REFRESH_STOCK_IDENTITY_REQUIRED');
   if(typeof t.config.identity.symbol!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$/.test(t.config.identity.symbol))throw Error('REFRESH_INSTRUMENT_ID_REQUIRED');
   if(t.config.asOf||t.config.evidenceBundle||t.config.fetchImpl||t.config.userAgent)throw Error('REFRESH_RESERVED_RUNTIME_FIELD');
   if(t.config.identity.market!==(t.provider==='SEC_STOCK'?'US':'KR'))throw Error('REFRESH_MARKET_MISMATCH');
   if(t.provider==='SEC_STOCK'&&!/^\d{1,10}$/.test(String(t.config.identity.cik||'')))throw Error('REFRESH_SEC_CIK_REQUIRED');
   if(t.provider==='KR_STOCK'&&!t.config.dartReports?.length&&!t.config.disclosureRange&&!t.config.krxFlow)throw Error('REFRESH_KR_REQUEST_REQUIRED');
   const allowed=['identity','dartReports','disclosureRange','krxFlow','corpMapAvailableAt','financialOptions','technical','supplementalFundamentalFacts','valuationInput','market','manager13F'];
   if(Object.keys(t.config).some(k=>!allowed.includes(k)))throw Error('REFRESH_UNKNOWN_COLLECTOR_FIELD');
  }
 }
 return {config,configDir:path.dirname(p),bytes,configHash:digest(bytes)};
}
export function refreshPrerequisites(config,env=process.env){
 const required=new Set();for(const t of config.targets){if(t.provider==='SEC_STOCK')required.add('SEC_USER_AGENT');if(t.provider==='KR_STOCK'){if(t.config.dartReports?.length||t.config.disclosureRange||!t.config.identity.corpCode)required.add('DART_API_KEY');if(t.config.krxFlow)required.add('KRX_API_KEY');}}
 return {targetCount:config.targets.length,providers:[...new Set(config.targets.map(t=>t.provider))],requiredEnvironment:[...required],missingEnvironment:[...required].filter(k=>!env[k]?.trim()),networkRequestsPerformed:false,scope:'EXPLICIT_CONFIG_ONLY_NOT_OFFICIAL_FULL_UNIVERSE'};
}
export function refreshInputCheckReason(error){
 const safe=new Set(['REFRESH_EXPLICIT_TARGETS_REQUIRED','REFRESH_INSTRUMENT_ID_REQUIRED','REFRESH_STOCK_IDENTITY_REQUIRED','REFRESH_MARKET_MISMATCH','REFRESH_SEC_CIK_REQUIRED','REFRESH_KR_REQUEST_REQUIRED','REFRESH_SOURCE_PACK_INSTRUMENTS_ONLY','DUPLICATE_INSTRUMENT_ID','REFRESH_SOURCE_ARTIFACT_ID_CONFLICT','REFRESH_TOTAL_INPUT_LIMIT','REFRESH_INPUT_CHANGED_BEFORE_COLLECTION','RAW_HASH_MISMATCH','RAW_PATH_NOT_ALLOWED','FUTURE_ANALYSIS_TIME','FUTURE_RAW_CAPTURE','FUTURE_IMPORTED_RECORD','INPUT_ANALYSIS_TIME_MISMATCH','BASIC_INPUT_SCHEMA_REQUIRED','INPUT_COLLECTION_LIMIT_OR_TYPE']);
 if(safe.has(error?.message))return error.message;
 if(error?.message?.startsWith('KRX_SERVICE_NOT_READY:'))return 'KRX_SERVICE_NOT_READY';
 return 'REFRESH_LOCAL_INPUT_CHECK_FAILED';
}
// Check the whole local batch before collection. Report only counts and fixed reason codes.
export function checkRefreshInputs(loaded,{now=new Date().toISOString()}={}){
 strictTimestamp(now);const ids=new Set(),artifactIds=new Set(),inputPacks=new Map();let apiTargets=0;
 const addId=symbol=>{if(ids.has(symbol))throw Error('DUPLICATE_INSTRUMENT_ID');ids.add(symbol);if(ids.size>3000)throw Error('REFRESH_TOTAL_INPUT_LIMIT');};
 for(const [index,t] of loaded.config.targets.entries()){
  if(t.provider!=='INPUT_PACK'){
   apiTargets++;addId(t.config.identity.symbol);
   if(t.provider==='KR_STOCK'&&t.config.krxFlow)buildKrxRequest({apiKey:'LOCAL_PREFLIGHT_ONLY',...t.config.krxFlow,asOf:now});
   continue;
  }
  const file=localFile(loaded.configDir,t.file),input=readInputPack(file);
  if(input.config.mode!=='IMPORTED'||Object.keys(input.config).some(k=>!['schema','mode','analysisAsOf','instruments','artifacts'].includes(k)))throw Error('REFRESH_SOURCE_PACK_INSTRUMENTS_ONLY');
  const prepared=prepareBasicData(input.config,{inputDir:input.inputDir,now});
  for(const item of input.config.instruments||[])addId(symbolOf(item.input));
  for(const a of input.config.artifacts||[]){if(artifactIds.has(a.artifactId))throw Error('REFRESH_SOURCE_ARTIFACT_ID_CONFLICT');artifactIds.add(a.artifactId);if(artifactIds.size>500)throw Error('REFRESH_TOTAL_INPUT_LIMIT');}
  inputPacks.set(index,{file,fileHash:input.fileHash,config:input.config,rawFiles:prepared.rawFiles});
 }
 return {report:{status:'LOCAL_INPUTS_CHECKED',targetCount:loaded.config.targets.length,apiTargetCount:apiTargets,inputPackTargetCount:inputPacks.size,plannedInstrumentCount:ids.size,localRawArtifactCount:artifactIds.size,networkRequestsPerformed:false,filesWritten:false,sourceMatching:'NOT_INDEPENDENTLY_VERIFIED',fullOfficialUniverseVerified:false},inputPacks};
}
// Never persist credential-bearing URLs or headers. Response bytes remain unmodified.
export function createRawCapture({dir,fetchImpl=fetch,credentials=[],clock=()=>new Date().toISOString()}){
 fs.mkdirSync(path.join(dir,'raw'),{recursive:true});const artifacts=[],requests=[],pending=new Set();let sequence=0;
 const sensitive=credentials.filter(x=>typeof x==='string'&&x.length);
 const fetchCaptured=async(url,options={})=>{
  const u=new URL(String(url));if(u.protocol!=='https:'||u.username||u.password||u.port||!hosts.has(u.hostname))throw Error('REFRESH_PROVIDER_URL_BLOCKED');
  if(u.hostname==='etf-market-api.islovep.workers.dev'&&(u.pathname!=='/'||u.searchParams.get('action')!=='gpt-data'||[...u.searchParams.keys()].some(k=>!['action','symbol'].includes(k))||options.method&&options.method!=='GET'||new Headers(options.headers).has('Authorization')))throw Error('REFRESH_WORKER_READ_ONLY_ROUTE');
  const index=++sequence;if(index>500)throw Error('REFRESH_ARTIFACT_LIMIT');
  const reference=new URL(u);for(const k of [...reference.searchParams.keys()])if(/key|token|secret|signature|auth/i.test(k))reference.searchParams.set(k,'REDACTED');
  const task=(async()=>{
   let r;try{r=await fetchImpl(u.toString(),{...options,redirect:'error'});}catch{throw Error('REFRESH_UPSTREAM_NETWORK_OR_TIMEOUT');}
   if(r.url&&(!hosts.has(new URL(r.url).hostname)||new URL(r.url).protocol!=='https:'))throw Error('REFRESH_REDIRECT_BLOCKED');
   const chunks=[];let size=0;
   if(r.body){const reader=r.body.getReader();try{while(true){const x=await reader.read();if(x.done)break;size+=x.value.length;if(size>32*1024*1024)throw Error('REFRESH_RAW_SIZE_LIMIT');chunks.push(Buffer.from(x.value));}}finally{await reader.cancel().catch(()=>{});}}
   const bytes=Buffer.concat(chunks);if(sensitive.some(s=>bytes.includes(Buffer.from(s))))throw Error('REFRESH_RESPONSE_CONTAINS_CREDENTIAL');
   const artifactId='refresh_'+String(index).padStart(4,'0'),local='raw/'+artifactId+'.bin',retrievedAt=clock();
   const headers=Object.fromEntries(['content-type','date','etag','last-modified'].map(k=>[k,r.headers.get(k)]).filter(([,v])=>v!==null));
   for(const v of Object.values(headers))if(sensitive.some(s=>v.includes(s)))throw Error('REFRESH_RESPONSE_HEADER_CONTAINS_CREDENTIAL');
   fs.writeFileSync(path.join(dir,local),bytes,{flag:'wx',mode:0o600});
   requests.push({artifactId,url:reference.toString(),status:r.status,retrievedAt,headers});
   artifacts.push({artifactId,localFile:local,sha256:digest(bytes),retrievedAt,sourceRef:reference.toString(),bytes:bytes.length});
   return new Response(bytes,{status:r.status,statusText:r.statusText,headers:r.headers});
  })();pending.add(task);try{return await task;}finally{pending.delete(task);}
 };
 return {fetchImpl:fetchCaptured,artifacts,requests,settle:async()=>{await Promise.allSettled([...pending]);}};
}
function validateGeneration(dir,expectedId){
 if(fs.realpathSync(dir)!==dir)throw Error('REFRESH_OUTPUT_PATH_INVALID');
 const p=path.join(dir,'refresh.json');if(fs.realpathSync(p)!==p)throw Error('REFRESH_OUTPUT_PATH_INVALID');
 const r=JSON.parse(fs.readFileSync(p));if(r.schema!=='BASIC_REFRESH_RECEIPT_V1'||r.status!=='COMPLETE'||r.runId!==expectedId||!Array.isArray(r.files)||!r.files.length)throw Error('REFRESH_GENERATION_INCOMPLETE');
 const seen=new Set();for(const f of r.files){
  if(typeof f.path!=='string'||f.path.includes('\\')||path.posix.normalize(f.path)!==f.path||seen.has(f.path)||f.path==='refresh.json')throw Error('REFRESH_INTEGRITY_FAILURE');seen.add(f.path);
  const target=path.resolve(dir,f.path);if(!target.startsWith(dir+path.sep)||fs.realpathSync(target)!==target||!fs.statSync(target).isFile())throw Error('REFRESH_INTEGRITY_FAILURE');
  const b=fs.readFileSync(target);if(b.length!==f.bytes||digest(b)!==f.sha256)throw Error('REFRESH_INTEGRITY_FAILURE');
 }
 if(!safeId(r.viewRunId))throw Error('REFRESH_VIEW_ID_INVALID');const viewDir=path.join(dir,'view','runs',r.viewRunId),receipt=validateReviewRun(viewDir);
 return {dir:viewDir,runId:r.viewRunId,receipt,refreshReceipt:r,generationDir:dir,status:'RESUMED'};
}
export function latestRefresh(outputRoot){
 const root=path.resolve(outputRoot),p=path.join(root,'latest_refresh.json');if(!fs.existsSync(p))throw Error('NO_COMPLETED_REFRESH');
 if(fs.realpathSync(root)!==root||fs.realpathSync(p)!==p)throw Error('REFRESH_OUTPUT_PATH_INVALID');
 const head=JSON.parse(fs.readFileSync(p));if(!safeId(head.runId))throw Error('REFRESH_HEAD_INVALID');
 const dir=path.join(root,'generations',head.runId);if(digest(fs.readFileSync(path.join(dir,'refresh.json')))!==head.receiptHash)throw Error('REFRESH_HEAD_HASH_MISMATCH');return validateGeneration(dir,head.runId);
}
export async function refreshBasic({configFile,outputRoot,runId,env=process.env,fetchImpl=fetch,clock=()=>new Date().toISOString(),priorReviewRunDir}={}){
 if(!safeId(runId))throw Error('INVALID_RUN_ID');const loaded=readRefreshConfig(configFile),rules=checkBasicRules(),preflight=refreshPrerequisites(loaded.config,env);
 if(preflight.missingEnvironment.length)throw Error('REFRESH_ENV_REQUIRED:'+preflight.missingEnvironment.join(','));
 const inputCheck=checkRefreshInputs(loaded,{now:clock()});
 const out=path.resolve(outputRoot);fs.mkdirSync(out,{recursive:true,mode:0o700});if(fs.realpathSync(out)!==out)throw Error('REFRESH_OUTPUT_PATH_INVALID');
 const lock=path.join(out,'.refresh.lock');let fd;try{fd=fs.openSync(lock,'wx',0o600);}catch(e){if(e.code==='EEXIST')throw Error('REFRESH_WRITER_BUSY_OR_PENDING');throw e;}
 let capture,dir,newGeneration=false;try{
  fs.writeFileSync(fd,JSON.stringify({runId,pid:process.pid,startedAt:clock()}));
  fs.mkdirSync(path.join(out,'generations'),{recursive:true});if(fs.realpathSync(path.join(out,'generations'))!==path.join(out,'generations'))throw Error('REFRESH_OUTPUT_PATH_INVALID');dir=path.join(out,'generations',runId);
  if(fs.existsSync(dir)){
   const old=validateGeneration(dir,runId);if(old.refreshReceipt.configHash!==loaded.configHash)throw Error('REFRESH_RUN_ID_CONFIG_CONFLICT');return old;
  }
  fs.mkdirSync(dir,{mode:0o700});newGeneration=true;json(path.join(dir,'refresh.json'),{schema:'BASIC_REFRESH_RECEIPT_V1',runId,status:'PENDING',configHash:loaded.configHash,automaticResend:false,startedAt:clock()});
  fs.writeFileSync(path.join(dir,'config.json'),loaded.bytes,{mode:0o600});
  const previous=fs.existsSync(path.join(out,'latest_refresh.json'))?latestRefresh(out):null;
  if(previous&&priorReviewRunDir)throw Error('AMBIGUOUS_REFRESH_PREVIOUS_RUN');
  const remotePrior=priorReviewRunDir?validateReviewRun(fs.realpathSync(priorReviewRunDir)):null;
  capture=createRawCapture({dir,fetchImpl,clock,credentials:[env.DART_API_KEY,env.KRX_API_KEY,env.SEC_USER_AGENT]});
  const instruments=[],importedArtifacts=[],targetResults=[];
  // Snapshot every checked local pack and exact raw byte before the first awaited API call.
  for(const [index,input] of inputCheck.inputPacks){
   const file=localFile(loaded.configDir,loaded.config.targets[index].file);
   if(fs.statSync(file).size>64*1024*1024)throw Error('REFRESH_INPUT_CHANGED_BEFORE_COLLECTION');
   const bytes=fs.readFileSync(file);
   if(digest(bytes)!==input.fileHash)throw Error('REFRESH_INPUT_CHANGED_BEFORE_COLLECTION');
   fs.writeFileSync(path.join(dir,'source_pack_'+index+'.json'),bytes,{mode:0o600});
   for(const a of input.config.artifacts||[]){
    const original=input.rawFiles.get(a.artifactId);
    if(fs.realpathSync(original)!==original||fs.statSync(original).size>32*1024*1024)throw Error('RAW_PATH_NOT_ALLOWED');
    const bytes=fs.readFileSync(original);if(digest(bytes)!==a.sha256)throw Error('REFRESH_INPUT_CHANGED_BEFORE_COLLECTION');
    const local='raw/pack_'+index+'_'+a.artifactId+'.bin';fs.writeFileSync(path.join(dir,local),bytes,{flag:'wx',mode:0o600});importedArtifacts.push({...a,localFile:local});
   }
  }
  for(const [index,t] of loaded.config.targets.entries()){
   if(t.provider==='INPUT_PACK'){
    const input=inputCheck.inputPacks.get(index);
    for(const a of input.config.artifacts||[]){
     if(capture.artifacts.some(x=>x.artifactId===a.artifactId))throw Error('REFRESH_SOURCE_ARTIFACT_ID_CONFLICT');
    }
    // Existing reviewed product contracts bind exact artifact IDs. Preserve those identities.
    const items=structuredClone(input.config.instruments);instruments.push(...items);
    targetResults.push({index,provider:t.provider,status:'CAPTURED_INPUT_NOT_SOURCE_CERTIFIED',instruments:items.map(x=>symbolOf(x.input))});continue;
   }
   if(t.provider==='WORKER_ETF'){
    const item=await collectWorkerEtf({identity:t.config.identity,fetchImpl:capture.fetchImpl,asOf:clock});
    item.input.technicalSource.rawReference={artifactId:capture.artifacts.at(-1).artifactId,sha256:capture.artifacts.at(-1).sha256};instruments.push(item);
    targetResults.push({index,provider:t.provider,instruments:[t.config.identity.symbol],status:'COLLECTED_NOT_INDEPENDENTLY_SOURCE_CERTIFIED'});continue;
   }
   const cfg={...structuredClone(t.config),asOf:clock(),fetchImpl:capture.fetchImpl};
   if(t.provider==='SEC_STOCK')cfg.userAgent=env.SEC_USER_AGENT;
   else {cfg.dartApiKey=env.DART_API_KEY;cfg.krxApiKey=env.KRX_API_KEY;}
   const context=await (t.provider==='SEC_STOCK'?collectUsStockContext(cfg):collectKrStockContext(cfg));
   json(path.join(dir,'collector_context_'+index+'.json'),context);
   const stockContextInput={identity:context.identity,fundamentalFacts:context.fundamental.history,valuationFacts:context.valuation.facts,valuation:context.valuation,flowFacts:context.flow.facts,events:context.events,ownershipFacts:context.ownership.facts,technical:context.technical,market:context.market,quality:context.dataQuality.sections,warnings:context.meta.warnings,financialOptions:cfg.financialOptions};
   assertNoSecrets(stockContextInput);instruments.push({input:{assetMode:'STOCK',analysisAsOf:cfg.asOf,stockContextInput}});
   targetResults.push({index,provider:t.provider,instruments:[context.identity.symbol],status:'COLLECTED_NOT_INDEPENDENTLY_SOURCE_CERTIFIED'});
  }
  await capture.settle();const analysisAsOf=clock();for(const item of instruments){item.input.analysisAsOf=analysisAsOf;if(item.input.stockContextInput)item.input.stockContextInput.asOf=analysisAsOf;if(item.input.etfMetricsInput)item.input.etfMetricsInput.asOf=analysisAsOf;}
  const pack={schema:'BASIC_RELEASE_INPUT_V1',mode:'IMPORTED',analysisAsOf,instruments,artifacts:[...capture.artifacts,...importedArtifacts]};
  assertNoSecrets(pack);json(path.join(dir,'requests.json'),capture.requests);json(path.join(dir,'input.json'),pack);
  // Basic importer applies source-claim quarantine and all existing temporal/identity gates.
  const built=buildBasicRelease({config:pack,inputDir:dir,outputRoot:path.join(dir,'view'),runId,priorRunDir:previous?.dir||priorReviewRunDir});
  const files=[];const walk=p=>{for(const e of fs.readdirSync(p,{withFileTypes:true})){const f=path.join(p,e.name);if(e.isSymbolicLink())throw Error('REFRESH_SYMLINK_FORBIDDEN');if(e.isDirectory())walk(f);else if(e.name!=='refresh.json'){const b=fs.readFileSync(f);files.push({path:path.relative(dir,f).split(path.sep).join('/'),bytes:b.length,sha256:digest(b)});}}};walk(dir);
  const receipt={schema:'BASIC_REFRESH_RECEIPT_V1',runId,status:'COMPLETE',configHash:loaded.configHash,analysisAsOf,targetCount:loaded.config.targets.length,targetResults,instrumentCount:instruments.length,rawArtifacts:pack.artifacts.length,ruleVersion:rules.version,ruleBlobSha:rules.blobSha,viewRunId:built.runId,previousRefreshRunId:previous?.refreshReceipt.runId||null,previousRefreshReceiptHash:previous?digest(fs.readFileSync(path.join(previous.generationDir,'refresh.json'))):null,previousReviewRunId:previous?.runId||remotePrior?.runId||null,files,automaticResend:false,automaticTradingAllowed:false,fullOfficialUniverseVerified:false,sourceMatching:'NOT_INDEPENDENTLY_VERIFIED',deployment:false};
  json(path.join(dir,'refresh.json'),receipt);const checked=validateGeneration(dir,runId);
  json(path.join(out,'latest_refresh.next.json'),{runId,receiptHash:digest(fs.readFileSync(path.join(dir,'refresh.json')))});fs.renameSync(path.join(out,'latest_refresh.next.json'),path.join(out,'latest_refresh.json'));
  return {...checked,status:'COMPLETE'};
 }catch(e){
  if(capture){await capture.settle();if(dir&&fs.existsSync(dir))json(path.join(dir,'requests.json'),capture.requests);}
  if(newGeneration&&dir&&fs.existsSync(dir)&&!fs.existsSync(path.join(dir,'failure.json'))){const known=/^[A-Z][A-Z0-9_]+(?::[A-Z0-9_,.]+)?$/;json(path.join(dir,'failure.json'),{runId,status:'FAILED_OR_PENDING',reason:known.test(e.message)?e.message:'REFRESH_COLLECTION_OR_VALIDATION_FAILED',at:clock(),automaticResend:false,lastValidPreserved:true});}
  throw e;
 }finally{fs.closeSync(fd);fs.unlinkSync(lock);}
}
