import {isObject,hasText,strictTimestamp} from './common.mjs';
const known=x=>hasText(x)&&!['UNKNOWN','UNVERIFIED','PENDING','UNRESOLVED','N/A'].includes(x.trim().toUpperCase());

// Metadata describes the exact price and volume series, not merely a provider name.
export function validateDailyScope({priceBasis,volumeBasis,calendar,asOf}) {
  const blockers=[];
  if(!isObject(priceBasis)||priceBasis.schema!=='PRICE_SERIES_BASIS_V1')return {verified:false,priceCalendarVerified:false,blockers:['PRICE_BASIS_REQUIRED']};
  if(priceBasis.status!=='VERIFIED')blockers.push('PRICE_BASIS_NOT_VERIFIED');
  for(const k of ['sourceRef','versionId','availableAt','instrumentId','market','venueScope','sessionScope'])if(!known(priceBasis[k]))blockers.push(`PRICE_BASIS_FIELD_REQUIRED:${k}`);
  try{if(strictTimestamp(priceBasis.availableAt)>strictTimestamp(asOf))blockers.push('PRICE_BASIS_LOOKAHEAD');}catch(e){blockers.push(e.message);}
  if(!hasText(calendar?.market)||priceBasis.market!==calendar.market)blockers.push('PRICE_CALENDAR_MARKET_MISMATCH');
  if(!hasText(calendar?.sessionScope)||priceBasis.sessionScope!==calendar.sessionScope)blockers.push('PRICE_CALENDAR_SESSION_MISMATCH');
  const priceCalendarVerified=blockers.length===0;
  for(const k of ['instrumentId','market','venueScope','sessionScope']){
    if(!known(volumeBasis?.[k]))blockers.push(`VOLUME_BINDING_REQUIRED:${k}`);
    else if(volumeBasis[k]!==priceBasis[k])blockers.push(`PRICE_VOLUME_SCOPE_MISMATCH:${k}`);
  }
  return {verified:blockers.length===0,priceCalendarVerified,blockers:[...new Set(blockers)]};
}
