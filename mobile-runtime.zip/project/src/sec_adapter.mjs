import {hasText,isObject,parseAmount,strictTimestamp,strictDate,round,factIdentity} from './common.mjs';

export function normalizeCik(cik){
  const digits=String(cik||'').replace(/\D/g,'');if(!digits||digits.length>10)throw new Error('INVALID_CIK');return digits.padStart(10,'0');
}
export function secHeaders(userAgent){
  if(!hasText(userAgent)||!/@/.test(userAgent))throw new Error('SEC_USER_AGENT_WITH_CONTACT_REQUIRED');
  return {'User-Agent':userAgent,Accept:'application/json, application/xml, text/xml, */*'};
}
export function buildSecSubmissionsUrl(cik){return `https://data.sec.gov/submissions/CIK${normalizeCik(cik)}.json`;}
export function buildSecCompanyFactsUrl(cik){return `https://data.sec.gov/api/xbrl/companyfacts/CIK${normalizeCik(cik)}.json`;}
export function buildSecFilingBaseUrl({cik,accessionNumber}){
  const cikNum=String(Number(normalizeCik(cik))),acc=String(accessionNumber||'').replace(/-/g,'');
  if(!/^\d{18}$/.test(acc))throw new Error('INVALID_ACCESSION');
  return `https://www.sec.gov/Archives/edgar/data/${cikNum}/${acc}/`;
}

export function discoverFilings(submissions,{forms=['10-K','10-K/A','10-Q','10-Q/A','8-K','13F-HR','13F-HR/A'],asOf,diagnostics=[]}={}){
  if(!isObject(submissions)||!isObject(submissions.filings?.recent))throw new Error('INVALID_SEC_SUBMISSIONS');
  const r=submissions.filings.recent,cutoff=strictTimestamp(asOf,'asOf'),out=[];
  for(let i=0;i<(r.form||[]).length;i++){
    const form=r.form[i];if(!forms.includes(form))continue;
    const accessionNumber=r.accessionNumber?.[i],availableAt=r.acceptanceDateTime?.[i];
    let t;
    try{t=strictTimestamp(availableAt,'SEC_ACCEPTANCE');}catch{
      diagnostics.push({code:'SEC_ACCEPTANCE_TIME_UNVERIFIED',accessionNumber,rawAcceptance:availableAt??null});continue;
    }
    if(!/^\d{10}-\d{2}-\d{6}$/.test(accessionNumber||'')){diagnostics.push({code:'SEC_ACCESSION_INVALID',accessionNumber});continue;}
    if(t>cutoff)continue;
    out.push({form,filingDate:r.filingDate?.[i],reportDate:r.reportDate?.[i]||null,accessionNumber,primaryDocument:r.primaryDocument?.[i]||null,availableAt,
      availabilityBasis:'SEC_ACCEPTANCE_TIMESTAMP',sourceRef:'SEC_SUBMISSIONS',versionId:accessionNumber,status:'VERIFIED'});
  }
  return out.sort((a,b)=>Date.parse(b.availableAt)-Date.parse(a.availableAt));
}

function chooseUnit(units,preferred){
  for(const p of preferred)if(Array.isArray(units?.[p]))return {unit:p,rows:units[p]};
  return null;
}
export function parseCompanyFacts(companyFacts,{cik,instrumentId,asOf,tags,preferredUnits=['USD','USD/shares','shares'],sourceRef='SEC_COMPANYFACTS',filings=[],diagnostics=[]}={}){
  if(!isObject(companyFacts)||!isObject(companyFacts.facts))throw new Error('INVALID_COMPANYFACTS');
  const cutoff=strictTimestamp(asOf,'asOf');
  if(normalizeCik(companyFacts.cik)!==normalizeCik(cik))throw new Error('SEC_CIK_MISMATCH');
  const facts=[];
  const evidence=new Map();
  for(const f of filings){
    if(f.status!=='VERIFIED'||!hasText(f.sourceRef)||!hasText(f.versionId))continue;
    try{strictTimestamp(f.availableAt,'filing.availableAt');}catch{continue;}
    const old=evidence.get(f.accessionNumber);
    evidence.set(f.accessionNumber,old===null||(old&&old.availableAt!==f.availableAt)?null:f);
  }
  for(const spec of tags||[]){
    const tax=companyFacts.facts[spec.taxonomy||'us-gaap'];const node=tax?.[spec.tag];if(!node)continue;
    const picked=chooseUnit(node.units,spec.preferredUnits||preferredUnits);if(!picked){diagnostics.push({code:'SEC_REQUESTED_UNIT_UNAVAILABLE',tag:spec.tag,availableUnits:Object.keys(node.units||{})});continue;}
    for(const row of picked.rows){
      const filed=row.filed,filing=evidence.get(row.accn);
      if(!filing){diagnostics.push({code:'SEC_FACT_AVAILABILITY_UNVERIFIED',accessionNumber:row.accn,tag:spec.tag,filed});continue;}
      const availableAt=filing.availableAt;if(Date.parse(availableAt)>cutoff)continue;
      if(spec.forms&&row.form&&!spec.forms.includes(row.form))continue;
      if(!Number.isFinite(row.val))continue;
      try{strictDate(row.end);if(row.start){strictDate(row.start);if(row.start>row.end)throw new Error();}}catch{diagnostics.push({code:'SEC_PERIOD_INVALID',tag:spec.tag});continue;}
      const days=row.start?(Date.parse(row.end)-Date.parse(row.start))/86400000+1:null;
      const periodKind=!row.start?'INSTANT':days>=70&&days<=110?'QUARTER':days>=330&&days<=380?'ANNUAL':'YTD';
      const currency=picked.unit==='shares'?'USD':picked.unit.split('/')[0];
      const unit=picked.unit==='shares'?'SHARES':picked.unit==='USD/shares'?'USD_PER_SHARE':picked.unit;
      facts.push({key:spec.key,period:row.frame||row.end||null,periodStart:row.start||null,periodEnd:row.end||null,value:row.val,unit,currency,account:spec.key.replace('fundamental.',''),fsDiv:'CFS',accountingBasis:'US_GAAP',periodKind,cumulative:['YTD','ANNUAL'].includes(periodKind),sourceAccount:spec.tag,sourceTaxonomy:spec.taxonomy||'us-gaap',shareAdjustmentBasis:spec.shareAdjustmentBasis||null,comparisonBasis:spec.comparisonBasis||null,
        availabilityBasis:'SEC_ACCEPTANCE_TIMESTAMP',apiFirstSeenVerified:false,
        instrumentId,cik:normalizeCik(cik),form:row.form||null,filingId:row.accn||null,availableAt,sourceRef,versionId:row.accn||`${spec.tag}:${row.end}:${filed}`,status:'VERIFIED',actualOrEstimate:'ACTUAL'});
    }
  }
  return facts;
}

function xmlTag(block,name){
  const re=new RegExp(`<(?:\\w+:)?${name}[^>]*>([\\s\\S]*?)<\\/(?:\\w+:)?${name}>`,'i');const m=String(block).match(re);return m?m[1].trim():null;
}
function strict13FManagerCik(cik){
  // Identity validation precedes formatting: never erase a minus sign or a name.
  if((typeof cik!=='string'&&typeof cik!=='number')||(typeof cik==='number'&&!Number.isSafeInteger(cik)))throw new Error('13F_MANAGER_CIK_INVALID');
  const digits=String(cik);
  if(!/^\d{1,10}$/.test(digits)||Number(digits)<=0)throw new Error('13F_MANAGER_CIK_INVALID');
  return digits.padStart(10,'0');
}

export function parse13FInfoTableXml(xml,{managerCik,accessionNumber,periodEnd,availableAt,sourceRef='SEC_13F_INFORMATION_TABLE'}={}){
  const validatedManagerCik=strict13FManagerCik(managerCik);
  strictTimestamp(availableAt,'availableAt');
  const blocks=String(xml||'').match(/<(?:\w+:)?infoTable\b[^>]*>[\s\S]*?<\/(?:\w+:)?infoTable>/gi)||[];
  const holdings=[];
  for(const b of blocks){
    const issuer=xmlTag(b,'nameOfIssuer'),title=xmlTag(b,'titleOfClass'),cusip=xmlTag(b,'cusip'),figi=xmlTag(b,'figi');
    const value=parseAmount(xmlTag(b,'value'),'13f.value');const shares=parseAmount(xmlTag(b,'sshPrnamt'),'13f.shares');const shareType=xmlTag(b,'sshPrnamtType');
    if(!hasText(issuer)||!hasText(cusip)||value===null||shares===null)continue;
    holdings.push({issuer,titleOfClass:title,cusip,figi,valueAsFiled:value,sharesOrPrincipal:shares,shareType,putCall:xmlTag(b,'putCall'),investmentDiscretion:xmlTag(b,'investmentDiscretion'),otherManager:xmlTag(b,'otherManager'),
      votingAuthority:{sole:parseAmount(xmlTag(b,'Sole'),'sole'),shared:parseAmount(xmlTag(b,'Shared'),'shared'),none:parseAmount(xmlTag(b,'None'),'none')}});
  }
  return {schema:'SEC_13F_INFO_TABLE_V1',managerCik:validatedManagerCik,accessionNumber,periodEnd,availableAt,sourceRef,status:'VERIFIED',holdings,
    limitations:['QUARTER_END_POSITION_NOT_REAL_TIME_TRADE','SHORT_POSITIONS_NOT_REPORTED','REPORTING_OMISSIONS_MAY_APPLY','VALUE_UNIT_PRESERVED_AS_FILED']};
}

export function compare13F(current,previous){
  const limitations=['ABSENCE_DOES_NOT_ALWAYS_MEAN_FULL_SALE','NOT_TRANSACTION_LEVEL_DATA','QUARTER_END_POSITION_NOT_REAL_TIME_TRADE'];
  const blocked=reason=>({status:'BLOCKED',reason,changes:[],limitations});
  try{
    if(strict13FManagerCik(current?.managerCik)!==strict13FManagerCik(previous?.managerCik))return blocked('13F_MANAGER_MISMATCH');
    strictDate(current.periodEnd);strictDate(previous.periodEnd);
    if(previous.periodEnd>=current.periodEnd)return blocked('13F_ORDERED_PERIODS_REQUIRED');
  }catch{return blocked('13F_MANAGER_AND_PERIOD_METADATA_REQUIRED');}
  if(!Array.isArray(current?.holdings)||!Array.isArray(previous?.holdings))return blocked('13F_HOLDINGS_REQUIRED');
  // One issuer can have common shares and PUT/CALL rows under the same CUSIP.
  // Ambiguous duplicate positions remain blocked rather than silently overwritten.
  const key=h=>JSON.stringify([h.cusip,h.titleOfClass,h.shareType,h.putCall||null,h.investmentDiscretion||null,h.otherManager||null]);
  const identity=h=>({cusip:h.cusip,issuer:h.issuer,titleOfClass:h.titleOfClass,shareType:h.shareType,putCall:h.putCall||null,investmentDiscretion:h.investmentDiscretion||null,otherManager:h.otherManager||null});
  for(const report of [current,previous]){
    if(report.holdings.some(h=>!hasText(h?.cusip)||!hasText(h?.titleOfClass)||!['SH','PRN'].includes(h?.shareType)||!['PUT','CALL',null,undefined,''].includes(h?.putCall)||!Number.isFinite(h?.sharesOrPrincipal)||h.sharesOrPrincipal<0))return blocked('13F_POSITION_IDENTITY_OR_AMOUNT_REQUIRED');
    if(new Set(report.holdings.map(key)).size!==report.holdings.length)return blocked('13F_AMBIGUOUS_DUPLICATE_POSITIONS');
  }
  const prev=new Map(previous.holdings.map(x=>[key(x),x])),changes=[];
  for(const h of current.holdings){
    const p=prev.get(key(h)),delta=p?h.sharesOrPrincipal-p.sharesOrPrincipal:null;
    changes.push({...identity(h),currentShares:h.sharesOrPrincipal,previousShares:p?.sharesOrPrincipal??null,deltaShares:delta,
      status:!p?'NEW_OR_PREVIOUSLY_UNREPORTED':delta>0?'INCREASED':delta<0?'DECREASED':'UNCHANGED'});prev.delete(key(h));
  }
  for(const p of prev.values())changes.push({...identity(p),currentShares:null,previousShares:p.sharesOrPrincipal,deltaShares:null,status:'ABSENT_CURRENT_NOT_PROOF_OF_FULL_SALE'});
  return {status:'COMPARABLE_POSITIONS_ONLY',changes,limitations};
}

export function buildSecFundamentalFacts(companyFacts,meta){
 const mapping={
 revenue:['RevenueFromContractWithCustomerExcludingAssessedTax','RevenueFromContractWithCustomerIncludingAssessedTax','Revenues','SalesRevenueNet'],
 operatingIncome:['OperatingIncomeLoss'],netIncome:['NetIncomeLoss'],profitCommon:['NetIncomeLossAvailableToCommonStockholdersBasic'],
 basicEps:['EarningsPerShareBasic'],dilutedEps:['EarningsPerShareDiluted'],weightedBasicShares:['WeightedAverageNumberOfSharesOutstandingBasic'],weightedDilutedShares:['WeightedAverageNumberOfDilutedSharesOutstanding'],
 assets:['Assets'],liabilities:['Liabilities'],equity:['StockholdersEquity'],cash:['CashAndCashEquivalentsAtCarryingValue'],
 operatingCashFlow:['NetCashProvidedByUsedInOperatingActivities'],capexPpe:['PaymentsToAcquirePropertyPlantAndEquipment'],interestExpense:['InterestExpense'],
 stockBasedCompensation:['ShareBasedCompensation'],dividendsPaid:['PaymentsOfDividends'],repurchases:['PaymentsForRepurchaseOfCommonStock'],sharesOutstanding:['CommonStockSharesOutstanding']
 };
 const tags=Object.entries(mapping).flatMap(([account,tags])=>tags.map(tag=>({key:`fundamental.${account}`,tag,forms:['10-K','10-Q','10-K/A','10-Q/A'],preferredUnits:/Eps$/.test(account)?['USD/shares']:/Shares$/.test(account)||account==='sharesOutstanding'?['shares']:['USD'],shareAdjustmentBasis:meta.shareAdjustmentBasis||null,comparisonBasis:meta.comparisonBasis||null})));
 const raw=parseCompanyFacts(companyFacts,{...meta,tags}),unique=new Map();
 for(const f of raw){
  // Same measurement/value/availability from taxonomy aliases is one fact; unequal aliases remain conflicts.
  const key=`${factIdentity(f)}|${f.availableAt}|${f.value}`;
  if(unique.has(key)){const old=unique.get(key);old.sourceAccounts.push(f.sourceAccount);}
  else unique.set(key,{...f,sourceAccounts:[f.sourceAccount],realDataVerified:meta.realDataVerified===true});
 }
 return [...unique.values()];
}
