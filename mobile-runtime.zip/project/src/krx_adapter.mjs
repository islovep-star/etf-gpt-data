import {hasText,isObject,parseAmount,strictDate,strictTimestamp,round} from './common.mjs';
import {calculateEps} from './financial_contract.mjs';

export function validateKrxServiceConfig(config,asOf){
  const blockers=[];
  if(!isObject(config)||config.schema!=='KRX_SERVICE_CONFIG_V1')return {approved:false,blockers:['KRX_SERVICE_CONFIG_REQUIRED']};
  for(const k of ['serviceId','serviceName','servicePath','approvalRef','approvedAt','sourceRef'])if(!hasText(config[k]))blockers.push(`KRX_SERVICE_FIELD_REQUIRED:${k}`);
  if(config.approved!==true)blockers.push('KRX_SERVICE_NOT_APPROVED');
  try{if(strictTimestamp(config.approvedAt,'approvedAt')>strictTimestamp(asOf,'analysis_as_of'))blockers.push('KRX_APPROVAL_LOOKAHEAD');}catch(e){blockers.push(e.message);}
  if(!/^\/svc\/apis\//.test(config.servicePath||''))blockers.push('KRX_SERVICE_PATH_INVALID');
  return {approved:blockers.length===0,blockers:[...new Set(blockers)]};
}

export function buildKrxRequest({apiKey,basDd,config,asOf}){
  if(!hasText(apiKey))throw new Error('KRX_API_KEY_REQUIRED');strictDate(basDd,'basDd');
  const c=validateKrxServiceConfig(config,asOf);if(!c.approved)throw new Error(`KRX_SERVICE_NOT_READY:${c.blockers.join(',')}`);
  const url=`https://data-dbg.krx.co.kr${config.servicePath}?basDd=${basDd.replaceAll('-','')}`;
  return {url,headers:{AUTH_KEY:apiKey,Accept:'application/json'},service:{id:config.serviceId,name:config.serviceName,sourceRef:config.sourceRef,approvalRef:config.approvalRef}};
}

function rowsOf(json){return json?.OutBlock_1||json?.OutBlock1||json?.output||json?.list||[];}
function field(row,names){for(const n of names)if(row?.[n]!==undefined&&row[n]!==null&&row[n]!=='')return row[n];return null;}
function dateOf(row,fallback){const raw=String(field(row,['BAS_DD','basDd','date'])||fallback||'');return /^\d{8}$/.test(raw)?`${raw.slice(0,4)}-${raw.slice(4,6)}-${raw.slice(6)}`:raw;}

function krxDailyIdentity(row,{instrumentMap=[],availableAt}={}){
  const codes=[];
  for(const name of ['ISU_SRT_CD','isuSrtCd','short_code','symbol','ISU_CD']){
    if(row[name]===undefined||row[name]===null||String(row[name]).trim()==='')continue;
    const value=String(row[name]).trim().toUpperCase();
    if(/^[0-9A-Z]{6}$/.test(value))codes.push(value);
    else if(name==='ISU_CD'&&/^KR[0-9A-Z]{9}\d$/.test(value)){
      const mapped=instrumentMap.filter(x=>x.isin===value&&/^[0-9A-Z]{6}$/.test(x.symbol||'')&&hasText(x.sourceRef)&&(()=>{try{return strictTimestamp(x.availableAt)<=strictTimestamp(availableAt);}catch{return false;}})());
      if(!mapped.length)throw new Error('KRX_IDENTITY_MAPPING_REQUIRED');
      codes.push(...mapped.map(x=>x.symbol));
    }else throw new Error('KRX_IDENTITY_INVALID');
  }
  if(new Set(codes).size>1)throw new Error('KRX_IDENTITY_CONFLICT');
  return codes[0]||null;
}

export function parseKrxStockDaily(json,{symbol,availableAt,sourceRef,versionId,serviceId,basDd,instrumentMap=[]}={}){
  strictTimestamp(availableAt,'availableAt');
  const out=[];
  for(const row of rowsOf(json)){
    const code=krxDailyIdentity(row,{instrumentMap,availableAt});
    if(!code)continue;
    if(symbol&&code!==symbol)continue;
    const date=dateOf(row,basDd);try{strictDate(date,'tradeDate');}catch{continue;}
    const close=parseAmount(field(row,['TDD_CLSPRC','tddClsprc','close']),'close');
    const open=parseAmount(field(row,['TDD_OPNPRC','tddOpnprc','open']),'open');
    const high=parseAmount(field(row,['TDD_HGPRC','tddHgprc','high']),'high');
    const low=parseAmount(field(row,['TDD_LWPRC','tddLwprc','low']),'low');
    const volume=parseAmount(field(row,['ACC_TRDVOL','accTrdvol','volume']),'volume');
    const turnover=parseAmount(field(row,['ACC_TRDVAL','accTrdval','turnover']),'turnover');
    if([close,open,high,low,volume].some(x=>x===null))continue;
    out.push({instrumentId:code,tradeDate:date,open,high,low,close,volume,turnover,availableAt,sourceRef,versionId:versionId||`${serviceId||'KRX'}:${date}`,serviceId,status:'PARTIAL',realDataVerified:false,sourceVerification:{status:'UNVERIFIED'},calculationStatus:'NOT_APPLICABLE',identityFields:Object.fromEntries(['ISU_SRT_CD','isuSrtCd','short_code','symbol','ISU_CD'].filter(k=>row[k]!==undefined).map(k=>[k,row[k]]))});
  }
  return out.sort((a,b)=>a.tradeDate.localeCompare(b.tradeDate));
}

export function parseKrxInvestorFlow(json,{symbol,availableAt,sourceRef,versionId,serviceId,basDd,turnoverScope=null}={}){
  strictTimestamp(availableAt,'availableAt');
  const out=[];
  for(const row of rowsOf(json)){
    const code=String(field(row,['ISU_SRT_CD','isuSrtCd','short_code','symbol'])||symbol||'').trim().toUpperCase();
    if(symbol&&code&&code!==symbol)continue;
    const date=dateOf(row,basDd);try{strictDate(date,'tradeDate');}catch{continue;}
    const investor=String(field(row,['INVST_TP_NM','invstTpNm','investorType','INVESTOR'])||'').trim();
    if(!investor)continue;
    const netAmount=parseAmount(field(row,['NETBID_TRDVAL','netBidTrdval','netBuyAmount','NET_BUY_VALUE']),'netBuyAmount');
    const netVolume=parseAmount(field(row,['NETBID_TRDVOL','netBidTrdvol','netBuyVolume','NET_BUY_VOLUME']),'netBuyVolume');
    const turnover=parseAmount(field(row,['ACC_TRDVAL','accTrdval','turnover']),'turnover');
    if(netAmount===null&&netVolume===null)continue;
    out.push({instrumentId:code,tradeDate:date,investorType:investor,netBuyAmount:netAmount,netBuyVolume:netVolume,turnover,turnoverScope,
      availableAt,sourceRef,versionId:versionId||`${serviceId||'KRX_FLOW'}:${date}:${investor}`,serviceId,status:'VERIFIED'});
  }
  return out.sort((a,b)=>a.tradeDate.localeCompare(b.tradeDate)||a.investorType.localeCompare(b.investorType));
}

// Current KRX MDCSTAT022 detailed investor groups; other classifications need a
// separately reviewed adapter instead of a caller-defined category expansion.
// https://data.krx.co.kr/contents/MDC/MDI/outerLoader/index.cmd?screenId=MDCSTAT022
export const KRX_INSTITUTION_COMPONENTS=Object.freeze(['금융투자','보험','투신','사모','은행','기타금융','연기금 등']);
const INSTITUTION_COMPONENT_SET=new Set(KRX_INSTITUTION_COMPONENTS);

export function aggregateInvestorFlow(rows,{asOf,instrumentId,windows=[5,20,60],expectedTradingDates=null,institutionComponents=[]}={}){
 const cutoff=strictTimestamp(asOf,'asOf');
 if(!Array.isArray(institutionComponents)||institutionComponents.some(k=>!hasText(k)||k!==k.trim()||/^(기관|기관계|기관합계|외국인|외국인합계)$/.test(k))||new Set(institutionComponents).size!==institutionComponents.length)throw new Error('FLOW_INSTITUTION_COMPONENTS_MUST_BE_UNIQUE_DISJOINT_CATEGORIES');
 if(institutionComponents.some(k=>!INSTITUTION_COMPONENT_SET.has(k)))throw new Error('FLOW_INSTITUTION_COMPONENT_CLASSIFICATION_UNSUPPORTED');
 const completeInstitutionComponents=institutionComponents.length===KRX_INSTITUTION_COMPONENTS.length;
 if(windows.some(n=>!Number.isInteger(n)||n<1))throw new Error('FLOW_WINDOW_INVALID');
 if(expectedTradingDates){expectedTradingDates.forEach(d=>strictDate(d));if(new Set(expectedTradingDates).size!==expectedTradingDates.length||expectedTradingDates.some(d=>d>asOf.slice(0,10)))throw new Error('FLOW_EXPECTED_DATES_INVALID');}
 let eligible=(rows||[]).filter(x=>{try{return strictTimestamp(x.availableAt)<=cutoff&&strictDate(x.tradeDate)&&x.tradeDate<=asOf.slice(0,10);}catch{return false;}});
 const ids=new Set(eligible.map(x=>x.instrumentId));
 if(instrumentId)eligible=eligible.filter(x=>x.instrumentId===instrumentId);
 else if(ids.size>1||ids.has(undefined))throw new Error('FLOW_INSTRUMENT_MISMATCH');
 const dates=expectedTradingDates?[...expectedTradingDates].sort():[...new Set(eligible.map(x=>x.tradeDate))].sort();
 const result={foreign:{},institution:{}};
 for(const group of Object.keys(result))for(const n of windows){
  const selectedDates=dates.slice(-n),observations=[],warnings=[];let invalid=false;
  for(const date of selectedDates){
   const daily=eligible.filter(x=>x.tradeDate===date),byType=new Map();
   for(const row of daily){const old=byType.get(row.investorType);if(!old||Date.parse(row.availableAt)>Date.parse(old.availableAt))byType.set(row.investorType,row);else if(Date.parse(row.availableAt)===Date.parse(old.availableAt)&&(row.netBuyAmount!==old.netBuyAmount||row.turnover!==old.turnover))byType.set(row.investorType,{...old,status:'BLOCKED',netBuyAmount:null});}
   const totals=[...byType.values()].filter(x=>group==='foreign'?/^(외국인|외국인합계)$/.test(x.investorType):/^(기관|기관계|기관합계)$/.test(x.investorType));
   let chosen=totals;
   if(!totals.length&&group==='institution'&&institutionComponents.length){
    if(!completeInstitutionComponents){warnings.push('INSTITUTION_COMPONENT_COVERAGE_INCOMPLETE');continue;}
    chosen=institutionComponents.map(k=>byType.get(k));
   }
   if(!chosen.length||chosen.some(x=>!x||!Number.isFinite(x.netBuyAmount)||x.status==='BLOCKED')){if(chosen.some(x=>x?.status==='BLOCKED'))invalid=true;continue;}
   if(totals.length>1){invalid=true;warnings.push('OVERLAPPING_TOTAL_ROWS');continue;}
   const turnoverValues=[...new Set(chosen.map(x=>x.turnover).filter(Number.isFinite))];
   // ACC_TRDVAL is not assumed to be market turnover without an explicit scope receipt.
   const turnover=turnoverValues.length===1&&chosen.every(x=>x.turnoverScope==='INSTRUMENT_DAY_TOTAL'&&Number.isFinite(x.turnover))?turnoverValues[0]:null;
   observations.push({date,net:chosen.reduce((a,x)=>a+x.netBuyAmount,0),turnover,rows:chosen});
  }
  const observedDays=observations.length,coverageVerified=!!expectedTradingDates&&selectedDates.length===n&&observedDays===n;
  const status=invalid?'BLOCKED':!observedDays?'MISSING':coverageVerified&&observations.every(o=>o.rows.every(x=>x.status==='VERIFIED'&&x.realDataVerified===true&&hasText(x.sourceRef)&&hasText(x.versionId)))?'VERIFIED':'PARTIAL';
  const net=observedDays&&!invalid?observations.reduce((a,x)=>a+x.net,0):null;
  const turnover=observedDays&&observations.every(o=>Number.isFinite(o.turnover)&&o.turnover>0)?observations.reduce((a,x)=>a+x.turnover,0):null;
  result[group][`${n}D`]={netBuyAmount:net,netBuyDays:net===null?null:observations.filter(x=>x.net>0).length,observedDays,expectedDays:n,
   expectedDates:selectedDates,coverageVerified,status,calculationStatus:net===null?'UNAVAILABLE':'CALCULATED',
   turnoverRatioPct:net!==null&&turnover>0?round(net/turnover*100,6):null,ratioStatus:net!==null&&turnover>0?status:'MISSING',
   warnings:[...new Set([...warnings,...(!expectedTradingDates?['EXPECTED_TRADING_DATES_UNVERIFIED']:[])])],evidence:observations.flatMap(o=>o.rows)};
 }
 return result;
}

export function buildFlowFacts(aggregated,{instrumentId,availableAt,sourceRef='KRX_INVESTOR_FLOW',versionId='KRX_FLOW'}={}){
 strictTimestamp(availableAt,'availableAt');const facts=[];
 for(const [group,windows] of Object.entries(aggregated||{}))for(const [window,x] of Object.entries(windows)){
  if((x.evidence||[]).some(f=>f.instrumentId!==instrumentId||strictTimestamp(f.availableAt)>strictTimestamp(availableAt)))throw new Error('FLOW_FACT_EVIDENCE_MISMATCH');
  const base={period:window,instrumentId,availableAt,sourceRef,expectedDays:x.expectedDays,observedDays:x.observedDays,coverageVerified:x.coverageVerified,evidence:x.evidence,warnings:x.warnings,calculationStatus:x.calculationStatus};
  facts.push({...base,key:`flow.${group}.${window}.netBuyAmount`,value:x.netBuyAmount,unit:'KRW',versionId:`${versionId}:${group}:${window}`,status:x.status});
  facts.push({...base,key:`flow.${group}.${window}.turnoverRatioPct`,value:x.turnoverRatioPct,unit:'PCT',versionId:`${versionId}:${group}:${window}:ratio`,status:x.ratioStatus});
 }
 return facts;
}

export function calculateValuation(input){
 const {price,sharesOutstanding,equity,dividendPerShare,availableAt,instrumentId,sourceRef='CALCULATED',currency='KRW',assetType='STOCK',epsInput={}}=input;
 if(assetType!=='STOCK')throw new Error('CORPORATE_VALUATION_NOT_APPLICABLE_TO_ETF');
 if(![price,sharesOutstanding].every(x=>Number.isFinite(x)&&x>0))throw new Error('VALUATION_MARKET_INPUT_REQUIRED');
 strictTimestamp(availableAt,'availableAt');
 const epsResult=calculateEps({...epsInput,asOf:availableAt});
 const validScope=r=>r.inputs.length&&r.inputs.every(f=>f.instrumentId===instrumentId&&f.currency===currency);
 const eps=validScope(epsResult.basic)?epsResult.basic.value:null;
 const dilutedEps=validScope(epsResult.diluted)?epsResult.diluted.value:null;
 // PER requires an explicit annual/TTM earnings period and the same split-adjusted price basis.
 const epsBasis=epsResult.basic.inputs[0];
 const perComparable=epsBasis&&['ANNUAL','TTM'].includes(epsBasis.periodKind)&&input.priceShareAdjustmentBasis===epsBasis.shareAdjustmentBasis;
 const marketCap=price*sharesOutstanding,bps=Number.isFinite(equity)?equity/sharesOutstanding:null;
 const per=eps>0&&perComparable?price/eps:null,pbr=bps>0?price/bps:null;
 const dividendYield=Number.isFinite(dividendPerShare)&&dividendPerShare>=0?dividendPerShare/price*100:null;
 const current={price,sharesOutstanding,marketCap,eps,dilutedEps,bps,per,pbr,dividendYield,epsResult,
  epsBasis:eps===null?'MISSING_COMPARABLE_EPS':'REPORTED_OR_WEIGHTED_AVERAGE',
  perStatus:eps===null?'MISSING_EARNINGS':eps<0?'NEGATIVE_EARNINGS':eps===0?'ZERO_EARNINGS':!perComparable?'INCOMPARABLE_EARNINGS_OR_PRICE_BASIS':'AVAILABLE',availableAt,
  calculationStatus:'CALCULATED',sourceStatus:'PARTIAL',warnings:['MARKET_INPUT_SOURCE_VALIDATION_REQUIRED',...(input.netIncomeTtm!==undefined?['LEGACY_NET_INCOME_DIVIDED_BY_PERIOD_END_SHARES_DISABLED']:[])]};
 const facts=[['valuation.marketCap',marketCap,currency],['valuation.EPS',eps,`${currency}_PER_SHARE`],['valuation.dilutedEPS',dilutedEps,`${currency}_PER_SHARE`],['valuation.BPS',bps,`${currency}_PER_SHARE`],['valuation.PER',per,'MULTIPLE'],['valuation.PBR',pbr,'MULTIPLE'],['valuation.dividendYield',dividendYield,'PCT']]
 .filter(([,v])=>v!==null).map(([key,value,unit])=>({key,value:round(value,6),unit,currency,instrumentId,availableAt,sourceRef,versionId:`${sourceRef}:${key}:${availableAt}`,status:'PARTIAL',calculationStatus:'CALCULATED',sourceStatus:'PARTIAL',inputs:key.includes('EPS')||key==='valuation.PER'?epsResult:undefined}));
 return {current,facts};
}
