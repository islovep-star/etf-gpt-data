import {buildDecisionSupportBundle} from './unified_pipeline.mjs';
import {metric} from './financial_contract.mjs';
import {evaluateReview,publicDiagnostic} from '../vendor/p0/src/review_guard.mjs';
import {toP0Observation,validateRecordEnvelope} from './data_record_contract.mjs';
import {sha256,strictDate,strictTimestamp} from './common.mjs';
import {assertReviewedProductMetadata} from './product_metadata_contract.mjs';

const missing=reason=>({value:null,status:'MISSING',calculationStatus:'UNAVAILABLE',reason,inputs:[]});
export function conciseEvidence(value){
 if(Array.isArray(value))return value.map(conciseEvidence);
 if(!value||typeof value!=='object')return value;
 return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,k==='inputs'?v.map(f=>({key:f.key,value:f.value,unit:f.unit,periodStart:f.periodStart??null,periodEnd:f.periodEnd??null,periodKind:f.periodKind??null,sourceRef:f.sourceRef,versionId:f.versionId,rawReference:f.rawReference,rawReferences:f.rawReferences,availableAt:f.availableAt,sourceVerification:f.sourceVerification})):conciseEvidence(v)]));
}
function stockCore(context){
 const m=context.fundamental.metrics,periods=m.periods;
 const annual=periods.filter(p=>p.periodKind==='ANNUAL').at(-1),quarter=periods.filter(p=>p.periodKind==='QUARTER').at(-1);
 const facts=context.fundamental.facts;
 const at=(account,p)=>facts.filter(f=>f.account===account&&f.periodStart===(p?.periodStart??null)&&f.periodEnd===p?.periodEnd&&f.periodKind===p?.periodKind);
 const fact=(account,p)=>{const f=at(account,p);return f.length===1?{...f[0],formula:'REPORTED',inputs:[f[0]]}:missing('UNIQUE_REPORTED_PERIOD_REQUIRED');};
 const growth=m.growth.filter(g=>g.periodKind==='ANNUAL'&&g.periodEnd===annual?.periodEnd);
 const comparablePrior=growth.find(g=>g.key==='revenue.yoyPct')?.inputs?.[1];
 const prior=periods.find(p=>p.periodKind==='ANNUAL'&&p.periodStart===comparablePrior?.periodStart&&p.periodEnd===comparablePrior?.periodEnd);
 const a=annual?.metrics.operatingMarginPct,b=prior?.metrics.operatingMarginPct;
 const marginChange=metric('operatingMarginChangePp',a?.value!=null&&b?.value!=null?a.value-b.value:null,[...(a?.inputs||[]),...(b?.inputs||[])],{unit:'PERCENTAGE_POINTS',formula:'comparable current annual operating margin minus prior annual margin',reason:a?.value!=null&&b?.value!=null?null:'COMPARABLE_MARGINS_REQUIRED'});
 const instant=p=>({...p,periodStart:null,periodKind:'INSTANT'});
 return {basis:{annual:annual?{periodStart:annual.periodStart,periodEnd:annual.periodEnd,currency:annual.currency}:null,quarter:quarter?{periodStart:quarter.periodStart,periodEnd:quarter.periodEnd}:null,scope:'HISTORICAL_SAMPLE_NOT_CURRENT_FINANCIALS'},
  earnings:{revenue:fact('revenue',annual),operatingIncome:fact('operatingIncome',annual),netIncome:fact('netIncome',annual),basicEps:annual?.eps.basic||missing('EPS_REQUIRED'),dilutedEps:annual?.eps.diluted||missing('DILUTED_EPS_REQUIRED'),latestQuarterEps:quarter?.eps||null,growth,ttm:m.ttm},
  margins:{operatingMarginPct:a||missing('MARGIN_INPUT_REQUIRED'),changePp:marginChange},
  cashFlow:{operatingCashFlow:fact('operatingCashFlow',annual),capexPpe:fact('capexPpe',annual),fcfPpe:annual?.metrics.fcfPpe||missing('OCF_CAPEX_REQUIRED'),fcfTotal:annual?.metrics.fcfTotal||missing('TOTAL_CAPEX_DEFINITION_REQUIRED'),reportedFcf:annual?.reportedFcf||missing('REPORTED_FCF_NOT_OBTAINED')},
  debt:{cash:fact('cash',instant(annual)),interestBearingDebt:fact('interestBearingDebt',instant(annual)),currentDebt:fact('currentDebt',instant(annual)),netDebt:annual?.metrics.netDebt||missing('DEBT_CASH_REQUIRED'),cashToCurrentDebt:annual?.metrics.cashToCurrentDebt||missing('CURRENT_DEBT_REQUIRED'),interestCoverage:annual?.metrics.ebitInterestCoverage||missing('EXPLICIT_EBIT_INTEREST_REQUIRED'),maturitySchedule:missing('FULL_MATURITY_SCHEDULE_NOT_OBTAINED')},
  shares:{outstanding:fact('sharesOutstanding',instant(annual)),weightedBasic:fact('weightedBasicShares',annual),weightedDiluted:fact('weightedDilutedShares',annual),dilutedShareIncrementPct:annual?.metrics.dilutedShareIncrementPct||missing('DILUTED_SHARES_REQUIRED'),outstandingChanges:m.shareChanges,issuanceConversionBuyback:missing('CORPORATE_ACTION_RECONCILIATION_NOT_OBTAINED')},
  valuation:{per:missing('ALIGNED_PRICE_ANNUAL_EPS_AND_SHARE_BASIS_REQUIRED'),pbr:missing('ALIGNED_PRICE_COMMON_EQUITY_AND_OUTSTANDING_SHARES_REQUIRED'),comparisons:m.valuationComparisons},
  sourceConflicts:periods.filter(p=>p.eps.basic.reconciliation?.status==='CONFLICT').map(p=>({periodStart:p.periodStart,periodEnd:p.periodEnd,periodKind:p.periodKind,eps:p.eps.basic})),
  risks:{auditOpinion:missing('AUDITOR_OPINION_NOT_REVIEWED'),goingConcern:missing('GOING_CONCERN_NOT_REVIEWED'),tradingSuspension:missing('CURRENT_TRADING_STATUS_NOT_OBTAINED')}};
}

/** Public output boundary is informational only. Caller assertions cannot approve actions. */
export function buildCoreReview(input){
 const bundle=buildDecisionSupportBundle(input);
 const symbol=input.assetMode==='STOCK'?bundle.sections.stockContext.identity.symbol:input.etfMetricsInput?.instrumentId;
 if(!symbol)throw new Error('OUTPUT_IDENTITY_REQUIRED');
 const sourceFacts=input.assetMode==='STOCK'?bundle.sections.stockContext.fundamental.facts:(input.sourceFacts||[]);
 const artifacts=input.assetMode==='STOCK'?input.stockContextInput.evidenceBundle?.rawArtifacts:input.etfMetricsInput.evidenceBundle?.rawArtifacts;
 const productForOutput=input.productMetadata?structuredClone(input.productMetadata):null,productWarnings=[];
 if(input.assetMode==='ETF'&&input.productMetadata){
  const product=productForOutput,cutoff=input.analysisAsOf.slice(0,10);
  assertReviewedProductMetadata(product,{instrumentId:symbol,rawArtifacts:artifacts});
  for(const date of [product.monthly?.measurementDate,product.pcf?.date,product.priceNav?.date]){strictDate(date);if(date>cutoff)throw new Error('FUTURE_PRODUCT_METADATA');}
  for(const part of [product.monthly,product.pcf]){const a=artifacts?.find(a=>a.artifactId===part.rawReference?.artifactId&&a.sha256===part.rawReference?.sha256);if(!a||strictTimestamp(a.retrievedAt)>strictTimestamp(input.analysisAsOf))throw new Error('PRODUCT_SOURCE_REFERENCE_REQUIRED');}
  product.priceNav.fields={};
  for(const [key,account] of [['close','close'],['nav','navPerUnit'],['volume','volume']]){
   const matches=sourceFacts.filter(f=>f.instrumentId===symbol&&f.account===account&&f.tradeDate===product.priceNav.date);
   if(matches.some(f=>!validateRecordEnvelope(f,{asOf:input.analysisAsOf,rawArtifacts:artifacts}).valid))throw new Error('PRODUCT_PRICE_SOURCE_MISMATCH');
   const source=matches.length===1?matches[0]:null;
   const verified=source?.status==='VERIFIED'&&source.realDataVerified===true&&source.sourceVerification?.status==='MATCHED_TO_ORIGINAL'&&(source.actualOrEstimate===undefined||source.actualOrEstimate==='ACTUAL');
   if(verified&&source.value!==product.priceNav[key])throw new Error('PRODUCT_PRICE_SOURCE_MISMATCH');
   if(verified)product.priceNav.fields[key]={value:source.value,status:'VERIFIED',reason:null,rawReference:source.rawReference};
   else {
    const reason=source?`PRODUCT_PRICE_SOURCE_NOT_VERIFIED:${key}:${source.status}:${source.sourceVerification?.status}:${source.actualOrEstimate||'UNSPECIFIED'}`:matches.length?'CONFLICTING_PRICE_SOURCE_RECORDS':'PRICE_SOURCE_MISSING';
    product.priceNav[key]=null;
    product.priceNav.fields[key]={value:null,status:source?.status==='MISSING'||!matches.length?'MISSING':'BLOCKED',reason,sourceStatus:source?.status||null,sourceVerification:source?.sourceVerification||null,reportedValue:source?.value??null,rawReferences:matches.map(f=>f.rawReference)};
    productWarnings.push(reason);
   }
  }
  // A missing/conflicting source invalidates only the dependent numerical metric.
  if(product.priceNav.close===null||product.priceNav.nav===null){bundle.sections.etfMetrics.metrics.premiumDiscountPct={...missing('VERIFIED_ACTUAL_PRICE_AND_NAV_REQUIRED'),unit:'PCT'};bundle.sections.etfMetrics.missing=[...new Set([...bundle.sections.etfMetrics.missing,'premiumDiscountPct'])];}
  if(product.pcf.completeActualPortfolio!==false)throw new Error('PCF_CANNOT_PROMOTE_ACTUAL_HOLDINGS');
  if(product.reportedManagementFee&&(!validateRecordEnvelope(product.reportedManagementFee,{asOf:input.analysisAsOf,rawArtifacts:artifacts}).valid||product.reportedManagementFee.instrumentId!==symbol))throw new Error('PRODUCT_FEE_EVIDENCE_REQUIRED');
 }
 // The original-export samples have date-only observation times. Do not create midnight P0 observations.
 const observations=sourceFacts.map(f=>toP0Observation(f,{asOf:input.analysisAsOf,rawArtifacts:artifacts||[]}));
 const p0=bundle.sections.p0Review||evaluateReview({mode:'LIVE',asOf:input.analysisAsOf,analysisProfile:'UNCONFIGURED',facts:observations.filter(x=>x.status==='VERIFIED')},null);
 const core=input.assetMode==='STOCK'?stockCore(bundle.sections.stockContext):{etfMetrics:bundle.sections.etfMetrics,product:productForOutput,technical:bundle.sections.technical?{...bundle.sections.technical,status:'COLLECTED_REVIEW_HOLD',corporateEps:'NOT_APPLICABLE',source:input.technicalSource||null}:{status:'PENDING',reason:'EXISTING_WORKER_INDICATOR_COMPARISON_DEFERRED_STAGE12',dailyWeeklyEngine:'REUSE_EXISTING_ONLY',corporateEps:'NOT_APPLICABLE'}};
 const warnings=[...bundle.warnings,...productWarnings,'BOUNDED_SOURCE_SAMPLE_NOT_LIVE_OR_PIT','INDEPENDENT_REVIEW_HOLD','NO_USER_ACCOUNT_OR_ACTION_APPROVAL'];
 const out={schema:'OBJECTIVE_CORE_REVIEW_V1',instrumentId:symbol,instrumentName:input.assetMode==='STOCK'?bundle.sections.stockContext.identity.instrumentName:input.productMetadata?.name||input.etfMetricsInput?.instrumentName,assetType:input.assetMode,analysisAsOf:input.analysisAsOf,core:conciseEvidence(core),warnings,
  safety:{status:'HOLD',dataViewAvailable:true,actionReviewCandidate:false,actionAllowed:false,automaticTradingAllowed:false,orderExecution:false,independentReview:'HOLD',p0:publicDiagnostic(p0),blockerCodes:[...new Set(p0.blockers.map(x=>x.split(':')[0]))],sourceObservationReadyCount:observations.filter(x=>x.status==='VERIFIED').length,sourceObservationBlockedCount:observations.filter(x=>x.status!=='VERIFIED').length,privateAccountAttached:Boolean(input.reviewPacket),privateAccountScope:input.reviewPacket?.exampleOnly?'SYNTHETIC_TEST_ONLY':input.reviewPacket?'PRIVATE_NOT_EXPORTED':'NOT_PROVIDED'},
  decisionAuthority:'GPT_INTERPRETATION_REQUIRES_SEPARATE_REVIEW',judgement:'NONE',technicalScoreContribution:0,automaticTradingAllowed:false};
 return {...out,packetHash:sha256(out)};
}
