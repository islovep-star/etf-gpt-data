"""Persist only captured analysis evidence from the private runner data directory."""
import os,pathlib,zipfile
root=pathlib.Path(os.environ['MOBILE_DATA_DIR']).resolve()
out=pathlib.Path(os.environ['MOBILE_REPORT_DIR']).resolve()/'PRIVATE_REFRESH_EVIDENCE.zip'
if root.exists():
    files=[];total=0
    for p in root.rglob('*'):
        if p.is_symlink():raise SystemExit('EVIDENCE_SYMLINK_BLOCKED')
        if p.is_file():
            total+=p.stat().st_size
            if total>256*1024*1024:raise SystemExit('EVIDENCE_SIZE_LIMIT')
            files.append(p)
    if files:
        out.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
            for p in files:z.write(p,p.relative_to(root).as_posix())
        print('Private captured evidence archived; no key directory included.')
