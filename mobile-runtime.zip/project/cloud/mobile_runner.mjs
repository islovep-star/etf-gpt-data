import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {execFile} from 'node:child_process';
import {refreshBasic,readRefreshConfig,checkRefreshInputs,refreshPrerequisites} from '../src/basic_refresh.mjs';
import {validateReviewRun,digest} from '../src/review_run_store.mjs';
import {prepareMobileConfig,inspectMobileDeployment,APP_ACCOUNT_ID,APP_COMPATIBILITY_DATE} from '../src/mobile_deployment_preflight.mjs';
import {appAdmin,APP_ORIGIN} from '../tools/mobile_app_admin.mjs';
import {checkBasicLive} from '../tools/check_basic_live.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),app=path.join(root,'deployment/basic_app');
const actions=new Set(['check','bootstrap','deploy','refresh-publish','push-test']);
const mutations=new Set(['bootstrap','deploy','refresh-publish','push-test']);
const fixedErrors=new Set(['MOBILE_PRIVATE_REPOSITORY_REQUIRED','MOBILE_MANUAL_DEFAULT_BRANCH_REQUIRED','MOBILE_OPERATION_NOT_CONFIRMED','MOBILE_RERUN_MUTATION_BLOCKED','MOBILE_ACTION_INVALID','MOBILE_KV_ID_REQUIRED','MOBILE_CF_TOKEN_REQUIRED','MOBILE_REFRESH_CONFIG_REQUIRED','MOBILE_TARGETS_CONFIRMATION_REQUIRED','MOBILE_SOURCE_PACK_NOT_SUPPORTED','MOBILE_RUN_ID_REQUIRED','MOBILE_BOOTSTRAP_EXISTING_APP_PRESERVED','MOBILE_BOOTSTRAP_ABSENCE_NOT_CONFIRMED','MOBILE_READ_TOKEN_REQUIRED','MOBILE_REMOTE_READ_FAILED','MOBILE_REMOTE_REDIRECT_BLOCKED','MOBILE_REMOTE_RESPONSE_TOO_LARGE','MOBILE_REMOTE_MANIFEST_INVALID','MOBILE_REMOTE_BYTES_MISMATCH','MOBILE_REMOTE_GENERATION_MISMATCH','MOBILE_REMOTE_RECEIPT_INVALID','MOBILE_WRANGLER_FAILED','MOBILE_APP_PREFLIGHT_BLOCKED','APP_REQUEST_OUTCOME_UNKNOWN_NO_AUTOMATIC_RETRY','APP_PUBLICATION_NOT_CONFIRMED','APP_RESPONSE_INVALID_NO_AUTOMATIC_RETRY']);
export function guardMobileExecution({action,confirm,event,env}){
 if(!actions.has(action))throw Error('MOBILE_ACTION_INVALID');
 if(event?.repository?.private!==true)throw Error('MOBILE_PRIVATE_REPOSITORY_REQUIRED');
 if(env.GITHUB_EVENT_NAME!=='workflow_dispatch'||env.GITHUB_REF!=='refs/heads/'+event.repository.default_branch)throw Error('MOBILE_MANUAL_DEFAULT_BRANCH_REQUIRED');
 if(mutations.has(action)&&confirm!==true)throw Error('MOBILE_OPERATION_NOT_CONFIRMED');
 if(mutations.has(action)&&String(env.GITHUB_RUN_ATTEMPT)!=='1')throw Error('MOBILE_RERUN_MUTATION_BLOCKED');
 if(!/^\d{1,20}$/.test(env.GITHUB_RUN_ID||''))throw Error('MOBILE_RUN_ID_REQUIRED');
}
async function readRemote(route,token,fetchImpl,maximum=16*1024*1024){
 let r;try{r=await fetchImpl(APP_ORIGIN+route,{method:'GET',headers:{Authorization:'Bearer '+token},redirect:'manual',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(30000)});}catch{throw Error('MOBILE_REMOTE_READ_FAILED');}
 if(r.status>=300&&r.status<400)throw Error('MOBILE_REMOTE_REDIRECT_BLOCKED');
 const reader=r.body?.getReader();if(!reader)throw Error('MOBILE_REMOTE_READ_FAILED');const chunks=[];let n=0;
 try{for(;;){const x=await reader.read();if(x.done)break;n+=x.value.length;if(n>maximum)throw Error('MOBILE_REMOTE_RESPONSE_TOO_LARGE');chunks.push(x.value);}}finally{await reader.cancel().catch(()=>{});}
 return {response:r,bytes:Buffer.concat(chunks)};
}
export async function restorePublishedRun({destination,readToken,fetchImpl=fetch}){
 if(!/^[A-Za-z0-9_-]{24,256}$/.test(readToken||''))throw Error('MOBILE_READ_TOKEN_REQUIRED');
 const first=await readRemote('/mobile/data/manifest',readToken,fetchImpl);let m;try{m=JSON.parse(first.bytes);}catch{throw Error('MOBILE_REMOTE_MANIFEST_INVALID');}
 if(first.response.status===404&&m.error==='APP_DATA_NOT_PUBLISHED')return null;
 if(!first.response.ok||m.schema!=='BASIC_MOBILE_MANIFEST_V1'||!/^[A-Za-z0-9_-]{1,64}$/.test(m.runId||'')||m.actionAllowed!==false||first.response.headers.get('X-Basic-Run-Id')!==m.runId||!Array.isArray(m.files)||!m.files.length||m.files.length>20000)throw Error('MOBILE_REMOTE_MANIFEST_INVALID');
 const seen=new Set();let total=0;
 for(const f of m.files){if(typeof f.path!=='string'||f.path.length>299||! /^[A-Za-z0-9._/-]+$/.test(f.path)||f.path.startsWith('/')||f.path.split('/').some(x=>!x||x==='.'||x==='..')||seen.has(f.path)||!Number.isSafeInteger(f.bytes)||f.bytes<0||! /^[a-f0-9]{64}$/.test(f.sha256||''))throw Error('MOBILE_REMOTE_MANIFEST_INVALID');seen.add(f.path);total+=f.bytes;}
 if(total>16*1024*1024||!seen.has('run.json'))throw Error('MOBILE_REMOTE_MANIFEST_INVALID');
 const dir=path.resolve(destination,m.runId);fs.mkdirSync(dir,{recursive:true,mode:0o700});if(fs.realpathSync(dir)!==dir)throw Error('MOBILE_REMOTE_MANIFEST_INVALID');
 for(const f of m.files){const x=await readRemote('/mobile/data/'+f.path,readToken,fetchImpl,Math.max(1,f.bytes));if(!x.response.ok||x.response.headers.get('X-Basic-Run-Id')!==m.runId)throw Error('MOBILE_REMOTE_GENERATION_MISMATCH');if(x.bytes.length!==f.bytes||digest(x.bytes)!==f.sha256)throw Error('MOBILE_REMOTE_BYTES_MISMATCH');const p=path.join(dir,f.path);fs.mkdirSync(path.dirname(p),{recursive:true,mode:0o700});if(fs.realpathSync(path.dirname(p))!==path.dirname(p))throw Error('MOBILE_REMOTE_MANIFEST_INVALID');fs.writeFileSync(p,x.bytes,{flag:'wx',mode:0o600});}
 let receipt;try{receipt=validateReviewRun(dir);}catch{throw Error('MOBILE_REMOTE_RECEIPT_INVALID');}
 if(receipt.files.length!==m.files.length-1||receipt.files.some(f=>!m.files.some(x=>x.path===f.path&&x.bytes===f.bytes&&x.sha256===f.sha256)))throw Error('MOBILE_REMOTE_RECEIPT_INVALID');
 return {dir,runId:m.runId,manifestHash:digest(first.bytes)};
}
async function bootstrapAbsence(env,fetchImpl){
 if(!env.CLOUDFLARE_API_TOKEN)throw Error('MOBILE_CF_TOKEN_REQUIRED');
 let r;try{r=await fetchImpl('https://api.cloudflare.com/client/v4/accounts/'+APP_ACCOUNT_ID+'/workers/scripts/etf-basic-app/settings',{method:'GET',headers:{Authorization:'Bearer '+env.CLOUDFLARE_API_TOKEN},redirect:'manual',signal:AbortSignal.timeout(30000)});}catch{throw Error('MOBILE_BOOTSTRAP_ABSENCE_NOT_CONFIRMED');}
 if(r.ok)throw Error('MOBILE_BOOTSTRAP_EXISTING_APP_PRESERVED');
 let b;try{b=await r.json();}catch{throw Error('MOBILE_BOOTSTRAP_ABSENCE_NOT_CONFIRMED');}
 if(r.status!==404||b.success!==false||!b.errors?.some(e=>e.code===10007))throw Error('MOBILE_BOOTSTRAP_ABSENCE_NOT_CONFIRMED');
}
async function wrangler({configFile,secretsFile,env}){
 const args=['--yes','wrangler@4.97.0','deploy','--config',configFile,...(secretsFile?['--secrets-file',secretsFile]:[])];
 await new Promise((resolve,reject)=>execFile('npx',args,{cwd:root,env:{...process.env,...env,CLOUDFLARE_ACCOUNT_ID:APP_ACCOUNT_ID,WRANGLER_SEND_METRICS:'false',CI:'true'},timeout:600000,maxBuffer:2*1024*1024},error=>error?reject(Error('MOBILE_WRANGLER_FAILED')):resolve()));
}
export async function runMobileAction({action,confirm=false,event,env=process.env,dataDir,privateDir,fetchImpl=fetch,deployImpl=wrangler,appDir=app}={}){
 const report={schema:'BASIC_MOBILE_WORKFLOW_REPORT_V1',action:actions.has(action)?action:'INVALID',checkedAt:new Date().toISOString(),status:'BLOCKED_OR_UNKNOWN',phase:'GUARD',automaticRetry:false,phoneReceiptVerified:false,fullOfficialUniverseVerified:false,completionCredits:0,writesAttempted:false};
 try{
  guardMobileExecution({action,confirm,event,env});
  fs.mkdirSync(dataDir,{recursive:true,mode:0o700});fs.mkdirSync(privateDir,{recursive:true,mode:0o700});
  const data=fs.realpathSync(dataDir),privateRoot=fs.realpathSync(privateDir);
  if(data===privateRoot||privateRoot.startsWith(data+path.sep)||data.startsWith(privateRoot+path.sep))throw Error('MOBILE_APP_PREFLIGHT_BLOCKED');
  report.runId='MOBILE_'+env.GITHUB_RUN_ID+'_'+env.GITHUB_RUN_ATTEMPT;
  const configFile=path.join(appDir,'wrangler.json');
  if(action==='bootstrap'){
   report.phase='BOOTSTRAP_ABSENCE_CHECK';await bootstrapAbsence(env,fetchImpl);
   if(!/^[a-f0-9]{32}$/i.test(env.BASIC_APP_KV_ID||'')||/^0+$/.test(env.BASIC_APP_KV_ID))throw Error('MOBILE_KV_ID_REQUIRED');
   fs.writeFileSync(configFile,JSON.stringify({name:'etf-basic-app',main:'worker.mjs',account_id:APP_ACCOUNT_ID,compatibility_date:APP_COMPATIBILITY_DATE,workers_dev:true,assets:{directory:'./public',binding:'ASSETS',run_worker_first:true},kv_namespaces:[{binding:'BASIC_APP_KV',id:env.BASIC_APP_KV_ID}],vars:{}},null,2),{flag:'wx',mode:0o600});
   const assetCheck=await inspectMobileDeployment({configFile,env:{},configOnly:true});if(assetCheck.assets.status!=='MATCHED_BUILD_BYTES')throw Error('MOBILE_APP_PREFLIGHT_BLOCKED');
   report.phase='BOOTSTRAP_DEPLOY';report.writesAttempted=true;await deployImpl({configFile,env});report.status='BOOTSTRAP_DEPLOY_COMMAND_SUCCEEDED_KEYS_NOT_REGISTERED';report.keySetupUrl=APP_ORIGIN+'/mobile/setup-keys.html';return report;
  }
  report.phase='APP_CONFIGURATION';prepareMobileConfig({kvId:env.BASIC_APP_KV_ID,publicKey:env.VAPID_PUBLIC_KEY,contact:env.VAPID_SUBJECT,outputFile:configFile});
  const check=await inspectMobileDeployment({configFile,env});report.localAppPreflight=check;
  if(check.status!=='LOCAL_CONFIG_AND_SECRET_FORMATS_READY_REMOTE_ACCESS_UNVERIFIED')throw Error('MOBILE_APP_PREFLIGHT_BLOCKED');
  if(action==='deploy'){
   if(!env.CLOUDFLARE_API_TOKEN)throw Error('MOBILE_CF_TOKEN_REQUIRED');
   const secretsFile=path.join(privateRoot,'app-secrets.json');fs.writeFileSync(secretsFile,JSON.stringify({BASIC_PWA_READ_TOKEN:env.BASIC_PWA_READ_TOKEN,BASIC_APP_ADMIN_TOKEN:env.BASIC_APP_ADMIN_TOKEN,VAPID_PRIVATE_JWK:env.VAPID_PRIVATE_JWK}),{flag:'wx',mode:0o600});
   report.phase='APP_DEPLOY';report.writesAttempted=true;try{await deployImpl({configFile,secretsFile,env});}finally{fs.rmSync(secretsFile,{force:true});}report.status='DEPLOY_COMMAND_SUCCEEDED_READ_AND_DEVICE_CHECK_PENDING';return report;
  }
  if(action==='push-test'){report.phase='EXPLICIT_PUSH_TEST';report.writesAttempted=true;report.push=await appAdmin('push-test',{env,fetchImpl});report.status=report.push.status;return report;}
  if(!env.BASIC_REFRESH_CONFIG_JSON||Buffer.byteLength(env.BASIC_REFRESH_CONFIG_JSON)>4*1024*1024)throw Error('MOBILE_REFRESH_CONFIG_REQUIRED');
  const refreshConfig=path.join(data,'refresh-config.json');fs.writeFileSync(refreshConfig,env.BASIC_REFRESH_CONFIG_JSON,{flag:'wx',mode:0o600});const loaded=readRefreshConfig(refreshConfig);
  if(loaded.config.targets.some(t=>t.provider==='INPUT_PACK'))throw Error('MOBILE_SOURCE_PACK_NOT_SUPPORTED');
  report.targetPreflight={...refreshPrerequisites(loaded.config,env),localInputs:checkRefreshInputs(loaded).report};
  if(report.targetPreflight.missingEnvironment.length)throw Error('MOBILE_APP_PREFLIGHT_BLOCKED');
  if(action==='check'){report.status='LOCAL_CONFIG_READY_NO_API_OR_DEPLOYMENT_EXECUTED';return report;}
  if(env.BASIC_TARGETS_CONFIRMED!=='true')throw Error('MOBILE_TARGETS_CONFIRMATION_REQUIRED');
  report.phase='RESTORE_PREVIOUS_PUBLISHED_RUN';const previous=await restorePublishedRun({destination:path.join(data,'previous'),readToken:env.BASIC_PWA_READ_TOKEN,fetchImpl});report.previousPublishedRunId=previous?.runId||null;
  report.phase='COLLECT_AND_BUILD';const refreshRoot=path.join(data,'refresh');const built=await refreshBasic({configFile:refreshConfig,outputRoot:refreshRoot,runId:report.runId,env,fetchImpl,priorReviewRunDir:previous?.dir});report.refreshed={runId:built.runId,targetCount:built.refreshReceipt.targetCount,instrumentCount:built.refreshReceipt.instrumentCount,previousReviewRunId:built.refreshReceipt.previousReviewRunId};
  report.phase='PUBLISH';report.writesAttempted=true;report.publication=await appAdmin('publish',{runDir:built.dir,env,fetchImpl});
  report.phase='READ_CONNECTION_CHECK';report.connection=await checkBasicLive({refreshRoot,configFile:refreshConfig,appConfigFile:configFile,env,fetchImpl});report.status=report.connection.status;return report;
 }catch(e){report.reason=fixedErrors.has(e?.message)?e.message:'MOBILE_EXECUTION_FAILED';return report;}
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 let report;try{const event=JSON.parse(fs.readFileSync(process.env.GITHUB_EVENT_PATH));report=await runMobileAction({action:process.env.MOBILE_ACTION,confirm:process.env.MOBILE_CONFIRM==='true',event,dataDir:process.env.MOBILE_DATA_DIR,privateDir:process.env.MOBILE_PRIVATE_DIR});}catch{report={schema:'BASIC_MOBILE_WORKFLOW_REPORT_V1',status:'BLOCKED_OR_UNKNOWN',reason:'MOBILE_RUNNER_INPUT_INVALID',automaticRetry:false,completionCredits:0};}
 fs.mkdirSync(process.env.MOBILE_REPORT_DIR,{recursive:true,mode:0o700});fs.writeFileSync(path.join(process.env.MOBILE_REPORT_DIR,'MOBILE_CONNECTION_REPORT.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});console.log(JSON.stringify(report));
 if(['BLOCKED_OR_UNKNOWN','CONNECTION_PENDING','PUSH_NOT_CONFIRMED'].includes(report.status))process.exitCode=2;
}
