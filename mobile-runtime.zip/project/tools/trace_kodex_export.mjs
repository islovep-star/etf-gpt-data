import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {sourceArtifact,bindRecordEvidence,validateRecordEnvelope,versionedPacketEvidence} from '../src/data_record_contract.mjs';
import {buildEtfMetrics} from '../src/etf_metrics.mjs';
const base=new URL('../data/reconciliation/',import.meta.url);
export function traceKodexExport(){
 const s=JSON.parse(fs.readFileSync(new URL('kodex_reviewed_rows.json',base)));
 for(const a of s.artifacts){const body=fs.readFileSync(new URL(a.localFile||'kodex_379810_dom.txt',base));const actual=sourceArtifact(body,a);if(actual.sha256!==a.sha256||actual.byteLength!==a.byteLength)throw new Error('KODEX_ORIGINAL_CHANGED');}
 const artifact=s.artifacts[0],facts=[];
 for(const r of s.rows)for(const [account,col,unit] of [['close','B','KRW_PER_UNIT'],['volume','E','SHARES'],['navPerUnit','F','KRW_PER_UNIT']]){
  const rawValue=r[account==='navPerUnit'?'nav':account];
  const f=bindRecordEvidence({key:`etf.${account}`,account,instrumentId:s.instrumentId,unit,currency:'KRW',value:rawValue,tradeDate:r.date,measurementDate:r.date,versionId:`${artifact.artifactId}:${col}${r.sourceRow}`,sourceRef:artifact.url,actualOrEstimate:'ACTUAL',volumeMultiplier:account==='volume'?1:undefined,sourceMeaning:s.sourceMeaning},{artifact,locator:`www.kodex.com!${col}${r.sourceRow}`,sourceAccount:account==='navPerUnit'?'펀드기준가격':account==='volume'?'거래량':'거래가격_종가',matchEvidence:`XLS_CELL:${col}${r.sourceRow}`,recordKind:account==='navPerUnit'?'ETF_METADATA':'PRICE'});
  f.sourceVerification.scope='TRANSCRIPTION_ONLY';
  if(!validateRecordEnvelope(f,{asOf:s.asOf,rawArtifacts:s.artifacts}).valid)throw new Error('KODEX_RECORD_INVALID');facts.push(f);
 }
 const latest=s.rows.at(-1),nav=facts.find(f=>f.account==='navPerUnit'&&f.tradeDate===latest.date);
 const metrics=buildEtfMetrics({instrumentId:s.instrumentId,asOf:s.asOf,fundType:'EQUITY',nav,evidenceBundle:{rawArtifacts:s.artifacts}});
 // Reference calculations only. No Worker import, production indicator claim or score.
 const sma={};for(const n of [5,10,20,60,112,224]){let sum=0;for(let i=s.rows.length-n;i<s.rows.length;i++)sum+=s.rows[i].close;sma[n]=sum/n;}
 let obv=0;for(let i=1;i<s.rows.length;i++)obv+=Math.sign(s.rows[i].close-s.rows[i-1].close)*s.rows[i].volume;
 const volumeMean20=s.rows.slice(-20).reduce((v,r)=>v+r.volume,0)/20;
 const referenceAgreement=Object.keys(sma).every(n=>Math.abs(sma[n]-s.referenceCalculations.sma[n])<1e-8)&&obv===s.referenceCalculations.obvFromZero&&volumeMean20===s.referenceCalculations.volumeMean20;
 return {schema:'ETF_PROVIDER_EXPORT_PACKET_V1',instrumentId:s.instrumentId,asOf:s.asOf,rows:s.rowCount,range:s.range,latest,facts,evidence:versionedPacketEvidence(facts),artifacts:s.artifacts,etfMetrics:metrics,sourceMeaning:s.sourceMeaning,referenceCalculations:{sma,obvFromZero:obv,volumeMean20},referenceAgreement,productionIndicatorComparison:s.productionIndicatorComparison,corporateEps:'NOT_APPLICABLE',technicalScoreContribution:0,judgement:'NONE',automaticTradingAllowed:false,deployment:'NOT_ATTEMPTED',operation:'NOT_VERIFIED'};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const t=traceKodexExport();if(process.argv.includes('--output'))fs.writeFileSync(process.argv[process.argv.indexOf('--output')+1],JSON.stringify(t,null,2)+'\n');
 console.log(JSON.stringify({rows:t.rows,facts:t.facts.length,range:t.range,referenceAgreement:t.referenceAgreement,productionIndicatorComparison:t.productionIndicatorComparison}));
}
