import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {latestRefresh,readRefreshConfig} from '../src/basic_refresh.mjs';
import {digest} from '../src/review_run_store.mjs';
import {inspectMobileDeployment} from '../src/mobile_deployment_preflight.mjs';
import {makeAppBundle,APP_ORIGIN} from './mobile_app_admin.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const reasonCodes=new Set(['CONNECTION_CHECK_ARGUMENTS','READ_TOKEN_FILE_INVALID','KEEP_USER_REPORT_OUTSIDE_PROJECT','REFRESH_CONFIG_DOES_NOT_MATCH_NORMAL_RUN','REFRESH_RUN_NOT_RECENT','INPUT_PACK_IS_NOT_LIVE_API_EVIDENCE','REFRESH_REQUEST_RECEIPT_INVALID','REFRESH_TARGET_COUNT_MISMATCH','NO_COMPLETED_REFRESH','REFRESH_HEAD_HASH_MISMATCH','REFRESH_INTEGRITY_FAILURE','REFRESH_GENERATION_INCOMPLETE','REDIRECT_BLOCKED','APP_GENERATION_HEADER_MISMATCH','APP_JSON_REQUIRED','APP_RESPONSE_EMPTY','APP_RESPONSE_TOO_LARGE','APP_DEPLOYED_BYTES_OR_CONTRACT_MISMATCH']);
const reason=e=>reasonCodes.has(e?.message)||/^APP_HTTP_[1-5][0-9]{2}$/.test(e?.message||'')?e.message:'LOCAL_OR_REMOTE_CHECK_FAILED';
export async function checkBasicLive({refreshRoot,configFile,appConfigFile=path.join(root,'deployment/basic_app/wrangler.json'),env=process.env,fetchImpl=fetch,now=Date.now()}={}){
 const report={schema:'BASIC_CONNECTION_REPORT_V1',checkedAt:new Date(now).toISOString(),status:'CONNECTION_PENDING',localRefresh:{status:'UNVERIFIED'},appConfiguration:{status:'UNVERIFIED'},remoteChecks:[],networkRequests:0,requestMethod:'GET_ONLY',remoteWrites:false,automaticRetry:false,fullTargetUniverseApproved:false,phoneReceiptVerified:false,completionCredits:0};let built,bundle;
 try{
  const loaded=readRefreshConfig(configFile);built=latestRefresh(refreshRoot);const r=built.refreshReceipt;
  if(r.configHash!==loaded.configHash)throw Error('REFRESH_CONFIG_DOES_NOT_MATCH_NORMAL_RUN');
  const age=now-Date.parse(r.analysisAsOf);if(!Number.isFinite(age)||age< -300000||age>36*3600000)throw Error('REFRESH_RUN_NOT_RECENT');
  if(loaded.config.targets.some(t=>t.provider==='INPUT_PACK'))throw Error('INPUT_PACK_IS_NOT_LIVE_API_EVIDENCE');
  const requests=JSON.parse(fs.readFileSync(path.join(built.generationDir,'requests.json')));
  if(!Array.isArray(requests)||!requests.length||requests.some(x=>!Number.isInteger(x.status)||x.status<200||x.status>=300))throw Error('REFRESH_REQUEST_RECEIPT_INVALID');
  if(r.targetCount!==loaded.config.targets.length||r.targetResults?.length!==r.targetCount)throw Error('REFRESH_TARGET_COUNT_MISMATCH');
  bundle=await makeAppBundle(built.dir);
  report.localRefresh={status:'CAPTURED_BYTES_AND_CONFIG_MATCHED',runId:built.runId,targetCount:r.targetCount,instrumentCount:r.instrumentCount,rawArtifactCount:r.rawArtifacts,requestCount:requests.length,configHash:r.configHash,normalRunHash:digest(fs.readFileSync(path.join(built.dir,'run.json'))),liveOrigin:'NOT_INDEPENDENTLY_CERTIFIED'};
 }catch(e){report.localRefresh={status:'BLOCKED',reason:reason(e)};return report;}
 const preflight=await inspectMobileDeployment({configFile:appConfigFile,env:{},configOnly:true});
 report.appConfiguration={status:preflight.status,configuration:preflight.configuration,assets:preflight.assets};
 if(preflight.status!=='LOCAL_CONFIG_READY_REMOTE_SECRETS_UNVERIFIED')return report;
 if(!/^[A-Za-z0-9_-]{24,256}$/.test(env.BASIC_PWA_READ_TOKEN||'')){report.remoteChecks=[{name:'READ_TOKEN',status:'BLOCKED',reason:'BASIC_PWA_READ_TOKEN_REQUIRED'}];return report;}
 const publicKey=JSON.parse(fs.readFileSync(appConfigFile)).vars.VAPID_PUBLIC_KEY;
 const check=async(name,route,{privateRead=false,json=false,verify}={})=>{
  try{
   report.networkRequests++;
   const response=await fetchImpl(APP_ORIGIN+route,{method:'GET',headers:privateRead?{Authorization:'Bearer '+env.BASIC_PWA_READ_TOKEN}: {},redirect:'manual',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(30000)});
   if(response.status>=300&&response.status<400)throw Error('REDIRECT_BLOCKED');
   if(!response.ok)throw Error('APP_HTTP_'+response.status);
   if(privateRead&&route.startsWith('/mobile/data/')&&response.headers.get('X-Basic-Run-Id')!==built.runId)throw Error('APP_GENERATION_HEADER_MISMATCH');
   if(json&&!(response.headers.get('Content-Type')||'').includes('application/json'))throw Error('APP_JSON_REQUIRED');
   const reader=response.body?.getReader();if(!reader)throw Error('APP_RESPONSE_EMPTY');const chunks=[];let size=0;
   try{for(;;){const x=await reader.read();if(x.done)break;size+=x.value.length;if(size>8*1024*1024)throw Error('APP_RESPONSE_TOO_LARGE');chunks.push(x.value);}}finally{await reader.cancel().catch(()=>{});}
   const bytes=Buffer.concat(chunks);const data=json?JSON.parse(bytes.toString('utf8')):bytes;
   if(!verify(data))throw Error('APP_DEPLOYED_BYTES_OR_CONTRACT_MISMATCH');
   report.remoteChecks.push({name,status:'MATCHED',httpStatus:response.status});
  }catch(e){report.remoteChecks.push({name,status:'BLOCKED_OR_UNVERIFIED',reason:reason(e)});}
 };
 await check('HEALTH','/health',{json:true,verify:x=>x.ok===true&&x.version==='BASIC_APP_V1'});
 for(const [name,route,file] of [['MOBILE_HTML','/mobile/','mobile/index.html'],['PUSH_CLIENT','/mobile/push-client.mjs','mobile/push-client.mjs'],['SERVICE_WORKER','/sw.js','sw.js']]){
  const hash=digest(fs.readFileSync(path.join(root,'deployment/basic_app/public',file)));await check(name,route,{verify:x=>digest(x)===hash});
 }
 await check('PUSH_CONFIG','/mobile/push/config',{privateRead:true,json:true,verify:x=>x.publicKey===publicKey&&x.mode==='GENERIC_REVIEW_NOTICE'});
 await check('NORMAL_RUN','/mobile/data/run',{privateRead:true,json:true,verify:x=>x.runId===built.runId&&x.status==='COMPLETE'&&x.integrityStatus==='VERIFIED_PUBLISHED_BYTES'&&x.readOnly===true&&x.orderExecution===false});
 const expected=new Map(bundle.files.map(x=>[x.path,x]));
 await check('NORMAL_MANIFEST','/mobile/data/manifest',{privateRead:true,json:true,verify:x=>x.schema==='BASIC_MOBILE_MANIFEST_V1'&&x.runId===built.runId&&x.actionAllowed===false&&Array.isArray(x.files)&&x.files.length===expected.size&&new Set(x.files.map(f=>f.path)).size===expected.size&&x.files.every(f=>expected.get(f.path)?.sha256===f.sha256&&expected.get(f.path)?.bytes===f.bytes)});
 if(report.remoteChecks.every(x=>x.status==='MATCHED'))report.status='READ_CONNECTION_MATCHED_DEVICE_AND_TARGET_CONFIRMATION_PENDING';
 return report;
}
export async function main(args=process.argv.slice(2)){
 const v={},allowed=new Set(['--refresh-root','--config','--read-token-file','--output-json']);
 for(let i=0;i<args.length;i++){const k=args[i];if(!allowed.has(k)||v[k]||!args[i+1]||args[i+1].startsWith('--'))throw Error('CONNECTION_CHECK_ARGUMENTS');v[k]=args[++i];}
 const env={};if(v['--read-token-file']){const p=fs.realpathSync(v['--read-token-file']);if(fs.statSync(p).size>1000)throw Error('READ_TOKEN_FILE_INVALID');env.BASIC_PWA_READ_TOKEN=fs.readFileSync(p,'utf8').trim();}
 else env.BASIC_PWA_READ_TOKEN=process.env.BASIC_PWA_READ_TOKEN;
 const report=await checkBasicLive({refreshRoot:path.resolve(v['--refresh-root']||path.join(root,'../ETF_BASIC_USER_DATA/refresh')),configFile:path.resolve(v['--config']||path.join(root,'config/refresh.json')),env});
 if(v['--output-json']){const p=path.resolve(v['--output-json']),dir=fs.realpathSync(path.dirname(p)),project=fs.realpathSync(root);if(dir===project||dir.startsWith(project+path.sep))throw Error('KEEP_USER_REPORT_OUTSIDE_PROJECT');fs.writeFileSync(path.join(dir,path.basename(p)),JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});}
 console.log(JSON.stringify(report));return report;
}
if(process.argv[1]===fileURLToPath(import.meta.url))main().then(r=>{if(r.status==='CONNECTION_PENDING')process.exitCode=2;}).catch(e=>{console.error(JSON.stringify({status:'CONNECTION_PENDING',reason:reason(e),automaticRetry:false}));process.exitCode=2;});
