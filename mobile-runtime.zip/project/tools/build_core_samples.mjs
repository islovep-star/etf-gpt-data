import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {traceRealSamples} from './trace_real_samples.mjs';
import {traceKodexExport} from './trace_kodex_export.mjs';
import {assessSampleCompletion} from '../src/sample_completion_gate.mjs';
import {normalizeProviderExport} from '../src/provider_export_adapter.mjs';
import {derivedRecordEvidence,sourceArtifact,bindRecordEvidence} from '../src/data_record_contract.mjs';
import {buildCoreReview} from '../src/core_review.mjs';
import {buildStockContext} from '../src/stock_context_pipeline.mjs';
const root=new URL('../',import.meta.url);
export function buildCoreSamples(){
 const financial=traceRealSamples(),etf=traceKodexExport(),gate=assessSampleCompletion(financial,etf);
 if(!gate.passed)throw new Error('STAGE04_BOUNDED_GATE_BLOCKED');
 const extra=JSON.parse(fs.readFileSync(new URL('data/phase04_08/reviewed_core_rows.json',root)));
 for(const a of extra.artifacts){const raw=sourceArtifact(fs.readFileSync(new URL('data/phase04_08/'+a.localFile,root)),a);if(raw.sha256!==a.sha256)throw new Error('CORE_RAW_HASH_MISMATCH');}
 const artifacts=[...financial.artifacts,...etf.artifacts,...extra.artifacts];
 const asOf=[financial.asOf,etf.asOf,extra.asOf].sort((a,b)=>Date.parse(a)-Date.parse(b)).at(-1);
 const facts=normalizeProviderExport(extra.appleRows,{rawArtifacts:artifacts,asOf});
 for(const date of ['2024-09-28','2023-09-30']){
  const get=a=>facts.find(f=>f.account===a&&f.periodEnd===date);
  for(const [account,accounts] of [['interestBearingDebt',['commercialPaper','currentTermDebt','noncurrentTermDebt']],['currentDebt',['commercialPaper','currentTermDebt']]]){
   const inputs=accounts.map(get);if(inputs.some(x=>!x))throw new Error('DISCLOSED_DEBT_COMPONENT_REQUIRED');
   facts.push(derivedRecordEvidence({...inputs[0],key:`fundamental.${account}`,account,sourceAccount:'Derived '+accounts.join(' + '),value:inputs.reduce((s,f)=>s+f.value,0),sourceRef:'DERIVED_DISCLOSED_DEBT_COMPONENTS',versionId:`APPLE_DEBT:${account}:${date}`,definition:account==='interestBearingDebt'?'COMMERCIAL_PAPER_AND_TERM_DEBT_ONLY_EXCLUDES_LEASES':'COMMERCIAL_PAPER_AND_CURRENT_TERM_DEBT_ONLY',formula:accounts.join(' + '),derived:true},inputs));
  }
 }
 const inputs=[],contexts={};
 for(const symbol of ['005930','AAPL']){
  const stockContextInput={identity:{symbol,market:symbol==='AAPL'?'US':'KR',instrumentName:symbol==='AAPL'?'Apple Inc.':'삼성전자'},fundamentalFacts:[...financial.contexts[symbol].context.fundamental.history,...(symbol==='AAPL'?facts:[])],evidenceBundle:{rawArtifacts:artifacts},warnings:['HISTORICAL_2023_2024_SOURCE_SAMPLE_NOT_LATEST']};
  contexts[symbol]=buildStockContext({...stockContextInput,asOf});inputs.push({assetMode:'STOCK',analysisAsOf:asOf,stockContextInput});
 }
 const a=extra.artifacts.find(x=>x.artifactId==='kodex_20260831_pdf');
 const fee=bindRecordEvidence({key:'etf.statedAnnualManagementFeePct',account:'statedAnnualManagementFeePct',instrumentId:'379810',value:extra.monthly.managementFeePct,currency:'KRW',unit:'PCT_PER_YEAR',measurementDate:extra.monthly.measurementDate,definition:extra.monthly.managementFeeDefinition,actualOrEstimate:'ACTUAL',sourceRef:a.url,versionId:'KODEX_MONTHLY_20260831_FEE'},{artifact:a,locator:'page=1;기본정보;총 보수',sourceAccount:'총 보수',matchEvidence:'MONTHLY_FEE_VISUAL_AND_TEXT_MATCH',recordKind:'ETF_METADATA'});
 const latestFacts=etf.facts.filter(x=>x.tradeDate===etf.latest.date);
 const productMetadata={name:'KODEX 미국나스닥100',fundType:'EQUITY',benchmark:extra.monthly.benchmark,monthly:{...extra.monthly,rawReference:{artifactId:a.artifactId,sha256:a.sha256,locator:'page=1'}},pcf:{...extra.pcf,rawReference:{artifactId:extra.artifacts[1].artifactId,sha256:extra.artifacts[1].sha256,locator:'www.kodex.com!A1:G106'}},reportedManagementFee:fee,priceNav:{date:etf.latest.date,close:etf.latest.close,nav:etf.latest.nav,volume:etf.latest.volume,sourceMeaning:etf.sourceMeaning,rawReferences:latestFacts.map(f=>f.rawReference)},countryCurrencyExposure:{status:'MISSING',reason:'LISTING_OR_ISIN_COUNTRY_IS_NOT_ECONOMIC_EXPOSURE'},overlap:{status:'MISSING',reason:'ACTUAL_HOLDINGS_AND_PRIVATE_PORTFOLIO_REQUIRED'}};
 inputs.push({assetMode:'ETF',analysisAsOf:asOf,etfMetricsInput:{instrumentId:'379810',asOf,fundType:'EQUITY',price:latestFacts.find(f=>f.account==='close'),nav:latestFacts.find(f=>f.account==='navPerUnit'),expenseRatio:fee,evidenceBundle:{rawArtifacts:artifacts}},sourceFacts:[...latestFacts,fee],productMetadata});
 const reviews=inputs.map(buildCoreReview);
 return {schema:'CORE_REAL_SAMPLE_OUTPUT_V1',asOf,stage04Gate:gate,reviews,inputs,contexts,artifacts,financialHistory:contexts,etfHistory:etf.facts,normalizedSupplement:facts,realUserAccountPresent:false,deployment:'NOT_ATTEMPTED'};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const s=buildCoreSamples();if(process.argv.includes('--output'))fs.writeFileSync(process.argv[process.argv.indexOf('--output')+1],JSON.stringify(s,null,2)+'\n');
 console.log(JSON.stringify({reviews:s.reviews.map(r=>({instrumentId:r.instrumentId,assetType:r.assetType,safety:r.safety.status})),supplement:s.normalizedSupplement.length,asOf:s.asOf}));
}
