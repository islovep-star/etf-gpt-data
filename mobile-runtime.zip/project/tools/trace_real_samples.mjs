import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {normalizeProviderExport} from '../src/provider_export_adapter.mjs';
import {sourceArtifact,validateRecordEnvelope,bindRecordEvidence,versionedPacketEvidence} from '../src/data_record_contract.mjs';
import {deriveStandaloneQuarter} from '../src/dart_adapter.mjs';
import {buildStockContext} from '../src/stock_context_pipeline.mjs';
import {buildCompactStockPacket} from '../src/stock_context_schema.mjs';
import {buildEtfMetrics} from '../src/etf_metrics.mjs';
import {calculateEps} from '../src/financial_contract.mjs';
const base=new URL('../data/real_samples/',import.meta.url);
export function traceRealSamples(){
 const sample=JSON.parse(fs.readFileSync(new URL('reviewed_rows.json',base),'utf8'));
 for(const artifact of sample.artifacts){const measured=sourceArtifact(fs.readFileSync(new URL(artifact.localFile,base)),artifact);if(measured.sha256!==artifact.sha256||measured.byteLength!==artifact.byteLength)throw new Error('RAW_ARTIFACT_CHANGED');}
 const asOf=sample.asOf,rawArtifacts=sample.artifacts;
 const normalized=normalizeProviderExport(sample.rows,{rawArtifacts,asOf});const derived=[];
 for(const year of [2023,2024]){
  for(const account of ['revenue','operatingIncome','netIncome','profitCommon']){
   const a=normalized.find(f=>f.instrumentId==='005930'&&f.account===account&&f.fiscalYear===year&&f.periodKind==='ANNUAL');
   const b=normalized.find(f=>f.instrumentId==='005930'&&f.account===account&&f.fiscalYear===year&&f.periodKind==='YTD'&&f.fiscalQuarter===3);
   derived.push(deriveStandaloneQuarter({currentCumulative:a,previousCumulative:b,quarter:'Q4',availableAt:asOf,sourceRef:'DERIVED_FROM_SAMSUNG_ORIGINALS'}));
  }
  for(const account of ['operatingCashFlow','capexPpe'])for(const q of [2,3,4]){
   const get=n=>normalized.find(f=>f.instrumentId==='AAPL'&&f.account===account&&f.fiscalYear===year&&f.fiscalQuarter===n);
   derived.push(deriveStandaloneQuarter({currentCumulative:get(q),previousCumulative:get(q-1),quarter:`Q${q}`,availableAt:asOf,sourceRef:'DERIVED_FROM_APPLE_ORIGINALS'}));
  }
 }
 const records=[...normalized,...derived];for(const f of records){const c=validateRecordEnvelope(f,{asOf,rawArtifacts});if(!c.valid)throw new Error('TRACE_CONTRACT:'+c.errors.join(','));}
 const epsChecks=[];
 for(const f of normalized.filter(f=>f.account==='basicEps'||f.account==='dilutedEps')){
  const same=g=>g.instrumentId===f.instrumentId&&g.periodStart===f.periodStart&&g.periodEnd===f.periodEnd&&g.periodKind===f.periodKind;
  const get=account=>normalized.find(g=>same(g)&&g.account===account);
  const income=get(f.instrumentId==='005930'?'profitCommon':'netIncome');const shares=get(f.account==='basicEps'?'weightedBasicShares':'weightedDilutedShares');
  const computed=income.value/shares.value, tolerance=f.currency==='KRW'?0.51:0.0051;
  epsChecks.push({instrumentId:f.instrumentId,periodStart:f.periodStart,periodEnd:f.periodEnd,periodKind:f.periodKind,account:f.account,reported:f.value,recomputed:computed,difference:Math.abs(computed-f.value),roundingTolerance:tolerance,pass:Math.abs(computed-f.value)<=tolerance,calculationBasis:f.instrumentId==='005930'?'ORDINARY_PROFIT_WEIGHTED_ORDINARY_SHARES':'INDEPENDENT_NET_INCOME_SHARE_ARITHMETIC_CHECK_NOT_FALLBACK_EPS',inputReferences:[income.rawReference,shares.rawReference,f.rawReference]});
 }
 const contexts={};for(const symbol of ['005930','AAPL']){const facts=records.filter(f=>f.instrumentId===symbol);const context=buildStockContext({identity:{symbol,market:symbol==='AAPL'?'US':'KR'},asOf,fundamentalFacts:facts,evidenceBundle:{rawArtifacts},warnings:['ORIGINAL_EXPORT_SAMPLE_NOT_LIVE_API','HISTORICAL_VALUES_NOT_PIT_VERIFIED',...epsChecks.filter(x=>x.instrumentId===symbol&&!x.pass).map(x=>'SOURCE_RECONCILIATION_OPEN:EPS:'+x.periodEnd)]});contexts[symbol]={context,packet:buildCompactStockPacket(context),coverage:{quarterRevenuePeriods:facts.filter(f=>f.account==='revenue'&&f.periodKind==='QUARTER').map(f=>({start:f.periodStart,end:f.periodEnd,derived:!!f.derived})),quarterEpsPeriods:facts.filter(f=>f.account==='basicEps'&&f.periodKind==='QUARTER').length}};}
 const etfArtifact=rawArtifacts.find(a=>a.artifactId===sample.etf.artifactId);
 const etfFacts=sample.etf.facts.map((f,i)=>bindRecordEvidence({...f,key:`etf.${f.account}`,instrumentId:'379810',unit:f.account==='navPerUnit'?'KRW_PER_UNIT':'PCT_PER_YEAR',value:f.value,versionId:`KODEX_20220531:${i}`,sourceRef:etfArtifact.url,measurementDate:'2022-05-31',actualOrEstimate:'ACTUAL'},{artifact:etfArtifact,locator:f.locator,sourceAccount:f.account,matchEvidence:`KODEX_ROW:${f.account}`,recordKind:'ETF_METADATA'}));
 for(const f of etfFacts){const c=validateRecordEnvelope(f,{asOf,rawArtifacts});if(!c.valid)throw new Error('ETF_CONTRACT:'+c.errors.join(','));}
 const etfMetrics=buildEtfMetrics({instrumentId:'379810',asOf,fundType:'EQUITY',nav:etfFacts[0],expenseRatio:etfFacts[1],evidenceBundle:{rawArtifacts}});
 const top10Sum=sample.etf.top10.reduce((s,h)=>s+h.weightPct,0);
 return {schema:'PHASE04_ORIGINAL_TO_PACKET_TRACE_V1',asOf,sourceMode:sample.validationScope,artifacts:rawArtifacts,recordCount:records.length,normalizedCount:normalized.length,derivedCount:derived.length,epsChecks,allEpsChecksPass:epsChecks.every(x=>x.pass),contexts,etf:{source:sample.etf,facts:etfFacts,evidence:versionedPacketEvidence(etfFacts),metrics:etfMetrics,disclosedTop10WeightSumPct:Math.round(top10Sum*100)/100,disclosedReturnDifferencePp:Math.round((sample.etf.oneMonthReturnPct-sample.etf.oneMonthBenchmarkPct)*100)/100,returnDifferenceIsMatchedWindowTrackingMetric:false,corporateEps:'NOT_APPLICABLE'},status:{numericSampleValidation:epsChecks.every(x=>x.pass)?'MATCHED_BOUNDED_SAMPLE':'PARTIAL_UNRESOLVED_SOURCE_DIFFERENCE',apiCollection:'BLOCKED_NOT_CONFIGURED',pointInTime:'NOT_VERIFIED',reference379810PriceVolumeIndicators:'NOT_VERIFIED',deployment:'NOT_ATTEMPTED',operation:'NOT_VERIFIED'}};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const out=traceRealSamples();const path=process.argv[process.argv.indexOf('--output')+1];if(process.argv.includes('--output'))fs.writeFileSync(path,JSON.stringify(out,null,2)+'\n');
 console.log(JSON.stringify({recordCount:out.recordCount,normalized:out.normalizedCount,derived:out.derivedCount,epsChecks:out.epsChecks.length,epsPassed:out.epsChecks.filter(x=>x.pass).length,quarterCoverage:Object.fromEntries(Object.entries(out.contexts).map(([k,v])=>[k,v.coverage])),etfTop10:out.etf.disclosedTop10WeightSumPct,status:out.status}));if(!out.allEpsChecksPass)process.exitCode=2;
}
