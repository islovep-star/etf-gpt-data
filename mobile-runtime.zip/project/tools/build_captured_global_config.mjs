import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {parseSourceSeries,latestFredRecord,latestVixRecord} from '../vendor/g02/g02_source_adapters.mjs';
const root=new URL('../data/g02_public/',import.meta.url);
export function buildCapturedGlobalConfig({includeCboe=false}={}){
 if(typeof includeCboe!=='boolean')throw Error('INVALID_CBOE_OPTION');
 const acquisition=JSON.parse(fs.readFileSync(new URL('acquisition.json',root))),domainEvidence={},all=[...acquisition.artifacts.map(a=>({...a,sourceRoot:root}))];
 if(includeCboe){const cboeRoot=new URL('../data/g02_cboe_20260930/',import.meta.url),cboe=JSON.parse(fs.readFileSync(new URL('acquisition.json',cboeRoot)));all.push(...cboe.artifacts.map(a=>({...a,sourceRoot:cboeRoot,collection:'g02_cboe_20260930'})));}
 for(const a of all){if(!a.ok)continue;const rows=parseSourceSeries(fs.readFileSync(new URL(a.localFile,a.sourceRoot),'utf8'),a.name==='VIX'?'CBOE_VIX':'FRED');if(rows.at(-1).value===null)continue;
  const x=a.name==='VIX'?latestVixRecord(rows,a.retrievedAt):latestFredRecord(a.name,rows,a.retrievedAt);
  x.record.raw_reference={localFile:a.localFile,sha256:a.sha256,...(a.collection?{collection:a.collection}:{})};(domainEvidence[x.domain]??=[]).push(x.record);
 }
 return {analysisAsOf:new Date(Math.max(...all.map(a=>Date.parse(a.retrievedAt)))).toISOString(),domainEvidence,
  limitations:['FRED 공개 원문 5개 표본 대조; 직접 Node 수집기는 연결 실패',includeCboe?'Cboe 공식 페이지의 갱신된 CSV 경로에서 별도 VIX 원문 확보; 이전 HTTP307 기록은 보존':'Cboe 공개 원문은 HTTP 307로 미확보','시장 참여 폭·교차자산·직접흐름 미연결','영역별 신호 산식·임계값 미동결: 관측값을 방향 신호로 바꾸지 않음','관측일 UTC 자정 및 기존 G01 신선도 기준의 보수적 판정; 실제 공표시각/PIT 인증 아님']};
}
if(process.argv[1]===fileURLToPath(import.meta.url))console.log(JSON.stringify(buildCapturedGlobalConfig({includeCboe:process.argv.includes('--include-cboe')}),null,2));
