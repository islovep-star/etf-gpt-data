import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {validateReviewRun,digest} from '../src/review_run_store.mjs';
import {validateBundle} from '../deployment/basic_app/worker.mjs';
export const APP_ORIGIN='https://etf-basic-app.islovep.workers.dev';
export async function makeAppBundle(runDir){
 const dir=fs.realpathSync(runDir),receipt=validateReviewRun(dir),names=[...receipt.files.map(x=>x.path),'run.json'],files=[];
 for(const name of names){const file=path.resolve(dir,name);if(!file.startsWith(dir+path.sep)||fs.realpathSync(file)!==file)throw Error('APP_BUNDLE_PATH');const b=fs.readFileSync(file);files.push({path:name,bytes:b.length,sha256:digest(b),base64:b.toString('base64url')});}
 const bundle={schema:'BASIC_APP_UPLOAD_V1',runId:receipt.runId,files};await validateBundle(bundle);if(Buffer.byteLength(JSON.stringify(bundle))>24*1024*1024)throw Error('APP_BUNDLE_TOO_LARGE_KEEP_LOCAL_OR_USE_LATER_CHUNK_STORAGE');return bundle;
}
export async function appAdmin(action,{runDir,env=process.env,fetchImpl=fetch}={}){
 if(!['check','publish','push-test'].includes(action))throw Error('APP_ADMIN_ACTION');
 const bundle=action==='push-test'?null:await makeAppBundle(runDir);
 if(action==='check')return {status:'BUNDLE_READY',runId:bundle.runId,files:bundle.files.length,bytes:Buffer.byteLength(JSON.stringify(bundle)),origin:APP_ORIGIN,networkRequestsPerformed:false,filesWritten:false};
 const token=env.BASIC_APP_ADMIN_TOKEN;if(!/^[A-Za-z0-9_-]{24,256}$/.test(token||''))throw Error('BASIC_APP_ADMIN_TOKEN_REQUIRED');
 // This CLI never deploys infrastructure or publishes automatically after a refresh.
 let r;try{r=await fetchImpl(APP_ORIGIN+'/admin/'+(action==='publish'?'publish':'push-test'),{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(bundle||{confirm:'GENERIC_REVIEW_NOTICE'}),redirect:'error',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(60000)});}catch{throw Error('APP_REQUEST_OUTCOME_UNKNOWN_NO_AUTOMATIC_RETRY');}
 let data;try{data=await r.json();}catch{throw Error('APP_RESPONSE_INVALID_NO_AUTOMATIC_RETRY');}
 // Never print upstream text or echoed credentials.
 if(JSON.stringify(data).includes(token))throw Error('APP_RESPONSE_CONTAINS_CREDENTIAL');
 if(!r.ok)throw Error('APP_HTTP_'+r.status);
 if(action==='publish'&&(data?.ok!==true||data.runId!==bundle.runId))throw Error('APP_PUBLICATION_NOT_CONFIRMED');
 return action==='publish'?{status:data.state,runId:data.runId,consistency:data.consistency,automaticRetry:false}:{status:data.ok?'PUSH_SERVICE_ACCEPTED':'PUSH_NOT_CONFIRMED',results:(data.results||[]).map(x=>({state:x.state,httpStatus:x.httpStatus})),deviceReceiptVerified:false,automaticRetry:false};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const [action,dir,...extra]=process.argv.slice(2);
 if(extra.length||action==='push-test'&&dir)throw Error('APP_ADMIN_ARGUMENTS');
 appAdmin(action,{runDir:dir}).then(x=>console.log(JSON.stringify(x))).catch(e=>{console.error(JSON.stringify({status:'BLOCKED_OR_UNKNOWN',reason:/^[A-Z0-9_]+$/.test(e.message)?e.message:'APP_ADMIN_FAILED',automaticRetry:false}));process.exitCode=2;});
}
